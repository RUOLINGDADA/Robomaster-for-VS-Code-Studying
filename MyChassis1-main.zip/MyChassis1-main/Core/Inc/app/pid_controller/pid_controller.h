/**
  ******************************************************************************
  * @file    pid_controller.h
  * @brief   通用 PID 与位置-速度级联 PID 接口。
  *
  * 本模块只做控制器计算，不绑定电机、CAN 或 FreeRTOS。单环 PID 支持梯形积分、
  * 变速积分、积分限幅、微分先行和微分低通；级联接口供云台等位置-速度双环复用。
  ******************************************************************************
  */

#ifndef PID_CONTROLLER_H
#define PID_CONTROLLER_H

#include <stdbool.h>

/**
 * @brief PID 参数。
 */
typedef struct {
  float kp;                         /* 比例系数，单位：输出单位/误差单位 */
  float ki;                         /* 积分系数，单位：输出单位/(误差单位·秒) */
  float kd;                         /* 微分系数，单位：输出单位·秒/测量单位 */
  float output_limit;               /* 输出绝对值上限 */
  float integral_limit;             /* 积分项绝对值上限 */
  float integral_error_scale;       /* 变速积分 a，权重=1/(1+a|e|)；单位为误差单位的倒数，0为全积分 */
  float derivative_cutoff_hz;       /* 微分低通截止频率，单位：Hz */
} Pid_ControllerConfigTypeDef;

/**
 * @brief PID 控制器运行状态。
 */
typedef struct {
  Pid_ControllerConfigTypeDef config; /* 参数副本，无动态内存 */
  float integral;                    /* 已乘 Ki 的积分项，单位为输出单位 */
  float previous_error;              /* 上次误差，用于梯形积分 */
  float previous_measurement;        /* 上次测量，用于微分先行 */
  float derivative_filtered;         /* 滤波后的微分项，单位为输出单位 */
  bool initialized;                  /* 是否已取得首个样本；复位后首帧微分为0 */
} Pid_ControllerTypeDef;

/**
 * @brief 位置环输出速度、速度环输出电流的双环控制器。
 */
typedef struct {
  Pid_ControllerTypeDef position_pid; /* 位置外环，输出速度 */
  Pid_ControllerTypeDef speed_pid;    /* 速度内环，输出执行器指令 */
} Pid_CascadeControllerTypeDef;

/**
 * @brief  初始化单环 PID。
 * @param  controller 控制器对象，不能为 NULL。
 * @param  config 参数，不能为 NULL；限幅使用非负值。
 * @retval true 初始化成功；false 参数为空、非有限值或限幅/变速积分系数非法。
 * @note 单一任务独占对象；初始化失败时对象清零，计算返回 0。
 */
bool Pid_Controller_Init(Pid_ControllerTypeDef *controller,
                         const Pid_ControllerConfigTypeDef *config);

/**
 * @brief  清除积分、微分历史和首次采样标志。
 * @param  controller 控制器对象，不能为 NULL。
 * @retval 无。
 */
void Pid_Controller_Reset(Pid_ControllerTypeDef *controller);

/**
 * @brief 计算一次单环 PID 输出。
 * @param controller 控制器对象。
 * @param target 目标值，单位由调用方定义。
 * @param measurement 反馈值，单位必须与 target 相同。
 * @param dt_s 本次采样间隔，单位：秒；非正值或非有限值不更新状态并返回 0。
 * @retval 限幅后的控制输出。
 * @note 微分项对 measurement 求导，避免目标阶跃造成微分冲击。
 */
float Pid_Controller_Calc(Pid_ControllerTypeDef *controller, float target,
                          float measurement, float dt_s);

/**
 * @brief 初始化位置-速度双环控制器。
 * @param cascade 级联控制器对象。
 * @param position_config 外环位置 PID 参数，输出单位应为速度。
 * @param speed_config 内环速度 PID 参数，输出单位应为执行器指令。
 * @retval true 初始化成功；false 参数非法。
 */
bool Pid_CascadeController_Init(
    Pid_CascadeControllerTypeDef *cascade,
    const Pid_ControllerConfigTypeDef *position_config,
    const Pid_ControllerConfigTypeDef *speed_config);

/**
 * @brief 清除级联控制器的两个环路历史。
 * @param cascade 级联控制器对象。
 * @retval 无。
 */
void Pid_CascadeController_Reset(Pid_CascadeControllerTypeDef *cascade);

/**
 * @brief 计算“位置外环 → 速度内环”的级联输出。
 * @param cascade 级联控制器对象。
 * @param position_target 位置目标，单位由调用方定义。
 * @param position_measurement 位置反馈。
 * @param speed_measurement 速度反馈。
 * @param dt_s 本次采样间隔，单位：秒。
 * @retval 限幅后的执行器输出。
 * @note 位置应是连续角度；跨圈或最短路径误差由调用方处理，不能直接使用 0~8191 原始值。
 */
float Pid_CascadeController_Calc(Pid_CascadeControllerTypeDef *cascade,
                                 float position_target,
                                 float position_measurement,
                                 float speed_measurement, float dt_s);

#endif /* PID_CONTROLLER_H */

/**
  ******************************************************************************
  * @file    board_can.h
  * @brief   底盘 CAN 板级接口：过滤器配置、外设启动和接收中断绑定。
  *          Board-level CAN interface: filter setup, peripheral start-up and RX
  *          notification binding.
  *
  * 为什么单独做一层 / Why a separate layer:
  *   CubeMX 生成的 `Core/Src/can.c` 只负责位时序、GPIO 复用和中断向量，它既不
  *   配置接收过滤器也不调用 HAL_CAN_Start()。过滤器内容和“哪些 ID 该被接收”
  *   属于应用需求而不是硬件配置，放在这里可以让重新生成 CubeMX 代码时不丢失，
  *   同时保持生成文件完全不被改动。
  *   The generated can.c configures bit timing, GPIO and NVIC only. Acceptance
  *   filters and HAL_CAN_Start() depend on application needs, so they live here to
  *   survive CubeMX regeneration and to leave generated files untouched.
  *
  * 不负责的内容 / Out of scope:
  *   - CAN 位时序、GPIO 复用、NVIC 优先级（由 CubeMX 生成代码负责）。
  *     Bit timing, GPIO alternate function and NVIC priority (generated code).
  *   - 具体电机协议解析（由 bsp/m3508_c620 负责）。
  *     Motor protocol decoding (see bsp/m3508_c620).
  ******************************************************************************
  */

#ifndef BOARD_CAN_H
#define BOARD_CAN_H

#include <stdbool.h>
#include <stdint.h>

/**
 * @brief  配置底盘 CAN1 接收过滤器并启动外设与 FIFO0 接收中断。
 *         Configure the chassis CAN1 acceptance filter and start the peripheral
 *         together with the FIFO0 message-pending interrupt.
 * @param  无 / none.
 * @retval true  过滤器配置成功且 CAN1 已进入 LISTENING 状态。
 *               Filter accepted and CAN1 reached the LISTENING state.
 * @retval false 过滤器或启动步骤失败；调用方应停止后续电机初始化。
 *               Filter or start-up failed; the caller should abort motor init.
 *
 * @note   必须在 MX_CAN1_Init() 之后、且在整个系统开始发送控制帧之前调用一次。
 *         典型位置是 main() 的 `USER CODE BEGIN 2` 区域，调度器启动之前。
 *         Call once after MX_CAN1_Init() and before any control frame is sent,
 *         typically in main()'s USER CODE BEGIN 2 section.
 * @note   本函数不阻塞、不使用动态内存，可以在调度器启动前安全调用。
 *         Non-blocking and allocation-free, safe before the scheduler starts.
 * @note   本函数目前只处理 CAN1。CAN2（云台总线）保持未启动状态：
 *         STM32F407 的 CAN1 与 CAN2 共享同一组 28 个过滤器，CAN2 只能使用
 *         14 ~ 27 号过滤器，而这些过滤器只有在 CAN1 处于初始化模式时才允许
 *         修改。等云台电机模块接入时，应在这里统一规划过滤器的分组，
 *         而不是在 CAN2 已经启动后临时添加过滤器。
 *         Only CAN1 is handled here. CAN2 (gimbal bus) is intentionally left
 *         unstarted: CAN1 and CAN2 share the same 28 filter banks on STM32F407,
 *         CAN2 may only use banks 14 ~ 27, and those banks can be modified only
 *         while CAN1 is in initialisation mode. Plan the filter split here when
 *         the gimbal module is added.
 */
bool BoardCan_Init(void);

/**
 * @brief  处理 CAN1 接收 FIFO0 中的待处理报文。
 *         Service pending messages in the CAN1 RX FIFO0.
 * @param  无 / none.
 * @retval true  至少成功取走并解析了一帧 / at least one frame was fetched.
 * @retval false 没有可取帧或帧不属于本工程设备 / nothing to fetch or unknown.
 *
 * @note   运行在 CAN1_RX0 中断上下文，只能做短操作：不打印、不阻塞、
 *         不调用非 FromISR 的 FreeRTOS API。
 *         Runs in the CAN1_RX0 ISR context: short work only, no printing, no
 *         blocking, and no non-FromISR FreeRTOS API.
 */
bool BoardCan_PollRxFifo0(void);

/**
 * @brief  检测 CAN1 是否进入 Bus-Off，若是则重启外设使其重新上线。
 *         Detect whether CAN1 entered Bus-Off and restart the peripheral so it
 *         rejoins the bus.
 * @param  无 / none.
 * @retval true  本次调用执行了 Bus-Off 恢复 / a recovery was performed.
 * @retval false 总线正常，无需恢复 / the bus is healthy, nothing to do.
 *
 * @note   必须在普通任务或主循环中周期调用（本工程由自检任务每 2 ms 调用一次）。
 *         不要放在中断里：HAL_CAN_Stop()/HAL_CAN_Start() 会重新配置外设寄存器，
 *         耗时远超中断应当承担的工作量。
 *         Call periodically from a task (the self-test task calls it every 2 ms).
 *         Never from an ISR: restarting the peripheral is far too slow for one.
 *
 * @note   **为什么必须有这个函数**：当本节点是总线上唯一节点、或 CANH/CANL 断线、
 *         或收发器未供电时，每一帧都收不到 ACK，发送错误计数 TEC 每帧 +8，约 31 帧
 *         后达到 255 触发 Bus-Off。此时硬件自动把本节点从总线摘除，**既不能发也
 *         不能收**。本工程 `.ioc` 中 CAN1.AutoBusOff = DISABLE，硬件不会自动恢复，
 *         因此如果没有本函数，外设会永久沉默直到手动复位——表现为“板子像死的”。
 *         Without this, Bus-Off is permanent: the node leaves the bus and never
 *         comes back, so no feedback is ever received again.
 *
 * @note   恢复只解决“外设被摘除”的问题，**不解决根因**。如果物理层仍然不通，
 *         重启后会在 2 ms 内再次 Bus-Off，此时 BoardCan_GetBusOffCount() 会持续
 *         增长。该计数增长即说明物理层仍有故障。
 *         Recovery cannot fix a broken physical layer; the counter will keep rising.
 */
bool BoardCan_RecoverIfBusOff(void);

/**
 * @brief  查询 CAN1 当前是否处于 Bus-Off。
 *         Report whether CAN1 is currently in Bus-Off.
 * @param  无 / none.
 * @retval true  Bus-Off 中（外设已脱离总线）/ in Bus-Off.
 * @retval false 未处于 Bus-Off / not in Bus-Off.
 *
 * @note   判据来自 CAN_ESR 寄存器的 BOFF 位，由硬件置位，不受软件状态影响。
 *         The flag comes from the hardware CAN_ESR.BOFF bit.
 */
bool BoardCan_IsBusOff(void);

/**
 * @brief  取 Bus-Off 发生的累计次数，用于判断物理层是否真的有故障。
 *         Read the cumulative Bus-Off counter.
 * @param  无 / none.
 * @retval 自复位以来进入 Bus-Off 的次数 / Bus-Off entries since reset.
 *
 * @note   这个计数器是排查 CAN 物理层问题最直接的软件指标：
 *         - 恒为 0：从未掉过总线，物理层正常；
 *         - 缓慢增长：偶发干扰或终端电阻接触不良；
 *         - 快速持续增长：CANH/CANL 断线/接反、收发器未供电、或总线上没有其它节点。
 *         A fast-growing counter means the physical layer is broken (open or swapped
 *         CANH/CANL, unpowered transceiver, or no other node on the bus).
 */
uint32_t BoardCan_GetBusOffCount(void);

#endif /* BOARD_CAN_H */

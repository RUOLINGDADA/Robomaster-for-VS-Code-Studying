# chassis_control —— 底盘目标速度与 PID 电流输出

## 模块职责

读取 DR16 快照得到四个逻辑转子目标速度，使用 CAN 速度反馈计算四个速度 PID 电流。
模块运行在底盘任务中，依赖 `pid_controller` 和 DBUS 数据类型，不操作 CAN、不使能电机、不创建任务。

## 控制约定

| 数据 | 含义 |
|---|---|
| `ch[2]` | 左右平移 `Vx` |
| `ch[3]` | 前后平移 `Vy` |
| `ch[0]` | 底盘旋转 `ω` |
| `ch[1]` | 云台 Yaw，当前保留 |
| `switch_s1=1` | 原有电机测试模式 |
| `switch_s1=2` | 底盘遥控模式 |
| `switch_s1=2 && switch_s2=2` | 小陀螺模式 |

物理位置的混控公式为：

```text
左前 = Vy + Vx + ω
右前 = Vy - Vx - ω
左后 = Vy - Vx + ω
右后 = Vy + Vx - ω
```

按电调 ID 写入目标数组时的顺序为：1号右前、2号左前、3号左后、4号右后。

正电流代表电机向前旋转，负电流代表向后旋转。上板调试时先分别给 m0、m1、m2、m3
发送正输出确认线序，再检查前进、右移和原地右转。

每个摇杆先应用现有 ±30 死区，混控结果按 ±660 换算为目标转子 rpm，并逐电机限幅：

```text
目标转子 rpm = clamp(混控值 / 660 × 6000, -6000, +6000)
逻辑反馈 rpm = CAN 转子 rpm × 方向系数
误差 rpm = 目标转子 rpm - 逻辑反馈 rpm
逻辑电流原始值 = clamp(PID(误差), -实际限幅, +实际限幅)
CAN 电流原始值 = 逻辑电流原始值 × 方向系数
电流 A ≈ 原始值 × 20 / 16384
轮子 rpm = 逻辑转子 rpm / 减速比
```

用户当前方向系数为 `{-1,+1,+1,-1}`，已保留。最大轮速、减速比尚未确定：6000 rpm是临时
转子目标上限，不是已确认轮速；没有固定的“电流→转速”比例，PID 按负载动态调节电流。
例如单轴通道330对应3000转子 rpm，停转时 Kp=4 给出12000原始值，普通模式最终限幅为4915；
达到目标后比例项降到0，主要由积分提供维持负载所需电流。

默认参数均在头文件集中定义：Kp=4、Ki=2、Kd=0，积分限幅1000原始值，微分低通30 Hz，
倒数变速积分 `1/(1+a|e|)`，a=0.01/rpm。Kp使误差超过约717 rpm时快速进入现有电流上限；
Kd先保留0作为 PI 起调值，微分功能已实现，反馈噪声确认后再调整。所有增益均需实机整定。

摇杆归中表示目标速度0，速度 PID 可输出反向电流刹车；退出控制模式/离线则直接零电流。

小陀螺模式使用 `ChassisControl_UpdateSpin()`：`ch[2]/ch[3]` 先按进入模式时的积分航向角
转换到车体坐标，再与右转目标角速度合成为四轮目标转子 rpm。普通模式理论限幅为 ±2867 raw
（约3.5A），实际限幅为 ±4915 raw（约6A）；小陀螺模式理论限幅为 ±5325 raw（约6.5A），
实际限幅为 ±8192 raw（约10A）。理论限幅只作参考，PID 抗饱和和最终输出只使用实际限幅。
角速度反馈当前由四轮 CAN 转速估算，轮径、轴距、轮距和减速比均为头文件中的可调临时宏。

键盘会话使用 `keyboard` 位掩码生成目标：W/S 为前后、A/D 为左右、Q/E 为逆/顺时针。
键盘模式只在模式管理器开启会话后生效，忽略摇杆和拨杆；相反按键抵消，多个方向可以叠加，
混控后的单轮目标仍限制在 ±6000 rpm。键盘三个轴在混控前使用独立的直线起步和对数后段：
默认 `t1=0.20 s` 直线到达目标的1/3，随后逐渐放缓，到 `t3=1.00 s` 达到100%。
对数基线为 `L(u)=ln(1+k*u)/ln(1+k)`，`u=(t-t1)/(t3-t1)`，默认 `k=4`。
叠加三次端点斜率修正，使直线/对数交界处速度及斜率连续，达到满速时斜率归零。
因此是平滑的对数形曲线，默认在0.40/0.60/0.80 s约达59%/79%/94%，不再经过原来的t2节点。
时间、直线末端比例和对数系数均在头文件定义；调节后应重新验证单调性和过冲。松键立即清零，
直接反向先经过零速；曲线使用任务实际 `dt_s`，模式切换或掉线时清除历史。键盘会话不进入
小陀螺模式；小陀螺仍只由 S1/S2 和摇杆控制。

## 接口

| 接口 | 上下文 | 说明 |
|---|---|---|
| `ChassisControl_Init` | 底盘任务启动 | 初始化四个速度 PID，失败不输出 |
| `ChassisControl_Update` | 底盘任务 | 更新目标转速；离线或非底盘模式时清零和复位 |
| `ChassisControl_UpdateKeyboard` | 键盘普通底盘任务 | 使用键盘位掩码和实际 dt 生成直线/对数目标 |
| `ChassisControl_CalcCurrent` | 底盘任务 | 用逻辑速度反馈和实际 dt 计算电流 |
| `ChassisControl_ResetMotor` | 底盘任务 | 单电机离线时清历史 |
| `ChassisControl_Clear` | 底盘任务/挂起工作任务后的管理任务 | 清目标、反馈观察值和 PID 历史 |
| `ChassisControl_UpdateSpin` | 小陀螺任务 | 大地坐标转换、自转叠加和四轮目标转速 |
| `ChassisControl_SetCurrentLimitsRaw` | 当前工作任务 | 设置理论限幅和实际限幅；实际限幅进入 PID |
| `ChassisControl_SetActualCurrentLimitRaw` | 当前工作任务 | 只更新实际限幅 |
| `g_chassis_target_speed_rpm[4]` | 调试器 / 任务 | 按 ID 1~4 排列的逻辑转子目标 rpm |
| `g_chassis_feedback_speed_rpm[4]` | 调试器 / 任务 | 按 ID 1~4 排列的逻辑转子反馈 rpm |
| `g_chassis_target_current_raw[4]` | 调试器 / 任务 | 按 ID 1~4 排列的 C620 原始目标电流 |
| `g_chassis_theoretical_current_limit_raw` | 调试器 / 任务 | 当前模式理论限幅，只作参考 |
| `g_chassis_actual_current_limit_raw` | 调试器 / 任务 | 当前模式实际限幅，PID/CAN 输出保护 |
| `g_chassis_spin_heading_rad` | 调试器 / 小陀螺任务 | 积分航向角，单位 rad |
| `g_chassis_spin_feedback_omega_rad_s` | 调试器 / 小陀螺任务 | 四轮反馈估算角速度，单位 rad/s |
| `g_chassis_keyboard_command_*` | 调试器 / 底盘任务 | 键盘即时 Vx/Vy/Wz 目标，单位 rpm |
| `g_chassis_keyboard_ramped_*` | 调试器 / 底盘任务 | 曲线处理后的 Vx/Vy/Wz 目标，单位 rpm |

`g_chassis_motors[i].target_current_raw` 是方向变换后等待发送的电流；
`g_chassis_motors[i].feedback.current_raw` 是电调实测原始电流（同协议符号），两者可以直接比较。
全局数组便于调试器逐值观察，volatile不保证多数组原子快照；跨任务读取需先暂停工作任务或另做快照。

验证命令：`powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\verify.ps1`、
`python tools/test_pid.py`。后者覆盖算法、方向、限幅、复位和一阶模型闭环，不能替代实机整定。
曲线约束的是目标转速；实际转速和电流仍由负载及速度 PID 决定，需用 VOFA 对比目标与反馈。

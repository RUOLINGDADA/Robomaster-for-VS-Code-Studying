/**
  ******************************************************************************
  * @file    dr16_dbus.h
  * @brief   DR16 DBUS 接收与解码接口。
  *
  * 本模块只负责串口接收、18 字节帧解码和快照读取，不负责遥控映射、底盘运动学、
  * PID 或电机输出。
  ******************************************************************************
  */

#ifndef DR16_DBUS_H
#define DR16_DBUS_H

#include "stm32f4xx_hal.h"

#include <stdbool.h>
#include <stdint.h>

/** DBUS 一帧固定长度，单位：字节。 */
#define DR16_DBUS_FRAME_LENGTH 18U

/** DR16 遥控通道数量。 */
#define DR16_DBUS_CHANNEL_COUNT 4U

/** 通道原始值中心，协议范围约为 364 ~ 1684。 */
#define DR16_DBUS_CHANNEL_CENTER_RAW 1024

/** 通道原始值最小值，协议单位。 */
#define DR16_DBUS_CHANNEL_MIN_RAW 364U

/** 通道原始值最大值，协议单位。 */
#define DR16_DBUS_CHANNEL_MAX_RAW 1684U

/** 反馈超时阈值，单位：毫秒。 */
#define DR16_DBUS_FEEDBACK_TIMEOUT_MS 100U

/** S1/S2 开关编码：向上。 */
#define DR16_DBUS_SWITCH_UP 1U

/** S1/S2 开关编码：向下。 */
#define DR16_DBUS_SWITCH_DOWN 2U

/** S1/S2 开关编码：中间。 */
#define DR16_DBUS_SWITCH_MIDDLE 3U

/** 键盘位掩码：W 键，前进。 */
#define DR16_DBUS_KEY_W (1U << 0U)
/** 键盘位掩码：S 键，后退。 */
#define DR16_DBUS_KEY_S (1U << 1U)
/** 键盘位掩码：A 键，左平移。 */
#define DR16_DBUS_KEY_A (1U << 2U)
/** 键盘位掩码：D 键，右平移。 */
#define DR16_DBUS_KEY_D (1U << 3U)
/** 键盘位掩码：Shift 键，切换普通底盘键盘会话。 */
#define DR16_DBUS_KEY_SHIFT (1U << 4U)
/** 键盘位掩码：Ctrl 键，当前保留给后续模式扩展。 */
#define DR16_DBUS_KEY_CTRL (1U << 5U)
/** 键盘位掩码：Q 键，逆时针旋转。 */
#define DR16_DBUS_KEY_Q (1U << 6U)
/** 键盘位掩码：E 键，顺时针旋转。 */
#define DR16_DBUS_KEY_E (1U << 7U)

/**
 * @brief DR16 解码后的数据快照。
 *
 * @note channel[] 已减去 1024 中心值，正常范围约为 -660 ~ +660；鼠标坐标为
 *       有符号原始计数，键盘为 16 个按键位掩码。
 */
typedef struct {
  int16_t channel[DR16_DBUS_CHANNEL_COUNT]; /* 中心化通道值 */
  uint8_t switch_s1;                        /* S1：1 上、2 下、3 中 */
  uint8_t switch_s2;                        /* S2：1 上、2 下、3 中 */
  int16_t mouse_x;                          /* 鼠标 X 原始值 */
  int16_t mouse_y;                          /* 鼠标 Y 原始值 */
  int16_t mouse_z;                          /* 鼠标 Z 原始值 */
  uint8_t mouse_left;                       /* 鼠标左键，0/1 */
  uint8_t mouse_right;                      /* 鼠标右键，0/1 */
  uint16_t keyboard;                        /* 键盘位掩码 */
  uint16_t reserved;                        /* 保留字段 */
  uint32_t last_frame_tick;                 /* 最近有效帧时间，单位 ms */
  uint32_t frame_count;                     /* 有效帧累计数 */
  uint32_t error_count;                     /* 无效帧或 UART 错误累计数 */
  bool online;                              /* 最近 100 ms 是否在线 */
} DR16_Dbus_DataTypeDef;

/**
 * @brief 初始化 DR16 DBUS 单接收器。
 * @param  huart 已完成 HAL 初始化的 USART 句柄，当前使用 USART3。
 * @retval true  参数有效并完成内部状态初始化。
 * @retval false 句柄为空或已存在其它接收器。
 * @note   本函数不启动 DMA；请随后调用 DR16_Dbus_Start()。
 */
bool DR16_Dbus_Init(UART_HandleTypeDef *huart);

/**
 * @brief 启动或重启 DBUS 的 DMA 双缓冲和空闲中断接收。
 * @retval true  DMA 已启动。
 * @retval false 尚未初始化或 DMA 配置失败。
 * @note   可由普通初始化代码调用；中断中使用本模块私有的切换路径。
 */
bool DR16_Dbus_Start(void);

/**
 * @brief 复制最近一份 DR16 数据快照。
 * @param  data 输出结构体，不能为 NULL。
 * @retval true  复制成功。
 * @retval false 尚未初始化或参数为空。
 * @note   可在任务或主循环调用；内部使用短临界区，禁止在 ISR 中调用。
 */
bool DR16_Dbus_GetData(DR16_Dbus_DataTypeDef *data);

/**
 * @brief 查询 DBUS 是否在指定毫秒时刻保持在线。
 * @param  now_tick 与 HAL_GetTick() 同源的当前毫秒 tick。
 * @retval true  收到过有效帧且距离未超过 DR16_DBUS_FEEDBACK_TIMEOUT_MS。
 * @retval false 尚未收到有效帧或反馈超时。
 */
bool DR16_Dbus_IsOnline(uint32_t now_tick);

/**
 * @brief 处理 USART3 空闲中断，供 USART3_IRQHandler 调用。
 * @retval 无。
 * @note   仅允许在 USART3 ISR 中调用，不执行阻塞操作和 FreeRTOS 调用。
 */
void DR16_Dbus_OnUartIrq(void);

/**
 * @brief 处理 USART3 DMA/UART 错误并恢复双缓冲接收。
 * @param huart 产生错误的 UART 句柄。
 * @retval 无。
 * @note 由统一 HAL_UART_ErrorCallback 在中断上下文调用，不打印、不阻塞。
 */
void DR16_Dbus_OnUartError(UART_HandleTypeDef *huart);

#endif /* DR16_DBUS_H */

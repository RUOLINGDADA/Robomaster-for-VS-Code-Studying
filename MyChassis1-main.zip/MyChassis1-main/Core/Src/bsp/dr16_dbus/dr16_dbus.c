/**
  ******************************************************************************
  * @file    dr16_dbus.c
  * @brief   DR16 DBUS USART3 DMA 双缓冲接收和 18 字节协议解码实现。
  *
  * 硬件接口为 USART3_RX，串口参数为 100 kbit/s、8E1；DBUS 电平反相由板级硬件完成。
  * DMA 使用 M0/M1 两块缓冲区，USART 空闲中断切换缓冲区并提交完整帧。
  * 本文件不创建任务、不打印日志、不把遥控量直接绑定到电机驱动。
  ******************************************************************************
  */

#include "bsp/dr16_dbus/dr16_dbus.h"

#include <string.h>

/** 每块 DMA 缓冲区长度，单位：字节；大于一帧以避免一帧结束时自动翻转 CT。 */
#define DR16_DBUS_DMA_BUFFER_LENGTH 36U

static UART_HandleTypeDef *g_dr16_dbus_uart;
static uint8_t g_dr16_dbus_rx_buffer[2][DR16_DBUS_DMA_BUFFER_LENGTH];
/* 中断写入、任务读取的共享快照；volatile 保证跨上下文访问可见。 */
static volatile DR16_Dbus_DataTypeDef g_dr16_dbus_data;
static bool g_dr16_dbus_initialized;

static int16_t DR16_Dbus_ReadI16Le(const uint8_t *data) {
  const uint16_t raw = (uint16_t)data[0] | ((uint16_t)data[1] << 8U);
  return (int16_t)raw;
}

static bool DR16_Dbus_Decode(const uint8_t frame[DR16_DBUS_FRAME_LENGTH],
                             DR16_Dbus_DataTypeDef *data) {
  const uint16_t channel_raw[DR16_DBUS_CHANNEL_COUNT] = {
      (uint16_t)(((uint16_t)frame[0] | ((uint16_t)frame[1] << 8U)) & 0x07FFU),
      (uint16_t)((((uint16_t)frame[1] >> 3U) |
                  ((uint16_t)frame[2] << 5U)) & 0x07FFU),
      (uint16_t)((((uint16_t)frame[2] >> 6U) |
                  ((uint16_t)frame[3] << 2U) |
                  ((uint16_t)frame[4] << 10U)) & 0x07FFU),
      (uint16_t)((((uint16_t)frame[4] >> 1U) |
                  ((uint16_t)frame[5] << 7U)) & 0x07FFU)};
  const uint8_t switch_s1 = (uint8_t)((frame[5] >> 4U) & 0x03U);
  const uint8_t switch_s2 = (uint8_t)((frame[5] >> 6U) & 0x03U);

  /* DBUS 没有帧头，先检查通道和拨杆，避免错位数据进入控制逻辑。 */
  for (uint32_t i = 0U; i < DR16_DBUS_CHANNEL_COUNT; i++) {
    if (channel_raw[i] < DR16_DBUS_CHANNEL_MIN_RAW ||
        channel_raw[i] > DR16_DBUS_CHANNEL_MAX_RAW) {
      return false;
    }
  }
  if ((switch_s1 < DR16_DBUS_SWITCH_UP || switch_s1 > DR16_DBUS_SWITCH_MIDDLE) ||
      (switch_s2 < DR16_DBUS_SWITCH_UP || switch_s2 > DR16_DBUS_SWITCH_MIDDLE)) {
    return false;
  }

  memset(data, 0, sizeof(*data));
  for (uint32_t i = 0U; i < DR16_DBUS_CHANNEL_COUNT; i++) {
    data->channel[i] = (int16_t)channel_raw[i] - DR16_DBUS_CHANNEL_CENTER_RAW;
  }
  data->switch_s1 = switch_s1;
  data->switch_s2 = switch_s2;
  data->mouse_x = DR16_Dbus_ReadI16Le(&frame[6]);
  data->mouse_y = DR16_Dbus_ReadI16Le(&frame[8]);
  data->mouse_z = DR16_Dbus_ReadI16Le(&frame[10]);
  data->mouse_left = frame[12];
  data->mouse_right = frame[13];
  data->keyboard = (uint16_t)frame[14] | ((uint16_t)frame[15] << 8U);
  data->reserved = (uint16_t)frame[16] | ((uint16_t)frame[17] << 8U);
  return true;
}

static void DR16_Dbus_RecordFrame(const uint8_t *frame) {
  DR16_Dbus_DataTypeDef decoded = {0};
  if (!DR16_Dbus_Decode(frame, &decoded)) {
    g_dr16_dbus_data.error_count++;
    return;
  }
  decoded.last_frame_tick = HAL_GetTick();
  decoded.frame_count = g_dr16_dbus_data.frame_count + 1U;
  decoded.error_count = g_dr16_dbus_data.error_count;
  decoded.online = true;
  g_dr16_dbus_data = decoded;
}

static bool DR16_Dbus_RestartRx(void) {
  if (!g_dr16_dbus_initialized || g_dr16_dbus_uart == NULL ||
      g_dr16_dbus_uart->hdmarx == NULL) {
    return false;
  }
  DMA_HandleTypeDef *const hdma = g_dr16_dbus_uart->hdmarx;

  /* 先停 DMA，再同时装载 M0/M1、计数器和当前目标缓冲区。 */
  __HAL_DMA_DISABLE(hdma);
  while ((hdma->Instance->CR & DMA_SxCR_EN) != 0U) {
    __HAL_DMA_DISABLE(hdma);
  }
  hdma->Instance->PAR = (uint32_t)&g_dr16_dbus_uart->Instance->DR;
  hdma->Instance->M0AR = (uint32_t)g_dr16_dbus_rx_buffer[0];
  hdma->Instance->M1AR = (uint32_t)g_dr16_dbus_rx_buffer[1];
  hdma->Instance->NDTR = DR16_DBUS_DMA_BUFFER_LENGTH;
  /* 每次重启都从 M0 开始，避免错误恢复后沿用上一次的 CT 位。 */
  hdma->Instance->CR &= ~DMA_SxCR_CT;
  hdma->Instance->CR |= DMA_SxCR_DBM | DMA_SxCR_CIRC;
  SET_BIT(g_dr16_dbus_uart->Instance->CR3, USART_CR3_DMAR);
  __HAL_UART_CLEAR_IDLEFLAG(g_dr16_dbus_uart);
  __HAL_UART_ENABLE_IT(g_dr16_dbus_uart, UART_IT_IDLE);
  __HAL_DMA_ENABLE(hdma);
  return true;
}

bool DR16_Dbus_Init(UART_HandleTypeDef *huart) {
  if (huart == NULL || g_dr16_dbus_initialized) {
    return false;
  }
  g_dr16_dbus_uart = huart;
  memset(g_dr16_dbus_rx_buffer, 0, sizeof(g_dr16_dbus_rx_buffer));
  const DR16_Dbus_DataTypeDef initial_data = {0};
  g_dr16_dbus_data = initial_data;
  g_dr16_dbus_initialized = true;
  return true;
}

bool DR16_Dbus_Start(void) { return DR16_Dbus_RestartRx(); }

bool DR16_Dbus_GetData(DR16_Dbus_DataTypeDef *data) {
  if (!g_dr16_dbus_initialized || data == NULL) {
    return false;
  }
  const uint32_t saved_primask = __get_PRIMASK();
  __disable_irq();
  *data = g_dr16_dbus_data;
  const uint32_t now_tick = HAL_GetTick();
  //AAA DR16遥控器在线状态读取
  data->online = g_dr16_dbus_data.frame_count > 0U &&
                 (now_tick - g_dr16_dbus_data.last_frame_tick) <=
                     DR16_DBUS_FEEDBACK_TIMEOUT_MS;
  __set_PRIMASK(saved_primask);
  return true;
}

bool DR16_Dbus_IsOnline(uint32_t now_tick) {
  if (!g_dr16_dbus_initialized) {
    return false;
  }
  const uint32_t saved_primask = __get_PRIMASK();
  __disable_irq();
  const bool online = g_dr16_dbus_data.frame_count > 0U &&
                      (now_tick - g_dr16_dbus_data.last_frame_tick) <=
                          DR16_DBUS_FEEDBACK_TIMEOUT_MS;
  __set_PRIMASK(saved_primask);
  return online;
}

void DR16_Dbus_OnUartIrq(void) {
  if (!g_dr16_dbus_initialized || g_dr16_dbus_uart == NULL ||
      __HAL_UART_GET_FLAG(g_dr16_dbus_uart, UART_FLAG_IDLE) == RESET) {
    return;
  }

  __HAL_UART_CLEAR_IDLEFLAG(g_dr16_dbus_uart);
  DMA_HandleTypeDef *const hdma = g_dr16_dbus_uart->hdmarx;
  const uint32_t current_target = hdma->Instance->CR & DMA_SxCR_CT;
  const uint16_t received_length =
      (uint16_t)(DR16_DBUS_DMA_BUFFER_LENGTH - hdma->Instance->NDTR);

  /* 停止当前 DMA，保存已接收的缓冲区，再把 DMA 切换到另一块。 */
  __HAL_DMA_DISABLE(hdma);
  while ((hdma->Instance->CR & DMA_SxCR_EN) != 0U) {
    __HAL_DMA_DISABLE(hdma);
  }
  hdma->Instance->NDTR = DR16_DBUS_DMA_BUFFER_LENGTH;
  if (current_target == 0U) {
    hdma->Instance->CR |= DMA_SxCR_CT;
  } else {
    hdma->Instance->CR &= ~DMA_SxCR_CT;
  }
  __HAL_DMA_ENABLE(hdma);

  if (received_length == DR16_DBUS_FRAME_LENGTH) {
    DR16_Dbus_RecordFrame(g_dr16_dbus_rx_buffer[current_target == 0U ? 0U : 1U]);
  } else {
    g_dr16_dbus_data.error_count++;
  }
}

/**
  * @brief 处理 USART3 的串口错误并恢复 DMA 双缓冲接收。
  * @param huart 产生错误的串口句柄。
  * @retval 无。
  * @note 运行在 USART ISR，不打印、不阻塞、不调用 FreeRTOS 接口。
  */
void DR16_Dbus_OnUartError(UART_HandleTypeDef *huart) {
  if (!g_dr16_dbus_initialized || huart != g_dr16_dbus_uart) {
    return;
  }
  g_dr16_dbus_data.error_count++;
  (void)DR16_Dbus_RestartRx();
}

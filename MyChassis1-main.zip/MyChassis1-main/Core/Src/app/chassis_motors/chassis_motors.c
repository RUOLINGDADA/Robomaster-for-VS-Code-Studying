/**
  ******************************************************************************
  * @file    chassis_motors.c
  * @brief   底盘四个 M3508 电机的公共注册、反馈和停止实现。
  *
  * 本文件只连接应用任务与已有的 CAN/M3508 驱动，不实现测试波形、遥控混控或 PID。
  * CAN FIFO 回调运行在中断中，只取帧和解码，不打印、不阻塞。
  ******************************************************************************
  */

#include "app/chassis_motors/chassis_motors.h"

#include "bsp/board_can/board_can.h"
#include "can.h"

#include <stdint.h>

/** 四个电机句柄必须使用静态存储，注册表会在中断中长期保存它们的地址。 */
C620_M3508_HandleTypeDef g_chassis_motors[CHASSIS_MOTORS_COUNT];

/**
 * 电机安装方向修正：2、3号正号保持不变，1、4号安装方向相反需要取反。
 * 数组下标对应电调 ID 减一，避免把物理方向判断散落在各个控制任务中。
 */
static const int8_t g_chassis_current_sign[CHASSIS_MOTORS_COUNT] = {
    -1, 1, 1, -1}; /* 保留用户实测方向：ID1/4反相，ID2/3同相。 */

bool ChassisMotors_Init(void) {
  /* 数组下标与电调 ID 一一对应：1右前、2左前、3左后、4右后。 */
  const uint8_t motor_ids[CHASSIS_MOTORS_COUNT] = {1U, 2U, 3U, 4U};
  for (uint32_t i = 0U; i < CHASSIS_MOTORS_COUNT; i++) {
    const C620_M3508_ConfigTypeDef config = {
        .hcan = &hcan1,
        .motor_id = motor_ids[i],
        .feedback_timeout_ms = C620_M3508_FEEDBACK_TIMEOUT_MS,
    };
    if (!C620_M3508_Init(&g_chassis_motors[i], &config)) {
      return false;
    }
  }
  ChassisMotors_StopAll();
  return true;
}

void ChassisMotors_Process(uint32_t now_tick) {
  for (uint32_t i = 0U; i < CHASSIS_MOTORS_COUNT; i++) {
    (void)C620_M3508_Process(&g_chassis_motors[i], now_tick);
  }
}

bool ChassisMotors_SetCurrent(uint32_t motor_index,
                              int16_t logical_current_raw) {
  if (motor_index >= CHASSIS_MOTORS_COUNT) {
    return false;
  }
  const int32_t physical_current_raw =
      (int32_t)logical_current_raw * g_chassis_current_sign[motor_index];
  return C620_M3508_SetCurrent(&g_chassis_motors[motor_index],
                               (int16_t)physical_current_raw);
}

void ChassisMotors_StopAll(void) {
  for (uint32_t i = 0U; i < CHASSIS_MOTORS_COUNT; i++) {
    (void)C620_M3508_SetOutputEnabled(&g_chassis_motors[i], false);
    (void)ChassisMotors_SetCurrent(i, 0);
  }
}

bool ChassisMotors_GetSpeedRpm(uint32_t motor_index, float *speed_rpm) {
  if (speed_rpm == NULL) {
    return false;
  }
  *speed_rpm = 0.0f;
  C620_M3508_FeedbackTypeDef feedback = {0};
  if (motor_index >= CHASSIS_MOTORS_COUNT ||
      !C620_M3508_IsOnline(&g_chassis_motors[motor_index]) ||
      !C620_M3508_GetFeedback(&g_chassis_motors[motor_index], &feedback)) {
    return false;
  }
  /* 在浮点域反相，INT16_MIN 不会因整数取反回绕；负反馈必须和目标处在同一坐标系。 */
  *speed_rpm = (float)feedback.speed_rpm * g_chassis_current_sign[motor_index];
  return true;
}

bool ChassisMotors_GetCurrentA(uint32_t motor_index, float *current_a) {
  if (current_a == NULL) {
    return false;
  }
  *current_a = 0.0f;
  C620_M3508_FeedbackTypeDef feedback = {0};
  if (motor_index >= CHASSIS_MOTORS_COUNT ||
      !C620_M3508_IsOnline(&g_chassis_motors[motor_index]) ||
      !C620_M3508_GetFeedback(&g_chassis_motors[motor_index], &feedback)) {
    return false;
  }
  const int8_t direction = g_chassis_current_sign[motor_index];
  *current_a = (float)feedback.current_raw * (float)direction *
               (20.0f / 16384.0f);
  return true;
}

bool ChassisMotors_Send(void) { return C620_M3508_SendAll(&hcan1); }

/**
  * @brief 处理 CAN1 FIFO0 接收中断。
  * @param hcan HAL CAN 句柄。
  * @retval 无。
  * @note 只处理 CAN1；运行在 CAN1_RX0 中断中，不打印、不阻塞。
  */
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan) {
  if (hcan == &hcan1) {
    (void)BoardCan_PollRxFifo0();
  }
}

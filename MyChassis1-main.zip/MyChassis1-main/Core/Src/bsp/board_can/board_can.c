/**
  ******************************************************************************
  * @file    board_can.c
  * @brief   底盘 CAN 板级实现：过滤器配置、外设启动、FIFO 轮询入口。
  *          Board-level CAN implementation: filter setup, start-up, FIFO polling.
  *
  * 硬件前提 / Hardware assumptions:
  *   - CAN1：PD0 = CAN1_RX，PD1 = CAN1_TX，位时序由 CubeMX 配置为 1 Mbit/s。
  *     CAN1 uses PD0/PD1 with 1 Mbit/s bit timing configured by CubeMX.
  *   - 底盘 M3508 电调全部挂在 CAN1 上，反馈 ID 为 0x201 ~ 0x208。
  *     All chassis M3508 ESCs sit on CAN1 and reply with IDs 0x201 ~ 0x208.
  *
  * 运行上下文 / Execution context:
  *   BoardCan_Init() 在调度器启动前或任务中调用一次；BoardCan_PollRxFifo0()
  *   在 CAN1_RX0 中断中被调用，因此本文件的接收路径不得阻塞或打印。
  *   BoardCan_Init() runs once; BoardCan_PollRxFifo0() runs in the CAN1_RX0 ISR.
  ******************************************************************************
  */

#include "bsp/board_can/board_can.h"

#include "bsp/m3508_c620/m3508_c620.h"
#include "can.h"

/**
 * @brief  配置 CAN1 的接收过滤器，只放行底盘电机反馈帧。
 *         Configure the CAN1 acceptance filter to admit chassis feedback only.
 * @param  无 / none.
 * @retval true  过滤器已被 HAL 接受 / the filter was accepted by HAL.
 * @retval false hcan1 尚未初始化或 HAL 配置失败 / hcan1 not ready or HAL failed.
 *
 * @note   过滤器改为静态函数是刻意的：过滤器分组是板级资源，C620 驱动不应
 *         知道自己占用了几号过滤器，否则更换总线或增加设备就要改驱动。
 *         Kept static on purpose: filter banking is a board resource and the motor
 *         driver must not depend on it.
 */
static bool BoardCan_ConfigureFilters(void) {
  CAN_FilterTypeDef filter = {0};

  /*
   * 过滤器设计：一条“ID + 掩码”过滤器即可覆盖底盘全部反馈 ID。
   *
   * 匹配值 0x200，掩码 0x7F8。掩码为 1 的位参与比较，为 0 的位“不关心”：
   *   0x7F8 = 0b0111_1111_1000，低 3 位被忽略，
   *   于是 (StdId & 0x7F8) == 0x200 接纳 0x200 ~ 0x207 共 8 个 ID。
   * 本工程使用电调 ID 1 ~ 4（反馈 0x201 ~ 0x204），完全落在该区间内；
   * 将来扩到 ID 8 时掩码需要重新规划成两段区间（例如掩码 0x7F0），
   * 因为 0x208 的低 3 位非 0，无法被同一个掩码同时覆盖。
   * The mask admits 0x200 ~ 0x207, which covers ESC IDs 1 ~ 7 (this project uses
   * 1 ~ 4). Extending to ID 8 requires re-planning the mask, because 0x208 has
   * non-zero low bits and cannot share this single mask.
   *
   * 注意 0x200 本身是广播控制帧、不会由电调发出，被过滤器放过也无害：
   * C620_M3508_HandleRxMessage() 会用 StdId > 0x200 的条件丢弃它。
   * Letting the broadcast ID 0x200 through is harmless: the driver drops it.
   */
  filter.FilterMode = CAN_FILTERMODE_IDMASK;      /* ID + 掩码模式 / ID+mask mode. */
  filter.FilterScale = CAN_FILTERSCALE_32BIT;     /* 32 位尺度，一个组装一条规则. */
  filter.FilterIdHigh = (uint16_t)(C620_M3508_FILTER_ID << 5U);
  filter.FilterIdLow = 0x0000U;
  filter.FilterMaskIdHigh = (uint16_t)(C620_M3508_FILTER_MASK << 5U);
  filter.FilterMaskIdLow = 0x0000U;
  filter.FilterFIFOAssignment = CAN_RX_FIFO0;     /* 反馈统一进入 FIFO0. */
  filter.FilterBank = 0U;                         /* CAN1 用 0 号过滤器 / CAN1 uses bank 0. */
  filter.FilterActivation = ENABLE;

  /*
   * SlaveStartFilterBank 是本函数里最容易踩的坑，必须说清楚。
   *
   * 双 CAN 实例（本芯片有 CAN1 + CAN2）时，HAL_CAN_ConfigFilter() 内部会走
   * stm32f4xx_hal_can.c 的 `#elif defined(CAN2)` 分支，执行：
   *     SET_BIT(CAN1->FMR, sFilterConfig->SlaveStartFilterBank << CAN_FMR_CAN2SB_Pos);
   * 也就是说：**这里填的值会直接决定 CAN_FMR.CAN2SB 这个“CAN2 从第几号 bank 开始”
   * 的分界字段。** bank 号小于该值的过滤器归 CAN1（主），大于等于的归 CAN2（从）。
   *
   * 本工程只用 CAN1、不启动 CAN2，因此必须填 0：
   *   - 填 14（CubeMX 给 hcan1.Init.SlaveStartFilterBank 的默认值）会把
   *     bank 14 ~ 27 全部划给一个根本没启动的 CAN2，白白浪费一半过滤器；
   *   - 更隐蔽的是，hcan1.Init.SlaveStartFilterBank 在 HAL_CAN_Init() 里
   *     **根本不会被读取**（HAL 只认过滤器结构体里的这一个），所以照着
   *     CubeMX 的 Init 结构体抄这个值是完全错误的来源。
   * 将来接入 CAN2（云台）时再改这里，并同步规划两边的 bank 划分。
   *
   * On dual-CAN parts this value writes CAN_FMR.CAN2SB and defines which filter
   * banks belong to CAN2. With CAN2 unused it must be 0; copying CubeMX's
   * hcan1.Init.SlaveStartFilterBank is wrong because HAL_CAN_Init() never reads it.
   */
  filter.SlaveStartFilterBank = 0U;

  return HAL_CAN_ConfigFilter(&hcan1, &filter) == HAL_OK;
}

bool BoardCan_Init(void) {
  /*
   * 顺序不能交换：
   *   1. 先配过滤器 —— HAL 规定只能在 CAN 处于初始化状态时修改过滤器组；
   *   2. 再 HAL_CAN_Start() —— 让外设进入 LISTENING 并参与总线仲裁；
   *   3. 最后激活 FIFO0 pending 中断 —— 此时才有必要开始响应接收事件。
   * 若先启动再配过滤器，HAL_CAN_ConfigFilter() 会直接返回错误，
   * 而如果把第 3 步提前，中断可能在过滤器还没配好时就被触发。
   * Order matters: filters are writable only in initialisation mode, so configure
   * them before starting, and enable the RX notification last.
   */
  if (!BoardCan_ConfigureFilters()) {
    return false;
  }

  if (HAL_CAN_Start(&hcan1) != HAL_OK) {
    return false;
  }

  /*
   * CAN_IT_RX_FIFO0_MSG_PENDING：FIFO0 中一旦出现新报文就置位中断，
   * HAL_CAN_IRQHandler() 随后调用 HAL_CAN_RxFifo0MsgPendingCallback()。
   * 该回调由应用层定义（见 task_m3508_can_test.c），使能位必须在这里打开，
   * 否则中断不会到达回调。
   * Enabling this interrupt source is what makes HAL invoke
   * HAL_CAN_RxFifo0MsgPendingCallback().
   */
  if (HAL_CAN_ActivateNotification(&hcan1,
                                   CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK) {
    /*
     * 中断激活失败时总线已经启动，为了避免“能发不能收”的静默故障，
     * 主动停止外设并返回失败，让上层明确看到初始化未完成。
     * Stop the peripheral so a send-only half-initialised CAN cannot run silently.
     */
    (void)HAL_CAN_Stop(&hcan1);
    return false;
  }

  return true;
}

bool BoardCan_PollRxFifo0(void) {
  /*
   * 直接转发给 C620 驱动：板级层只负责“哪个 FIFO 属于谁的协议”，
   * 不解析 DATA 字节，保持协议知识集中在 bsp/m3508_c620 一处。
   * The board layer only routes the FIFO; protocol knowledge stays in the driver.
   */
  return C620_M3508_RxFifoCallback(&hcan1, CAN_RX_FIFO0);
}

/* ---------------------------------------------------------------------------
 * Bus-Off 检测与恢复 / Bus-Off detection and recovery
 * ------------------------------------------------------------------------- */

/** 自复位以来 CAN1 进入 Bus-Off 的累计次数，用于区分“外设被摘除”和“物理层坏”。
 *  Cumulative Bus-Off count since reset, used to tell a latched peripheral apart
 *  from a genuinely broken physical layer. */
static uint32_t g_can1_busoff_count;

/**
 * Bus-Off 去抖窗口，单位：毫秒。
 * Bus-Off debounce window in milliseconds.
 *
 * 本函数由任务每 2 ms 调用一次。如果一看到 BOFF 就立刻重配外设，会有两个问题：
 *   1. 一次瞬态干扰造成的短暂 Bus-Off 本来能自愈，我们却白做了一次 Stop/Start
 *      （期间必然丢帧）；
 *   2. 物理层真正坏掉时，外设会以约每秒一次的节奏反复 Bus-Off，于是每秒都重配
 *      一次寄存器，纯属浪费。
 * 因此要求 Bus-Off 状态**连续稳定存在**超过该窗口才动手恢复。100 ms 相对 Can
 * 总线的一次 Bus-Off（约 32 帧发不出去，本工程 2 ms 周期下约 64 ms）足够长，
 * 又远小于人眼能感知的“卡顿”。
 * Require the flag to be stably set for this long before acting, so a transient
 * Bus-Off can self-heal and a broken physical layer is not reconfigured every second.
 */
#define BOARD_CAN_BUSOFF_DEBOUNCE_MS 100U

/** 首次观测到 Bus-Off 的 tick；为 0 表示当前未处于“持续 Bus-Off”状态。 */
static uint32_t g_can1_busoff_since_tick;

bool BoardCan_IsBusOff(void) {
  /*
   * 判据用硬件寄存器而不是软件状态：CAN_ESR 的 BOFF 位由硬件在 TEC 溢出时置位，
   * 软件任何状态变量都可能和它不同步。
   * Use the hardware flag; any software mirror could fall out of sync.
   */
  return (hcan1.Instance->ESR & CAN_ESR_BOFF) != 0U;
}

uint32_t BoardCan_GetBusOffCount(void) { return g_can1_busoff_count; }

bool BoardCan_RecoverIfBusOff(void) {
  const uint32_t now_ms = HAL_GetTick();

  if (!BoardCan_IsBusOff()) {
    /* 总线正常：清掉去抖计时，下次掉线重新开始计时。 */
    g_can1_busoff_since_tick = 0U;
    return false;
  }

  /*
   * 去抖：第一次看到 Bus-Off 只记录时刻，不立刻恢复。
   * 用无符号减法算已持续时间，天然处理 HAL tick 回绕。
   * Debounce: record the first sighting and only act once it has persisted.
   */
  if (g_can1_busoff_since_tick == 0U) {
    g_can1_busoff_since_tick = now_ms;
    return false;
  }
  if ((now_ms - g_can1_busoff_since_tick) < BOARD_CAN_BUSOFF_DEBOUNCE_MS) {
    return false;
  }

  /* 已经持续够久，认定为真 Bus-Off，开始恢复；计时清零以便下一轮重新判定。 */
  g_can1_busoff_since_tick = 0U;

  /*
   * 每执行一次恢复就计数一次。这个计数器的用法：
   *   - 恒为 0        -> 物理层一直正常；
   *   - 只增长一次     -> 曾经掉线，之后被本函数救回来且没再掉（物理层已恢复）；
   *   - 持续快速增长   -> 物理层仍然坏，恢复后很快又掉，属于接线/收发器问题。
   * Count every recovery so a fast-growing counter reveals an unrepaired physical
   * layer. A steady ~1 Hz growth with REC == 0 means nothing ever ACKs us.
   */
  g_can1_busoff_count++;

  /*
   * 恢复流程：Stop -> 重新配过滤器 -> Start -> 重新挂接收中断。
   *
   * 为什么必须 Stop 再 Start，而不是只清 ESR：
   *   进入 Bus-Off 后 bxCAN 会强制把 CAN_MCR.INRQ 置 1（回到初始化模式）并停止
   *   参与总线。HAL 的状态机也仍停在 LISTENING，不 Stop 就直接 Start 会被 HAL
   *   的 state 断言挡下。走一遍完整的 Stop/Start 既清掉硬件状态，也让 HAL 状态机
   *   回到一致的状态。
   * A plain ESR write is not enough: bxCAN latches INRQ and HAL still believes it is
   * LISTENING, so a full Stop/Start cycle is required to realign both.
   *
   * 注意恢复后过滤器会丢失（HAL_CAN_Stop 会把外设复位到初始化模式，
   * 而过滤器组在初始化模式之外不可修改），因此这里必须重新配置过滤器并重新
   * 激活接收中断，否则会出现“恢复了但永远收不到帧”的更隐蔽故障。
   * Filters must be re-installed after Stop: without this the peripheral returns to
   * the bus but silently never receives anything again.
   */
  if (HAL_CAN_Stop(&hcan1) != HAL_OK) {
    return true; /* 已计数；下一周期再试 / counted; retry on the next period. */
  }
  if (!BoardCan_ConfigureFilters()) {
    return true;
  }
  if (HAL_CAN_Start(&hcan1) != HAL_OK) {
    return true;
  }
  (void)HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING);
  return true;
}

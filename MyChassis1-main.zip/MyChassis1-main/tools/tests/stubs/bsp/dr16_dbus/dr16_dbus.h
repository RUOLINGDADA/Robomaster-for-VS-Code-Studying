/* 主机数值测试专用：只提供底盘算法依赖的数据，不模拟 UART 或中断。 */
#ifndef TEST_DR16_DBUS_H
#define TEST_DR16_DBUS_H
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#define DR16_DBUS_SWITCH_DOWN 2U /* 底盘模式开关编码 */
#define DR16_DBUS_KEY_W (1U << 0U)
#define DR16_DBUS_KEY_S (1U << 1U)
#define DR16_DBUS_KEY_A (1U << 2U)
#define DR16_DBUS_KEY_D (1U << 3U)
#define DR16_DBUS_KEY_SHIFT (1U << 4U)
#define DR16_DBUS_KEY_CTRL (1U << 5U)
#define DR16_DBUS_KEY_Q (1U << 6U)
#define DR16_DBUS_KEY_E (1U << 7U)
typedef struct {
  int16_t channel[4];
  uint8_t switch_s1;
  uint8_t switch_s2;
  uint16_t keyboard;
  bool online;
} DR16_Dbus_DataTypeDef;
#endif

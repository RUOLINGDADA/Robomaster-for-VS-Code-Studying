# MyChassis1 工程上下文

## 当前边界

- 本文档对应目录：`D:\CubeMxProject\MyChassis1`。
- 参考工程：`D:\CubeMxProject\test\Robomaster-for-VS-Code-Studying\yuntai\yuntai`。
  它提供目录结构、模块拆分、注释层次和 CubeMX + FreeRTOS + CMake 的工程组织方式，是
  **风格参考**，不是本工程的构建输入，也不属于本工程修改范围。
- 参考文档：RoboMaster 开发板 C 型嵌入式软件教程、C620 电调说明书、M3508 电机说明书。

## 已确认的工程状态

- MCU：STM32F407IGH6，封装 UFBGA176（RoboMaster 开发板 C 型）。
- 时钟：HSI 16 MHz 经 PLL 倍频到 SYSCLK 168 MHz；APB1 = 42 MHz，APB2 = 84 MHz。
  注意 `.ioc` 中 `RCC.HSE_VALUE = 12000000`，但 `SystemClock_Config()` 当前使用 **HSI** 作为
  PLL 源（`RCC_PLLSOURCE_HSI`，PLLM=8）。CAN 波特率依赖 APB1 时钟，确认时以实际生成的
  `main.c` 为准。
- RTOS：FreeRTOS + CMSIS-RTOS V2；`configTICK_RATE_HZ = 1000`，
  `configTOTAL_HEAP_SIZE = 15360` 字节（heap_4）。
- 构建：CMake + Ninja，工程名 `MyChassis1`，预设 `Debug` / `Release`。
- CubeMX 生成的初始化包含 `MX_GPIO_Init()`、`MX_CAN1_Init()`、`MX_CAN2_Init()` 和
  `MX_FREERTOS_Init()`。

## 已确认的硬件资源

| 外设 | 引脚 | 用途 | 状态 |
|---|---|---|---|
| CAN1 | PD0 = RX，PD1 = TX | 底盘 M3508（C620 电调） | 1 Mbit/s，已配过滤器并启动 |
| CAN2 | PB5 = RX，PB6 = TX | 云台电机 | 已初始化，未配过滤器、未启动 |
| USART3 | PC11 RX / PC10 TX | DR16 DBUS 接收 | 100 kbit/s；运行时设为 8E1 + DMA，见 `bsp/dr16_dbus` |
| USART1 | PB7 RX / PA9 TX | 蓝牙 VOFA 调试 | 9600 baud、8N1；DMA2 Stream2 RX / Stream7 TX |
| SWD | PA13 / PA14 | 调试下载 | — |

### 调试日志当前不可用（重要）

本工程任务层使用 `printf()` 输出状态，但 USART3 已被 DR16 DBUS 接收占用，不能同时当作普通日志口：

- 日志没有单独的 USART 配置；USART3 的 PC11 RX/PC10 TX 用于 DR16 DBUS，USART1 的 PB7/PA9
  用于 VOFA 调参和波形；
- CubeMX 生成的 `Core/Src/syscalls.c` 中，`_write()` 会把每个字节交给
  `__io_putchar()`，而 `__io_putchar()` 只有 `__attribute__((weak))` 声明
  （`syscalls.c:35`），全工程没有强定义实现；
- 其结果是 `printf()` 正常返回、不报错，但**所有字符被静默丢弃**。

因此当前状态下的调试手段是：调试器查看 `g_chassis_motors[]`、`g_c620_m3508_slots[]`
等变量的实时值，而不是串口日志。

USART1 已用于独立 VOFA 调试任务：JustFloat 波形和二进制 PID 调参协议见对应任务实现；
它不承载 `printf()` 日志。

要让日志生效，需要另选调试通道：

1. 在 CubeMX 中另启用一个 USART 并重新生成代码，然后实现 `__io_putchar()`；或
2. 使用 SWO/ITM 或 RTT 实现 `__io_putchar()`，不占用 USART3 DBUS 资源。

在完成上述任一步骤之前，任务里的 `printf` 语句是**无害但无输出**的，可以保留不动。


CAN1 位时序（CubeMX 生成）：`Prescaler = 3`、`SJW = 1TQ`、`BS1 = 10TQ`、`BS2 = 3TQ`，
时间份额 = 1 + 10 + 3 = 14 TQ。在 APB1 = 42 MHz 下，
波特率 = 42 MHz / (3 × 14) = **1 Mbit/s**，与 RoboMaster 电调要求一致。

## 目标架构

```text
HAL / CubeMX 生成代码
        ↑
板级层 bsp/board_can        （过滤器、外设启动、FIFO 路由：认引脚和外设）
设备驱动层 bsp/m3508_c620    （CAN 协议帧解析与打包：只认协议）
设备驱动层 bsp/dr16_dbus     （USART3 DBUS 帧接收与解码：只认协议）
应用算法 app/pid_controller （单环 PID 与位置-速度级联 PID，不依赖硬件）
应用层 app/chassis_control  （摇杆死区、四轮目标转速、速度 PID 电流限幅）
        ↑
应用任务层 app/*            （调度、反馈采样、遥控映射、周期发送）
```

约束：

- 驱动不创建任务、不阻塞、不打印。
- 应用层不直接操作 CAN 寄存器，也不直接拼装协议字节。
- 中断只做取帧、解码、打时间戳；控制决策放任务。

## 参考代码边界

底盘数组下标0~3对应电调 ID1~4（右前、左前、左后、右后）。用户目前的方向系数为
`{-1,+1,+1,-1}`，输出电流和速度反馈使用同一张表；协议反馈中的 rpm 是转子速度。
最大轮速和减速比未确认，当前临时目标上限是 6000 转子 rpm，不声明为轮子 rpm。
电流由速度 PID 计算。普通模式理论限幅为 ±2867（约 ±3.5 A），实际 PID/CAN 输出限幅为
±4915（约 ±6 A）；小陀螺模式理论限幅为 ±5325（约 ±6.5 A），实际限幅为 ±8192（约 ±10 A）。
理论限幅只用于参考，PID 抗饱和和最终输出只使用实际限幅。

参考工程 `yuntai` 中的 `c610_m2006` 驱动展示了静态注册表、聚合控制帧和 CAN 回调的写法。
本工程只采用其中与本任务直接相关的部分：静态注册表、大小端处理、聚合发送、超时保护。
没有明确用途的错误枚举、日志封装和额外状态层不复制。M3508/C620 与 M2006/C610 的协议帧
格式相同，但电压等级、减速比、额定电流和转速范围不同，参数不能互相照搬。

## 交付要求

每次改动都要说明：改动文件、公开接口、任务/中断上下文、硬件假设、构建或静态检查结果、
未验证风险和后续问题。需求未明确时写入 `OPEN_QUESTIONS.md` 并在回复中直接询问。

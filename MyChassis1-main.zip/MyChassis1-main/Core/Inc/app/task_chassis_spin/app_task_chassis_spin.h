/**
  ******************************************************************************
  * @file    app_task_chassis_spin.h
  * @brief   底盘小陀螺模式任务接口。
  *
  * 任务由模式管理器独占唤醒，在 S1=2 且 S2=2 时执行小陀螺控制；不负责
  * CAN 初始化、DBUS 解码或 PID 参数定义。
  ******************************************************************************
  */

#ifndef APP_TASK_CHASSIS_SPIN_H
#define APP_TASK_CHASSIS_SPIN_H

/**
  * @brief  小陀螺 FreeRTOS 任务入口。
  * @param  argument FreeRTOS 任务参数，当前未使用。
  * @retval 无；任务入口不会返回。
  */
void task_chassis_spin_entry(void *argument);

#endif /* APP_TASK_CHASSIS_SPIN_H */

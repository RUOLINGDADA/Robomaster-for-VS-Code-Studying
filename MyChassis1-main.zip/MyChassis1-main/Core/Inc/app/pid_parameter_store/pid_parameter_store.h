/**
  ******************************************************************************
  * @file    pid_parameter_store.h
  * @brief   底盘速度 PID 参数的 Flash 持久化接口。
  *
  * 本模块只负责 Sector 11 的参数记录、CRC 校验和 HAL Flash 擦写；不负责
  * 电机控制、串口协议或任务调度。Flash 操作必须在任务上下文调用。
  ******************************************************************************
  */

#ifndef PID_PARAMETER_STORE_H
#define PID_PARAMETER_STORE_H

#include "app/chassis_control/chassis_control.h"

#include <stdbool.h>

/** PID 参数区起始地址；STM32F407 Sector 11，固件链接区截止于此地址。 */
#define PID_PARAMETER_STORE_FLASH_ADDRESS 0x080E0000U

/** PID 参数记录格式版本。 */
#define PID_PARAMETER_STORE_VERSION 1U

/**
 * @brief 从 Flash 读取并校验 PID 参数。
 * @param gains 输出参数，不能为 NULL。
 * @retval true 记录存在、版本正确且 CRC/范围校验通过。
 * @retval false 参数区为空、损坏、版本不匹配或输出为空；调用方应使用默认值。
 */
bool PidParameterStore_Load(ChassisSpeedPidGainsTypeDef *gains);

/**
 * @brief 擦除 Sector 11 并写入一份 PID 参数。
 * @param gains 待保存的有效参数，不能为 NULL。
 * @retval true 擦除和写入均成功。
 * @retval false 参数非法或 HAL Flash 操作失败。
 * @note 操作会阻塞几十毫秒，调用期间应先停止电机输出。
 */
bool PidParameterStore_Save(const ChassisSpeedPidGainsTypeDef *gains);

#endif /* PID_PARAMETER_STORE_H */

/**
  ******************************************************************************
  * @file    pid_parameter_store.c
  * @brief   底盘速度 PID 参数 Flash 存储实现。
  *
  * 使用 STM32F407 最后一个 128 KB 扇区保存一条带版本和 CRC32 的记录。
  * 不在中断中调用，不负责运行时 PID 应用和串口应答。
  ******************************************************************************
  */

#include "app/pid_parameter_store/pid_parameter_store.h"

#include "stm32f4xx_hal.h"

#include <stddef.h>
#include <math.h>
#include <stdint.h>
#include <string.h>

/** Flash 记录魔数，ASCII "PID1"，用于拒绝未初始化扇区。 */
#define PID_PARAMETER_STORE_MAGIC 0x50494431U

typedef struct {
  uint32_t magic;    /**< 记录识别字 / record magic. */
  uint32_t version;  /**< 格式版本 / record format version. */
  uint32_t sequence; /**< 记录序号 / record sequence. */
  float kp;          /**< 速度环比例系数 / speed-loop Kp. */
  float ki;          /**< 速度环积分系数 / speed-loop Ki. */
  float kd;          /**< 速度环微分系数 / speed-loop Kd. */
  uint32_t crc32;    /**< 前置字段 CRC32 / CRC32 of preceding fields. */
} PidParameterRecordTypeDef;

static bool PidParameterStore_IsValidGains(
    const ChassisSpeedPidGainsTypeDef *gains) {
  return gains != NULL && isfinite(gains->kp) && isfinite(gains->ki) &&
         isfinite(gains->kd) && gains->kp >= 0.0f &&
         gains->kp <= CHASSIS_CONTROL_SPEED_KP_MAX && gains->ki >= 0.0f &&
         gains->ki <= CHASSIS_CONTROL_SPEED_KI_MAX && gains->kd >= 0.0f &&
         gains->kd <= CHASSIS_CONTROL_SPEED_KD_MAX;
}

static uint32_t PidParameterStore_Crc32(const uint8_t *data, size_t length) {
  uint32_t crc = 0xFFFFFFFFU;
  for (size_t i = 0U; i < length; i++) {
    crc ^= data[i];
    for (uint32_t bit = 0U; bit < 8U; bit++) {
      crc = (crc & 1U) != 0U ? (crc >> 1U) ^ 0xEDB88320U : crc >> 1U;
    }
  }
  return ~crc;
}

bool PidParameterStore_Load(ChassisSpeedPidGainsTypeDef *gains) {
  if (gains == NULL) {
    return false;
  }
  const PidParameterRecordTypeDef *record =
      (const PidParameterRecordTypeDef *)PID_PARAMETER_STORE_FLASH_ADDRESS;
  if (record->magic != PID_PARAMETER_STORE_MAGIC ||
      record->version != PID_PARAMETER_STORE_VERSION ||
      record->crc32 != PidParameterStore_Crc32(
                           (const uint8_t *)record,
                           offsetof(PidParameterRecordTypeDef, crc32))) {
    return false;
  }
  ChassisSpeedPidGainsTypeDef loaded = {
      record->kp, record->ki, record->kd};
  if (!PidParameterStore_IsValidGains(&loaded)) {
    return false;
  }
  *gains = loaded;
  return true;
}

bool PidParameterStore_Save(const ChassisSpeedPidGainsTypeDef *gains) {
  if (!PidParameterStore_IsValidGains(gains)) {
    return false;
  }

  PidParameterRecordTypeDef record = {
      PID_PARAMETER_STORE_MAGIC,
      PID_PARAMETER_STORE_VERSION,
      1U,
      gains->kp,
      gains->ki,
      gains->kd,
      0U};
  record.crc32 = PidParameterStore_Crc32(
      (const uint8_t *)&record, offsetof(PidParameterRecordTypeDef, crc32));

  FLASH_EraseInitTypeDef erase = {0};
  uint32_t sector_error = 0U;
  erase.TypeErase = FLASH_TYPEERASE_SECTORS;
  erase.VoltageRange = FLASH_VOLTAGE_RANGE_3;
  erase.Sector = FLASH_SECTOR_11;
  erase.NbSectors = 1U;

  if (HAL_FLASH_Unlock() != HAL_OK) {
    return false;
  }
  bool success = HAL_FLASHEx_Erase(&erase, &sector_error) == HAL_OK;
  if (success) {
    const uint32_t *words = (const uint32_t *)&record;
    for (uint32_t i = 0U; i < sizeof(record) / sizeof(uint32_t); i++) {
      if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD,
                            PID_PARAMETER_STORE_FLASH_ADDRESS + i * 4U,
                            words[i]) != HAL_OK) {
        success = false;
        break;
      }
    }
    /* 写入成功不等于数据完整；读回整条记录验证总线/电源抖动造成的半写入。 */
    if (success && memcmp((const void *)PID_PARAMETER_STORE_FLASH_ADDRESS,
                          &record, sizeof(record)) != 0) {
      success = false;
    }
  }
  HAL_FLASH_Lock();
  return success;
}

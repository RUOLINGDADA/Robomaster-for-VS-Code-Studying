/**
  ******************************************************************************
  * @file    app_task_vofa_debug.c
  * @brief   USART1 蓝牙 PID 调参与 VOFA JustFloat 波形输出。
  *
  * RX 使用单字节 DMA，在中断回调中只做帧收集；任务上下文负责参数校验、
  * Flash 保存、ACK 和 100 ms 波形发送。9600 baud 下发送 19 个 float。
  ******************************************************************************
  */

#include "app/chassis_control/chassis_control.h"
#include "app/chassis_motors/chassis_motors.h"
#include "app/pid_parameter_store/pid_parameter_store.h"
#include "app/task_chassis_mode_manager/app_task_chassis_mode_manager.h"
#include "app/task_vofa_debug/app_task_vofa_debug.h"
#include "bsp/dr16_dbus/dr16_dbus.h"
#include "usart.h"

#include "FreeRTOS.h"
#include "task.h"

#include "stm32f4xx_hal.h"

#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

/** VOFA 任务周期，单位毫秒；19 通道波形约 10 Hz。 */
#define VOFA_TASK_PERIOD_MS 100U
/** USART1 单字节 DMA 接收长度，单位字节；每个完成回调提交一个字节。 */
#define VOFA_RX_BUFFER_LENGTH 1U
/** 调参帧头第 1 字节，协议值。 */
#define VOFA_HEADER_0 0xA5U
/** 调参帧头第 2 字节，协议值。 */
#define VOFA_HEADER_1 0x5AU
/** 设置统一速度 PID 参数命令，协议值。 */
#define VOFA_CMD_SET_PID 0x01U
/** 保存统一速度 PID 参数命令，协议值。 */
#define VOFA_CMD_SAVE_PID 0x02U
/** 读取统一速度 PID 参数命令，协议值。 */
#define VOFA_CMD_GET_PID 0x03U
/** ACK 命令标志位，协议值。 */
#define VOFA_ACK_FLAG 0x80U
/** SET_PID 数据长度，单位字节；三个 little-endian float32。 */
#define VOFA_SET_PID_PAYLOAD_LENGTH 12U
/** ACK 成功状态码，协议值。 */
#define VOFA_STATUS_OK 0x00U
/** ACK 帧格式错误状态码，协议值。 */
#define VOFA_STATUS_FORMAT 0x01U
/** ACK CRC 错误状态码，协议值。 */
#define VOFA_STATUS_CRC 0x02U
/** ACK 参数非法状态码，协议值。 */
#define VOFA_STATUS_PARAMETER 0x03U
/** ACK Flash 操作失败状态码，协议值。 */
#define VOFA_STATUS_FLASH 0x04U
/** ACK 当前状态忙状态码，协议值。 */
#define VOFA_STATUS_BUSY 0x05U
/** JustFloat 波形通道数量；四目标、四反馈速度、四电流、四 DR16、三 PID。 */
#define VOFA_TELEMETRY_FLOAT_COUNT 19U
#define VOFA_TELEMETRY_FRAME_LENGTH \
  (VOFA_TELEMETRY_FLOAT_COUNT * sizeof(float) + 4U)
#define VOFA_TX_BUFFER_LENGTH 128U
#define VOFA_COMMAND_QUEUE_DEPTH 4U
/** 滑条文本命令最大长度，单位字节；例如“KP=4.538”。 */
#define VOFA_TEXT_LINE_LENGTH 32U
/** 滑条文本命令队列深度，单位行；ISR 满队列时丢弃新行。 */
#define VOFA_TEXT_QUEUE_DEPTH 8U

static uint8_t g_vofa_rx_byte;
static uint8_t g_vofa_rx_frame[24U];
static uint8_t g_vofa_rx_index;
static uint8_t g_vofa_rx_expected_length;
static volatile bool g_vofa_rx_started;
static volatile uint8_t g_vofa_command_queue[VOFA_COMMAND_QUEUE_DEPTH][24U];
static volatile uint8_t g_vofa_command_lengths[VOFA_COMMAND_QUEUE_DEPTH];
static volatile uint8_t g_vofa_command_queue_head;
static volatile uint8_t g_vofa_command_queue_tail;
static volatile uint8_t g_vofa_command_queue_count;
static uint8_t g_vofa_text_line[VOFA_TEXT_LINE_LENGTH];
static uint8_t g_vofa_text_line_length;
static volatile uint8_t g_vofa_text_queue[VOFA_TEXT_QUEUE_DEPTH]
                                      [VOFA_TEXT_LINE_LENGTH];
static volatile uint8_t g_vofa_text_lengths[VOFA_TEXT_QUEUE_DEPTH];
static volatile uint8_t g_vofa_text_queue_head;
static volatile uint8_t g_vofa_text_queue_tail;
static volatile uint8_t g_vofa_text_queue_count;
static volatile bool g_vofa_tx_busy;
static uint8_t g_vofa_tx_buffer[VOFA_TX_BUFFER_LENGTH];
static uint8_t g_vofa_pending_ack[32U];
static uint8_t g_vofa_pending_ack_length;
static volatile bool g_vofa_ack_pending;
/** 文本滑条命令回执；0=无回执，1=参数已接收，2=格式/范围错误。 */
static volatile uint8_t g_vofa_text_result;

static bool Vofa_Send(uint8_t *data, uint16_t length);

static uint16_t Vofa_Crc16(const uint8_t *data, uint32_t length) {
  uint16_t crc = 0xFFFFU;
  for (uint32_t i = 0U; i < length; i++) {
    crc ^= data[i];
    for (uint32_t bit = 0U; bit < 8U; bit++) {
      crc = (crc & 1U) != 0U ? (uint16_t)((crc >> 1U) ^ 0xA001U)
                             : (uint16_t)(crc >> 1U);
    }
  }
  return crc;
}

static bool Vofa_StartRx(void) {
  const bool started = HAL_UART_Receive_DMA(&huart1, &g_vofa_rx_byte,
                                             VOFA_RX_BUFFER_LENGTH) == HAL_OK;
  if (started) {
    g_vofa_rx_started = true;
  }
  return started;
}

static void Vofa_ResetParser(void) {
  g_vofa_rx_index = 0U;
  g_vofa_rx_expected_length = 0U;
}

static void Vofa_PushTextLine(void) {
  if (g_vofa_text_line_length == 0U) {
    return;
  }
  if (g_vofa_text_queue_count < VOFA_TEXT_QUEUE_DEPTH) {
    const uint8_t head = g_vofa_text_queue_head;
    memcpy((void *)g_vofa_text_queue[head], g_vofa_text_line,
           g_vofa_text_line_length);
    g_vofa_text_lengths[head] = g_vofa_text_line_length;
    g_vofa_text_queue_head =
        (uint8_t)((head + 1U) % VOFA_TEXT_QUEUE_DEPTH);
    g_vofa_text_queue_count++;
  }
  g_vofa_text_line_length = 0U;
}

static void Vofa_PushTextByte(uint8_t byte) {
  if (byte == '\r' || byte == '\n') {
    Vofa_PushTextLine();
    return;
  }
  if (byte < 0x20U || byte > 0x7EU) {
    return;
  }
  if (g_vofa_text_line_length >= (VOFA_TEXT_LINE_LENGTH - 1U)) {
    /* 超长行直接丢弃，直到下一个换行，避免半条命令被误执行。 */
    g_vofa_text_line_length = 0U;
    return;
  }
  g_vofa_text_line[g_vofa_text_line_length++] = byte;
}

static void Vofa_PushByte(uint8_t byte) {
  if (g_vofa_rx_index == 0U) {
    if (byte == VOFA_HEADER_0) {
      g_vofa_rx_frame[g_vofa_rx_index++] = byte;
      g_vofa_text_line_length = 0U;
      return;
    }
    if (byte != VOFA_HEADER_0) {
      Vofa_PushTextByte(byte);
      return;
    }
  }
  if (g_vofa_rx_index == 1U) {
    if (byte != VOFA_HEADER_1) {
      /* A5 A5 5A 也应把第二个 A5 当作新帧头，避免错位后丢一帧。 */
      if (byte == VOFA_HEADER_0) {
        g_vofa_rx_frame[0] = byte;
        g_vofa_rx_index = 1U;
      } else {
        Vofa_ResetParser();
      }
      return;
    }
    g_vofa_rx_frame[g_vofa_rx_index++] = byte;
    return;
  }

  g_vofa_rx_frame[g_vofa_rx_index++] = byte;
  if (g_vofa_rx_index == 4U) {
    const uint8_t payload_length = g_vofa_rx_frame[3];
    /* 缓冲区最多容纳 18 字节协议帧；具体命令/长度错误留给任务回 ACK。 */
    if (payload_length > (uint8_t)(sizeof(g_vofa_rx_frame) - 6U)) {
      Vofa_ResetParser();
      return;
    }
    g_vofa_rx_expected_length = (uint8_t)(6U + payload_length);
  }
  if (g_vofa_rx_expected_length != 0U &&
      g_vofa_rx_index >= g_vofa_rx_expected_length) {
    /* DMA 回调只复制完整帧入小队列；Flash、CRC 和 ACK 均留在任务上下文。 */
    if (g_vofa_command_queue_count < VOFA_COMMAND_QUEUE_DEPTH) {
      const uint8_t head = g_vofa_command_queue_head;
      memcpy((void *)g_vofa_command_queue[head], g_vofa_rx_frame,
             g_vofa_rx_expected_length);
      g_vofa_command_lengths[head] = g_vofa_rx_expected_length;
      g_vofa_command_queue_head =
          (uint8_t)((head + 1U) % VOFA_COMMAND_QUEUE_DEPTH);
      g_vofa_command_queue_count++;
    }
    Vofa_ResetParser();
  }
}

static bool Vofa_TextEquals(const char *text, const char *token,
                            uint32_t length) {
  for (uint32_t i = 0U; i < length; i++) {
    char left = text[i];
    char right = token[i];
    if (left >= 'a' && left <= 'z') {
      left = (char)(left - ('a' - 'A'));
    }
    if (left != right) {
      return false;
    }
  }
  return true;
}

static const char *Vofa_TextSkipSeparators(const char *text) {
  while (*text == ' ' || *text == '\t' || *text == '=' || *text == ':' ||
         *text == ',' || *text == ';') {
    text++;
  }
  return text;
}

static bool Vofa_TextEnd(const char *text) {
  while (*text == ' ' || *text == '\t') {
    text++;
  }
  return *text == '\0';
}

static bool Vofa_ParseTextCommand(const uint8_t *line, uint8_t length) {
  char text[VOFA_TEXT_LINE_LENGTH] = {0};
  ChassisSpeedPidGainsTypeDef gains = {0};
  char *end = NULL;
  const char *cursor;
  float value;

  if (line == NULL || length == 0U || length >= VOFA_TEXT_LINE_LENGTH) {
    return false;
  }
  memcpy(text, line, length);
  cursor = text;
  while (*cursor == ' ' || *cursor == '\t') {
    cursor++;
  }
  ChassisControl_GetSpeedPidGains(&gains);

  if (Vofa_TextEquals(cursor, "PID", 3U) &&
      (cursor[3] == '=' || cursor[3] == ':' || cursor[3] == ' ' ||
       cursor[3] == '\t')) {
    cursor = Vofa_TextSkipSeparators(cursor + 3);
    value = strtof(cursor, &end);
    if (end == cursor || !isfinite(value)) {
      return false;
    }
    gains.kp = value;
    cursor = Vofa_TextSkipSeparators(end);
    gains.ki = strtof(cursor, &end);
    if (end == cursor || !isfinite(gains.ki)) {
      return false;
    }
    cursor = Vofa_TextSkipSeparators(end);
    gains.kd = strtof(cursor, &end);
    if (end == cursor || !isfinite(gains.kd) || !Vofa_TextEnd(end)) {
      return false;
    }
    return ChassisControl_SetSpeedPidGains(&gains);
  }

  if (Vofa_TextEquals(cursor, "KP", 2U) &&
      (cursor[2] == '=' || cursor[2] == ':' || cursor[2] == ' ' ||
       cursor[2] == '\t')) {
    cursor = Vofa_TextSkipSeparators(cursor + 2);
    value = strtof(cursor, &end);
    gains.kp = value;
  } else if (Vofa_TextEquals(cursor, "KI", 2U) &&
             (cursor[2] == '=' || cursor[2] == ':' || cursor[2] == ' ' ||
              cursor[2] == '\t')) {
    cursor = Vofa_TextSkipSeparators(cursor + 2);
    value = strtof(cursor, &end);
    gains.ki = value;
  } else if (Vofa_TextEquals(cursor, "KD", 2U) &&
             (cursor[2] == '=' || cursor[2] == ':' || cursor[2] == ' ' ||
              cursor[2] == '\t')) {
    cursor = Vofa_TextSkipSeparators(cursor + 2);
    value = strtof(cursor, &end);
    gains.kd = value;
  } else {
    return false;
  }
  if (end == cursor || !isfinite(value) || !Vofa_TextEnd(end)) {
    return false;
  }
  return ChassisControl_SetSpeedPidGains(&gains);
}

static void Vofa_ProcessTextCommand(void) {
  uint8_t line[VOFA_TEXT_LINE_LENGTH] = {0};
  uint8_t length = 0U;
  taskENTER_CRITICAL();
  if (g_vofa_text_queue_count != 0U) {
    const uint8_t tail = g_vofa_text_queue_tail;
    length = g_vofa_text_lengths[tail];
    memcpy(line, (const void *)g_vofa_text_queue[tail], length);
    g_vofa_text_queue_tail =
        (uint8_t)((tail + 1U) % VOFA_TEXT_QUEUE_DEPTH);
    g_vofa_text_queue_count--;
  }
  taskEXIT_CRITICAL();
  if (length != 0U) {
    g_vofa_text_result = Vofa_ParseTextCommand(line, length) ? 1U : 2U;
  }
}

static void Vofa_ApplyPidWhenNoSpeedTask(void) {
  const ChassisModeTypeDef mode = ChassisModeManager_GetMode();
  /* 测试模式没有速度 PID 任务占用控制器，可直接应用滑条参数；普通/小陀螺
     模式仍由各自控制周期应用，避免 VOFA 任务和电机任务并发改 PID。 */
  if (mode == CHASSIS_MODE_TEST || mode == CHASSIS_MODE_NONE) {
    (void)ChassisControl_ApplyPendingSpeedPidGains();
  }
}

static void Vofa_SendTextResult(void) {
  static uint8_t response_ok[] = "OK\r\n";
  static uint8_t response_error[] = "ERR\r\n";
  uint8_t *response = NULL;
  uint16_t length = 0U;

  if (g_vofa_text_result == 1U) {
    response = response_ok;
    length = (uint16_t)(sizeof(response_ok) - 1U);
  } else if (g_vofa_text_result == 2U) {
    response = response_error;
    length = (uint16_t)(sizeof(response_error) - 1U);
  } else {
    return;
  }
  if (Vofa_Send(response, length)) {
    g_vofa_text_result = 0U;
  }
}

static bool Vofa_Send(uint8_t *data, uint16_t length) {
  if (g_vofa_tx_busy || length > VOFA_TX_BUFFER_LENGTH) {
    return false;
  }
  memcpy(g_vofa_tx_buffer, data, length);
  g_vofa_tx_busy = true;
  if (HAL_UART_Transmit_DMA(&huart1, g_vofa_tx_buffer, length) != HAL_OK) {
    g_vofa_tx_busy = false;
    return false;
  }
  return true;
}

static void Vofa_WriteFloat(uint8_t *buffer, uint32_t *offset, float value) {
  memcpy(&buffer[*offset], &value, sizeof(value));
  *offset += sizeof(value);
}

static void Vofa_SendAck(uint8_t command, uint8_t status,
                         const ChassisSpeedPidGainsTypeDef *gains) {
  uint8_t frame[32U] = {0};
  uint32_t length = 5U;
  frame[0] = VOFA_HEADER_0;
  frame[1] = VOFA_HEADER_1;
  frame[2] = command | VOFA_ACK_FLAG;
  frame[3] = status;
  frame[4] = gains != NULL && status == VOFA_STATUS_OK ? 12U : 0U;
  if (gains != NULL && status == VOFA_STATUS_OK) {
    memcpy(&frame[5], gains, 12U);
    length += 12U;
  }
  const uint16_t crc = Vofa_Crc16(frame, length);
  frame[length++] = (uint8_t)(crc & 0xFFU);
  frame[length++] = (uint8_t)(crc >> 8U);
  if (!Vofa_Send(frame, (uint16_t)length) && !g_vofa_ack_pending) {
    memcpy(g_vofa_pending_ack, frame, length);
    g_vofa_pending_ack_length = (uint8_t)length;
    g_vofa_ack_pending = true;
  }
}

static void Vofa_SendPendingAck(void) {
  if (!g_vofa_ack_pending || g_vofa_tx_busy) {
    return;
  }
  if (Vofa_Send(g_vofa_pending_ack, g_vofa_pending_ack_length)) {
    g_vofa_ack_pending = false;
  }
}

static void Vofa_ProcessCommand(void) {
  uint8_t frame[24U] = {0};
  uint8_t length = 0U;
  taskENTER_CRITICAL();
  if (g_vofa_command_queue_count != 0U) {
    const uint8_t tail = g_vofa_command_queue_tail;
    length = g_vofa_command_lengths[tail];
    memcpy(frame, (const void *)g_vofa_command_queue[tail], length);
    g_vofa_command_queue_tail =
        (uint8_t)((tail + 1U) % VOFA_COMMAND_QUEUE_DEPTH);
    g_vofa_command_queue_count--;
  }
  taskEXIT_CRITICAL();
  if (length == 0U) {
    return;
  }
  const uint8_t command = frame[2];
  const uint16_t received_crc = (uint16_t)frame[length - 2U] |
                                (uint16_t)frame[length - 1U] << 8U;
  if (received_crc != Vofa_Crc16(frame, length - 2U)) {
    Vofa_SendAck(command, VOFA_STATUS_CRC, NULL);
    return;
  }
  if ((command == VOFA_CMD_SET_PID &&
       length != (uint8_t)(6U + VOFA_SET_PID_PAYLOAD_LENGTH)) ||
      ((command == VOFA_CMD_SAVE_PID || command == VOFA_CMD_GET_PID) &&
       length != 6U) ||
      (command != VOFA_CMD_SET_PID && command != VOFA_CMD_SAVE_PID &&
       command != VOFA_CMD_GET_PID)) {
    Vofa_SendAck(command, VOFA_STATUS_FORMAT, NULL);
    return;
  }
  if (command == VOFA_CMD_SET_PID) {
    ChassisSpeedPidGainsTypeDef gains = {0};
    memcpy(&gains, &frame[4], sizeof(gains));
    if (!ChassisControl_SetSpeedPidGains(&gains)) {
      Vofa_SendAck(command, VOFA_STATUS_PARAMETER, NULL);
      return;
    }
    Vofa_SendAck(command, VOFA_STATUS_OK, NULL);
  } else if (command == VOFA_CMD_GET_PID) {
    ChassisSpeedPidGainsTypeDef gains = {0};
    ChassisControl_GetSpeedPidGains(&gains);
    Vofa_SendAck(command, VOFA_STATUS_OK, &gains);
  } else if (command == VOFA_CMD_SAVE_PID) {
    ChassisSpeedPidGainsTypeDef gains = {0};
    if (!ChassisModeManager_EnterMaintenance()) {
      Vofa_SendAck(command, VOFA_STATUS_BUSY, NULL);
      return;
    }
    /* 工作任务已挂起，此时安全地提交待处理参数并读取最终值。 */
    (void)ChassisControl_ApplyPendingSpeedPidGains();
    ChassisControl_GetSpeedPidGains(&gains);
    const bool success = PidParameterStore_Save(&gains);
    /* Flash 失败时继续保持维护停机，避免参数区异常后自动恢复电机输出。 */
    if (success) {
      ChassisModeManager_ExitMaintenance();
    }
    Vofa_SendAck(command, success ? VOFA_STATUS_OK : VOFA_STATUS_FLASH, NULL);
  } else {
    Vofa_SendAck(command, VOFA_STATUS_FORMAT, NULL);
  }
}

static void Vofa_SendTelemetry(void) {
  if (g_vofa_tx_busy) {
    return;
  }
  float values[VOFA_TELEMETRY_FLOAT_COUNT] = {0.0f};
  DR16_Dbus_DataTypeDef remote = {0};
  (void)DR16_Dbus_GetData(&remote);
  for (uint32_t i = 0U; i < CHASSIS_MOTORS_COUNT; i++) {
    values[i] = g_chassis_target_speed_rpm[i];
    (void)ChassisMotors_GetSpeedRpm(i, &values[4U + i]);
    (void)ChassisMotors_GetCurrentA(i, &values[8U + i]);
  }
  for (uint32_t i = 0U; i < DR16_DBUS_CHANNEL_COUNT; i++) {
    values[12U + i] = (float)remote.channel[i];
  }
  ChassisSpeedPidGainsTypeDef gains = {0};
  ChassisControl_GetSpeedPidGains(&gains);
  values[16] = gains.kp;
  values[17] = gains.ki;
  values[18] = gains.kd;
  uint32_t offset = 0U;
  for (uint32_t i = 0U; i < VOFA_TELEMETRY_FLOAT_COUNT; i++) {
    Vofa_WriteFloat(g_vofa_tx_buffer, &offset, values[i]);
  }
  g_vofa_tx_buffer[offset++] = 0x00U;
  g_vofa_tx_buffer[offset++] = 0x00U;
  g_vofa_tx_buffer[offset++] = 0x80U;
  g_vofa_tx_buffer[offset++] = 0x7FU;
  g_vofa_tx_busy = true;
  if (HAL_UART_Transmit_DMA(&huart1, g_vofa_tx_buffer, (uint16_t)offset) !=
      HAL_OK) {
    g_vofa_tx_busy = false;
  }
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
  if (huart == &huart1) {
    Vofa_PushByte(g_vofa_rx_byte);
  }
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart) {
  if (huart == &huart1) {
    g_vofa_tx_busy = false;
  }
}

void Vofa_Debug_OnUartError(UART_HandleTypeDef *huart) {
  if (huart != &huart1) {
    return;
  }
  /* UART 错误会终止 HAL 的单字节 DMA；清空半帧后从下一个字节重新找帧头。 */
  Vofa_ResetParser();
  g_vofa_rx_started = false;
}

void task_vofa_debug_entry(void *argument) {
  (void)argument;
  (void)Vofa_StartRx();
  TickType_t last_wake_tick = xTaskGetTickCount();
  for (;;) {
    /* 错误中止 DMA 后在任务上下文重试，避免在错误 ISR 中忙等。 */
    if (!g_vofa_rx_started) {
      (void)Vofa_StartRx();
    }
    Vofa_ProcessCommand();
    /* 一次周期处理完已经排队的滑条命令，避免三个 PID 滑条更新过慢。 */
    while (g_vofa_text_queue_count != 0U) {
      Vofa_ProcessTextCommand();
    }
    Vofa_ApplyPidWhenNoSpeedTask();
    Vofa_SendPendingAck();
    /* 先回送滑条结果；如果 TX 忙，下一周期重试，避免波形帧覆盖回执。 */
    Vofa_SendTextResult();
    Vofa_SendTelemetry();
    vTaskDelayUntil(&last_wake_tick, pdMS_TO_TICKS(VOFA_TASK_PERIOD_MS));
  }
}

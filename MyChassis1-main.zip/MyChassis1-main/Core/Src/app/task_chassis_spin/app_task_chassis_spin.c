/**
  ******************************************************************************
  * @file    app_task_chassis_spin.c
  * @brief   底盘小陀螺控制任务。
  *
  * 任务以固定周期读取 DR16 和四个 M3508 的 CAN 转速，按目标角速度积分大地
  * 坐标航向，并调用底盘控制模块生成四轮目标转速。实际车体角速度由四轮反馈
  * 估算后保存为调试量；电流闭环仍由四个电机速度 PID 完成。本任务不初始化
  * CAN，不直接解析 DBUS 帧，也不与测试/普通底盘任务并行运行。
  ******************************************************************************
  */

#include "app/chassis_control/chassis_control.h"
#include "app/chassis_motors/chassis_motors.h"
#include "app/task_chassis_spin/app_task_chassis_spin.h"
#include "app/task_chassis_mode_manager/app_task_chassis_mode_manager.h"
#include "bsp/board_can/board_can.h"
#include "bsp/dr16_dbus/dr16_dbus.h"

#include "FreeRTOS.h"
#include "task.h"

#include "stm32f4xx_hal.h"

#include <stdbool.h>
#include <stdint.h>

/** 小陀螺任务控制周期，单位：毫秒。 */
#define CHASSIS_SPIN_TASK_PERIOD_MS 2U

/** PID 采样间隔异常阈值，单位：毫秒。 */
#define CHASSIS_SPIN_TASK_PID_GAP_MS 100U

/** 初始化失败后的等待周期，单位：毫秒。 */
#define CHASSIS_SPIN_TASK_INIT_RETRY_MS 1000U

/** 圆周率，用于转子 rpm 与轮缘线速度换算。 */
#define CHASSIS_SPIN_PI 3.14159265358979323846f

static bool ChassisSpinTask_IsModeSelected(
    DR16_Dbus_DataTypeDef *remote_data) {
  if (remote_data == NULL || !DR16_Dbus_GetData(remote_data)) {
    return false;
  }
  if (!remote_data->online) {
    return false;
  }
  return ChassisModeManager_GetMode() == CHASSIS_MODE_SPIN;
}

/**
  * @brief  用四个电机的逻辑转速估算车体右转角速度。
  * @param  omega_rad_s 输出角速度，单位 rad/s，不能为 NULL。
  * @retval true 四个电机均在线且反馈有效；false 至少一个反馈不可用。
  * @note   当前使用临时轮径、轴距、轮距和减速比宏；更换 IMU 时只需替换此函数。
  */
static bool ChassisSpinTask_GetFeedbackOmega(float *omega_rad_s) {
  if (omega_rad_s == NULL) {
    return false;
  }
  float speed_rpm[CHASSIS_MOTORS_COUNT] = {0.0f};
  for (uint32_t i = 0U; i < CHASSIS_MOTORS_COUNT; i++) {
    if (!ChassisMotors_GetSpeedRpm(i, &speed_rpm[i])) {
      *omega_rad_s = 0.0f;
      return false;
    }
  }

  const float rpm_to_mps = CHASSIS_SPIN_WHEEL_RADIUS_M *
                           2.0f * CHASSIS_SPIN_PI /
                           (60.0f * CHASSIS_SPIN_REDUCTION_RATIO);
  const float right_turn_wheel_speed =
      (speed_rpm[1] + speed_rpm[2] - speed_rpm[0] - speed_rpm[3]) *
      rpm_to_mps;
  const float chassis_radius =
      4.0f * (CHASSIS_SPIN_HALF_LENGTH_M + CHASSIS_SPIN_HALF_WIDTH_M);
  *omega_rad_s = right_turn_wheel_speed / chassis_radius;
  return true;
}

/**
  * @brief  将四个逻辑目标转速计算成电流并写入电机缓存。
  * @param  dt_s 实际控制间隔，单位秒。
  * @retval 无。
  * @note   离线电机输出关闭并清除对应 PID 历史。
  */
static void ChassisSpinTask_ApplyTargetCurrents(float dt_s) {
  for (uint32_t i = 0U; i < CHASSIS_MOTORS_COUNT; i++) {
    float feedback_rpm = 0.0f;
    const bool online = ChassisMotors_GetSpeedRpm(i, &feedback_rpm);
    int16_t target_current = 0;
    if (online) {
      target_current = ChassisControl_CalcCurrent(i, feedback_rpm, dt_s);
    } else {
      ChassisControl_ResetMotor(i);
    }
    (void)C620_M3508_SetOutputEnabled(&g_chassis_motors[i], online);
    (void)ChassisMotors_SetCurrent(i, target_current);
  }
}

/**
  * @brief  将积分航向角折返到 [-pi, pi]，避免长时间运行累积过大。
  * @param  heading_rad 当前航向角，单位 rad。
  * @retval 折返后的航向角，单位 rad。
  */
static float ChassisSpinTask_WrapHeading(float heading_rad) {
  while (heading_rad > CHASSIS_SPIN_PI) {
    heading_rad -= 2.0f * CHASSIS_SPIN_PI;
  }
  while (heading_rad < -CHASSIS_SPIN_PI) {
    heading_rad += 2.0f * CHASSIS_SPIN_PI;
  }
  return heading_rad;
}

/**
  * @brief  底盘小陀螺任务入口。
  * @param  argument FreeRTOS 任务参数，当前未使用。
  * @retval 无；任务入口不会返回。
  * @note   任务永久等待模式管理器唤醒，退出模式后清零航向、PID 和电流。
  */
void task_chassis_spin_entry(void *argument) {
  (void)argument;
  if (!ChassisControl_Init()) {
    for (;;) {
      vTaskDelay(pdMS_TO_TICKS(CHASSIS_SPIN_TASK_INIT_RETRY_MS));
    }
  }

  for (;;) {
    vTaskSuspend(NULL);

    ChassisControl_Clear();
    ChassisControl_SetCurrentLimitsRaw(
        CHASSIS_SPIN_THEORETICAL_CURRENT_RAW_MAX,
        CHASSIS_SPIN_ACTUAL_CURRENT_RAW_MAX);
    float heading_rad = 0.0f;
    TickType_t last_wake_tick = xTaskGetTickCount();
    uint32_t previous_ms = HAL_GetTick() - CHASSIS_SPIN_TASK_PERIOD_MS;

    for (;;) {
      DR16_Dbus_DataTypeDef remote_data = {0};
      if (!ChassisSpinTask_IsModeSelected(&remote_data)) {
        ChassisControl_Clear();
        ChassisMotors_StopAll();
        (void)ChassisMotors_Send();
        break;
      }

      if (BoardCan_RecoverIfBusOff()) {
        ChassisControl_Clear();
        ChassisControl_SetCurrentLimitsRaw(
            CHASSIS_SPIN_THEORETICAL_CURRENT_RAW_MAX,
            CHASSIS_SPIN_ACTUAL_CURRENT_RAW_MAX);
        ChassisMotors_StopAll();
        (void)ChassisMotors_Send();
        previous_ms = HAL_GetTick();
        last_wake_tick = xTaskGetTickCount();
        vTaskDelayUntil(&last_wake_tick,
                        pdMS_TO_TICKS(CHASSIS_SPIN_TASK_PERIOD_MS));
        continue;
      }

      const uint32_t now_ms = HAL_GetTick();
      const uint32_t elapsed_ms = now_ms - previous_ms;
      previous_ms = now_ms;
      if (elapsed_ms == 0U || elapsed_ms > CHASSIS_SPIN_TASK_PID_GAP_MS) {
        ChassisControl_Clear();
        ChassisControl_SetCurrentLimitsRaw(
            CHASSIS_SPIN_THEORETICAL_CURRENT_RAW_MAX,
            CHASSIS_SPIN_ACTUAL_CURRENT_RAW_MAX);
        ChassisMotors_StopAll();
        (void)ChassisMotors_Send();
        heading_rad = 0.0f;
        last_wake_tick = xTaskGetTickCount();
        vTaskDelayUntil(&last_wake_tick,
                        pdMS_TO_TICKS(CHASSIS_SPIN_TASK_PERIOD_MS));
        continue;
      }

      const float dt_s = (float)elapsed_ms * 0.001f;
      const float target_omega_rad_s = CHASSIS_SPIN_TARGET_OMEGA_RAD_S;
      heading_rad = ChassisSpinTask_WrapHeading(
          heading_rad + target_omega_rad_s * dt_s);
      ChassisMotors_Process(now_ms);
      (void)ChassisControl_ApplyPendingSpeedPidGains();

      float feedback_omega_rad_s = 0.0f;
      if (ChassisSpinTask_GetFeedbackOmega(&feedback_omega_rad_s)) {
        ChassisControl_SetSpinFeedbackOmega(feedback_omega_rad_s);
      } else {
        ChassisControl_SetSpinFeedbackOmega(0.0f);
      }

      ChassisControl_UpdateSpin(&remote_data, heading_rad,
                                CHASSIS_SPIN_TARGET_OMEGA_RAD_S);
      ChassisSpinTask_ApplyTargetCurrents(dt_s);
      (void)ChassisMotors_Send();

      if (elapsed_ms > CHASSIS_SPIN_TASK_PERIOD_MS * 2U) {
        last_wake_tick = xTaskGetTickCount();
      }
      vTaskDelayUntil(&last_wake_tick,
                      pdMS_TO_TICKS(CHASSIS_SPIN_TASK_PERIOD_MS));
    }

    ChassisControl_Clear();
    ChassisMotors_StopAll();
    (void)ChassisMotors_Send();
  }
}

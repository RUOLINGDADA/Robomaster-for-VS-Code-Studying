# MyChassis1 项目规则

## 适用范围

本文件适用于 `D:\CubeMxProject\MyChassis1` 及其所有子目录。修改本工程前，先阅读本文件和
`doc/README.md`，再按任务阅读 `doc/` 下的专题文档。

## 项目目标与技术基线

- 目标平台：STM32F407IGH6（RoboMaster 开发板 C 型），使用 HAL 库、C11、CMake + Ninja、
  arm-none-eabi-gcc。
- 系统基础：FreeRTOS（CMSIS-RTOS V2 适配层）。任务、队列、信号量和事件组按实际功能添加，
  不为形式完整而增加对象。
- 本工程职责：RoboMaster 底盘控制。当前阶段实现 CAN 通信与 M3508 电机驱动，PID、运动学
  和功率限制属于后续任务，不由驱动层承担。
- 工程入口：`Core/Src/main.c`、`Core/Src/freertos.c`、`CMakeLists.txt` 和
  `cmake/stm32cubemx/CMakeLists.txt`。

## 硬件资源分配（已确认）

| 资源 | 用途 | 说明 |
|---|---|---|
| CAN1（PD0/PD1） | 底盘 M3508 电机 | 1 Mbit/s；`Prescaler=3`、`BS1=10TQ`、`BS2=3TQ` |
| CAN2（PB5/PB6） | 云台电机（尚未接入） | 已由 CubeMX 初始化，但未配置过滤器、未启动 |
| USART | 调试日志 | **当前未启用**：`.ioc` 无 USART，`__io_putchar()` 无强定义，`printf` 静默丢弃输出。详见 `doc/PROJECT_CONTEXT.md` |

## 目录与模块边界

采用多层级模块化结构，一个设备驱动对应一个目录：

```text
Core/
  Inc/
    bsp/<driver>/      # 设备/板级驱动头文件
    app/<feature>/     # 应用功能头文件（本工程任务接口通常由 freertos.c 声明）
  Src/
    bsp/<driver>/      # 设备/板级驱动实现
    app/<feature>/     # 应用任务与应用逻辑
doc/
  modules/<module>/    # 每个模块一份 README.md
  protocol/            # CAN 等协议的字段级说明
```

当前模块：

- `bsp/board_can/`：CAN 过滤器配置、外设启动、FIFO 路由。板级资源归它管。
- `bsp/m3508_c620/`：C620 电调 + M3508 电机的 CAN 协议驱动。只认协议，不认引脚。
- `app/task_m3508_can_test/`：底盘 CAN 环路自检任务。只做调度和时序，不做协议解析。

依赖方向固定为单向：

```text
app/*  ->  bsp/*  ->  HAL / CubeMX 生成代码
```

驱动不得反向依赖任务，`bsp/` 不得包含业务策略。

## 命名与代码风格

- 文件名、目录名使用小写英文加下划线；类型用 `PascalCaseTypeDef`；函数用
  `模块前缀_动作`（例如 `C620_M3508_SetCurrent`）；宏用全大写；静态文件级对象用 `g_` 前缀。
- 头文件使用 `#ifndef/#define/#endif` 保护；公共接口放头文件，私有实现放源文件。
- 2 空格缩进，大括号与 CubeMX 生成代码保持一致。
- 变量名体现单位或范围，例如 `elapsed_ms`、`speed_rpm`、`current_raw`；避免 `temp`、`flag2`。
- 只保留与功能有关的回调和错误处理，不为每种理论错误创建空回调。

### 注释最低要求

- 每个自建 `.c`/`.h` 文件有文件级多行说明，写明模块职责、硬件接口或协议范围、运行上下文
  （任务/中断/普通调用）和明确不负责的内容。
- 每个公开函数有多行说明，至少包含 `@brief`、参数、返回值；涉及单位、任务/ISR 限制、
  线程安全和失败后状态时必须写明。
- 每个复杂函数有块注释说明“先做什么、为什么这样做、失败如何退出”。
- 单行注释解释底层坑点（大小端、中断上下文、Tick 回绕、饱和边界、volatile 可见性），
  不复述代码。
- **本项目要求中英文双注释**：文件头和关键块注释给中英对照；头文件类型与字段注释中英并列；
  实现内部的单行注释以中文为主，涉及协议/底层机制的关键行补英文。
- 数值必须带单位或协议含义，不写“延时”“限制”“状态”这类无信息量的注释。

## FreeRTOS 使用规则

- 任务必须有明确职责、周期或阻塞条件、栈大小和优先级依据。周期任务使用 `vTaskDelayUntil`
  保持固定节拍，避免累计漂移。
- 任务的栈大小必须按实际调用链估算。本工程任务调用 `printf`，`newlib-nano` 格式化路径栈开销
  大，`osThreadAttr_t.stack_size` 单位是**字节**，务必乘 `sizeof(StackType_t)`。
- 中断中只能调用带 `FromISR` 后缀的 API，并正确处理 `higher_priority_task_woken`。
- 本工程 CAN 接收中断优先级为 5，等于 `configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY`，
  因此中断里可以调用 `FromISR` 接口，但当前接收路径刻意不做任何 FreeRTOS 调用。
- 任务入口不得返回；初始化失败时保留任务并阻塞等待，便于调试器检查，而不是删除任务。
- 共享数据必须说明访问上下文；多字段快照用临界区、队列或复制策略保证一致性。

## CubeMX 生成代码与构建

- `MyChassis1.ioc` 是用户的配置源，**修改前必须先询问用户**。
- `Core/Src/can.c`、`Core/Src/gpio.c`、`Core/Src/main.c`、`Core/Src/freertos.c` 等由 CubeMX
  生成。只允许在 `/* USER CODE BEGIN xxx */` 与 `/* USER CODE END xxx */` 之间写代码，
  否则重新生成时会被丢弃。
- 业务逻辑不要堆在生成文件中：新增驱动放 `Core/Src/bsp/`，新增任务放 `Core/Src/app/`。
- 新增 `.c` 文件必须同步更新 `CMakeLists.txt` 的 `target_sources()`；新增头文件根目录要更新
  `target_include_directories()`。
- 不提交 `build/`、编译产物和编辑器缓存。

## 修改流程（供后续 agent 执行）

1. 阅读本文件、`doc/README.md` 和相关模块文档。
2. 检查 `git status`，保留用户已有修改，不覆盖未知改动。
3. 先定义模块边界、公开 API、任务/中断上下文和硬件依赖，再写实现。
4. 以最小改动完成功能；不要顺手添加尚未被要求的功能（例如 PID、遥控解析）。
5. 编译验证；无法执行完整构建时，至少用真实工具链做语法/编译检查并说明未验证部分。
6. 同步更新 `doc/`：模块 README、`CHANGELOG.md`，未确认项写入 `OPEN_QUESTIONS.md`。

## 文档同步要求

新增或改变模块时，至少更新：

- `doc/README.md` 的模块索引；
- 对应 `doc/modules/<module>/README.md`（接口、依赖、任务、时序、示例调用）；
- `doc/CHANGELOG.md` 一条变更记录；
- 协议字段变化时更新 `doc/protocol/`；
- 需求或硬件信息未确定时更新 `doc/OPEN_QUESTIONS.md`，不要自行猜测并固化。

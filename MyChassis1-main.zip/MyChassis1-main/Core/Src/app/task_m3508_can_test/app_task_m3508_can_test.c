/**
  ******************************************************************************
  * @file    app_task_m3508_can_test.c
  * @brief   底盘四个 M3508 的 CAN 自检任务。
  *
  * 本任务只在 switch_s1=1 时运行：等待电调反馈后，按正转、反转两个阶段交替
  * 输出小电流。任务启动时由模式管理任务唤醒，离开测试模式后清零并重新挂起。
  * 电机句柄和 CAN 接收中断属于 app/chassis_motors，不在本文件重复注册。
  ******************************************************************************
  */

#include "app/chassis_motors/chassis_motors.h"
#include "app/task_m3508_can_test/app_task_m3508_can_test.h"
#include "bsp/board_can/board_can.h"
#include "bsp/dr16_dbus/dr16_dbus.h"

#include "FreeRTOS.h"
#include "task.h"

#include "stm32f4xx_hal.h"

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

/** 自检任务控制周期，单位：毫秒。 */
#define M3508_TEST_PERIOD_MS 2U

/** 自检阶段持续时间，单位：毫秒。 */
#define M3508_TEST_PHASE_MS 1000U

/** 收到反馈后的零电流稳定时间，单位：毫秒。 */
#define M3508_TEST_ARM_DELAY_MS 50U

/** 等待反馈的告警周期，单位：毫秒。 */
#define M3508_TEST_FEEDBACK_WARN_MS 3000U

/** 反馈日志输出周期，单位：毫秒。 */
#define M3508_TEST_LOG_PERIOD_MS 500U

/** 测试电流原始值，约等于 0.6 A。 */
#define M3508_TEST_CURRENT_RAW 500

/** 参与自检的电机掩码，bit0~bit3 对应 m0~m3。 */
#define M3508_TEST_SPIN_MASK 0x0FU

/** 自检阶段。 */
typedef enum {
  M3508_TEST_PHASE_WAIT_FEEDBACK = 0,
  M3508_TEST_PHASE_ARM_DELAY,
  M3508_TEST_PHASE_SPIN_POSITIVE,
  M3508_TEST_PHASE_SPIN_NEGATIVE
} M3508_TestPhaseTypeDef;

static M3508_TestPhaseTypeDef g_test_phase;
static TickType_t g_test_phase_start_tick;
static TickType_t g_test_last_log_tick;
static TickType_t g_test_wait_start_tick;
static uint32_t g_test_active_mask;
static bool g_test_warned_no_feedback;
static bool g_test_tx_ok;

static uint32_t M3508Test_OnlineCount(void) {
  uint32_t online_count = 0U;
  for (uint32_t i = 0U; i < CHASSIS_MOTORS_COUNT; i++) {
    if (C620_M3508_IsOnline(&g_chassis_motors[i])) {
      online_count++;
    }
  }
  return online_count;
}

static void M3508Test_SetPhase(M3508_TestPhaseTypeDef phase,
                               TickType_t now_tick) {
  g_test_phase = phase;
  g_test_phase_start_tick = now_tick;
  if (phase == M3508_TEST_PHASE_WAIT_FEEDBACK) {
    g_test_active_mask = 0U;
    g_test_wait_start_tick = now_tick;
    g_test_warned_no_feedback = false;
  }
}

static TickType_t M3508Test_PhaseDuration(M3508_TestPhaseTypeDef phase) {
  if (phase == M3508_TEST_PHASE_ARM_DELAY ||
      phase == M3508_TEST_PHASE_SPIN_POSITIVE ||
      phase == M3508_TEST_PHASE_SPIN_NEGATIVE) {
    return pdMS_TO_TICKS(phase == M3508_TEST_PHASE_ARM_DELAY
                             ? M3508_TEST_ARM_DELAY_MS
                             : M3508_TEST_PHASE_MS);
  }
  return 0U;
}

static void M3508Test_SetOutputsEnabled(bool enabled) {
  for (uint32_t i = 0U; i < CHASSIS_MOTORS_COUNT; i++) {
    const bool allowed = enabled &&
                         ((g_test_active_mask >> i) & 0x1U) != 0U &&
                         C620_M3508_IsOnline(&g_chassis_motors[i]);
    (void)C620_M3508_SetOutputEnabled(&g_chassis_motors[i], allowed);
  }
}

static void M3508Test_BuildTargetCurrents(
    int16_t target_current[CHASSIS_MOTORS_COUNT]) {
  int16_t test_current = 0;
  if (g_test_phase == M3508_TEST_PHASE_SPIN_POSITIVE) {
    test_current = (int16_t)M3508_TEST_CURRENT_RAW;
  } else if (g_test_phase == M3508_TEST_PHASE_SPIN_NEGATIVE) {
    test_current = (int16_t)-M3508_TEST_CURRENT_RAW;
  }
  for (uint32_t i = 0U; i < CHASSIS_MOTORS_COUNT; i++) {
    target_current[i] = ((g_test_active_mask >> i) & 0x1U) != 0U
                            ? test_current
                            : (int16_t)0;
  }
}

static void M3508Test_LogFeedback(TickType_t now_tick) {
  if ((now_tick - g_test_last_log_tick) <
      pdMS_TO_TICKS(M3508_TEST_LOG_PERIOD_MS)) {
    return;
  }
  g_test_last_log_tick = now_tick;
  printf("[m3508_test] online=%lu/%u phase=%u tx=%u\r\n",
         (unsigned long)M3508Test_OnlineCount(),
         (unsigned)CHASSIS_MOTORS_COUNT, (unsigned)g_test_phase,
         g_test_tx_ok ? 1U : 0U);
}

static bool M3508Test_IsModeSelected(void) {
  DR16_Dbus_DataTypeDef remote_data = {0};
  return DR16_Dbus_GetData(&remote_data) && remote_data.online &&
         remote_data.switch_s1 == DR16_DBUS_SWITCH_UP;
}

/**
  * @brief  运行一次自检状态机。
  * @param  now_tick 当前 FreeRTOS tick。
  * @param  now_ms 当前 HAL 毫秒 tick。
  * @retval true 仍处于测试模式；false 表示应退出并挂起任务。
  */
static bool M3508Test_RunCycle(TickType_t now_tick, uint32_t now_ms) {
  if (!M3508Test_IsModeSelected()) {
    ChassisMotors_StopAll();
    (void)ChassisMotors_Send();
    return false;
  }

  if (BoardCan_RecoverIfBusOff()) {
    ChassisMotors_StopAll();
    M3508Test_SetPhase(M3508_TEST_PHASE_WAIT_FEEDBACK, now_tick);
  }

  ChassisMotors_Process(now_ms);

  if (g_test_phase == M3508_TEST_PHASE_WAIT_FEEDBACK) {
    M3508Test_SetOutputsEnabled(false);
    for (uint32_t i = 0U; i < CHASSIS_MOTORS_COUNT; i++) {
      if (((M3508_TEST_SPIN_MASK >> i) & 0x1U) != 0U &&
          C620_M3508_IsOnline(&g_chassis_motors[i])) {
        g_test_active_mask |= 1U << i;
      }
    }
    if (g_test_active_mask != 0U) {
      M3508Test_SetPhase(M3508_TEST_PHASE_ARM_DELAY, now_tick);
    } else if (!g_test_warned_no_feedback &&
               (now_tick - g_test_wait_start_tick) >=
                   pdMS_TO_TICKS(M3508_TEST_FEEDBACK_WARN_MS)) {
      g_test_warned_no_feedback = true;
      printf("[m3508_test] no motor feedback\r\n");
    }
  } else {
    bool link_lost = false;
    for (uint32_t i = 0U; i < CHASSIS_MOTORS_COUNT; i++) {
      if (((g_test_active_mask >> i) & 0x1U) != 0U &&
          (!C620_M3508_IsOnline(&g_chassis_motors[i]) ||
           C620_M3508_RequiresRearm(&g_chassis_motors[i]))) {
        link_lost = true;
        break;
      }
    }
    if (link_lost) {
      ChassisMotors_StopAll();
      M3508Test_SetPhase(M3508_TEST_PHASE_WAIT_FEEDBACK, now_tick);
    } else {
      if ((now_tick - g_test_phase_start_tick) >=
          M3508Test_PhaseDuration(g_test_phase)) {
        const M3508_TestPhaseTypeDef next_phase =
            g_test_phase == M3508_TEST_PHASE_ARM_DELAY
                ? M3508_TEST_PHASE_SPIN_POSITIVE
                : (g_test_phase == M3508_TEST_PHASE_SPIN_POSITIVE
                       ? M3508_TEST_PHASE_SPIN_NEGATIVE
                       : M3508_TEST_PHASE_SPIN_POSITIVE);
        M3508Test_SetPhase(next_phase, now_tick);
      }
      int16_t target_current[CHASSIS_MOTORS_COUNT] = {0};
      M3508Test_BuildTargetCurrents(target_current);
      M3508Test_SetOutputsEnabled(g_test_phase != M3508_TEST_PHASE_ARM_DELAY);
      for (uint32_t i = 0U; i < CHASSIS_MOTORS_COUNT; i++) {
        (void)ChassisMotors_SetCurrent(i, target_current[i]);
      }
    }
  }

  g_test_tx_ok = ChassisMotors_Send();
  M3508Test_LogFeedback(now_tick);
  return true;
}

/**
  * @brief  M3508 自检任务入口。
  * @param  argument FreeRTOS 任务参数，当前未使用。
  * @retval 无；任务入口不会返回。
  * @note   任务启动后永久等待模式管理任务唤醒，离开 switch_s1=1 后清零并再次等待。
  */
void task_chassis_can_test_entry(void *argument) {
  (void)argument;
  for (;;) {
    vTaskSuspend(NULL);

    const TickType_t start_tick = xTaskGetTickCount();
    g_test_last_log_tick = start_tick;
    M3508Test_SetPhase(M3508_TEST_PHASE_WAIT_FEEDBACK, start_tick);
    ChassisMotors_StopAll();

    TickType_t last_wake_tick = start_tick;
    for (;;) {
      if (!M3508Test_RunCycle(xTaskGetTickCount(), HAL_GetTick())) {
        break;
      }
      vTaskDelayUntil(&last_wake_tick, pdMS_TO_TICKS(M3508_TEST_PERIOD_MS));
    }
    ChassisMotors_StopAll();
    (void)ChassisMotors_Send();
  }
}

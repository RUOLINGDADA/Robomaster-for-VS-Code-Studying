/* 主机测试用驱动替身：让公共电机模块执行真实方向逻辑，不访问 CAN 硬件。 */
#ifndef TEST_M3508_C620_H
#define TEST_M3508_C620_H
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#define C620_M3508_FEEDBACK_TIMEOUT_MS 100U /* 模拟真实驱动的超时配置 ms */
typedef struct { uint8_t unused; } CAN_HandleTypeDef;
typedef struct {
  CAN_HandleTypeDef *hcan;
  uint8_t motor_id;
  uint32_t feedback_timeout_ms;
} C620_M3508_ConfigTypeDef;
typedef struct { int16_t speed_rpm; int16_t current_raw; } C620_M3508_FeedbackTypeDef;
typedef struct {
  C620_M3508_ConfigTypeDef config;
  C620_M3508_FeedbackTypeDef feedback;
  int16_t target_current_raw;
  bool online;
} C620_M3508_HandleTypeDef;
bool C620_M3508_Init(C620_M3508_HandleTypeDef *, const C620_M3508_ConfigTypeDef *);
bool C620_M3508_Process(C620_M3508_HandleTypeDef *, uint32_t);
bool C620_M3508_SetOutputEnabled(C620_M3508_HandleTypeDef *, bool);
bool C620_M3508_SetCurrent(C620_M3508_HandleTypeDef *, int16_t);
bool C620_M3508_IsOnline(const C620_M3508_HandleTypeDef *);
bool C620_M3508_GetFeedback(const C620_M3508_HandleTypeDef *, C620_M3508_FeedbackTypeDef *);
bool C620_M3508_SendAll(CAN_HandleTypeDef *);
#endif

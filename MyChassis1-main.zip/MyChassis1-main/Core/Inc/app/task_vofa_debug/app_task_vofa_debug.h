/**
  ******************************************************************************
  * @file    app_task_vofa_debug.h
  * @brief   USART1 蓝牙 PID 调参与 VOFA JustFloat 波形任务接口。
  *
  * 本任务使用 CubeMX 已配置的 USART1 DMA；不操作 CAN，不直接修改 PID，
  * 所有运行时参数通过底盘控制模块的安全边界应用。
  ******************************************************************************
  */

#ifndef APP_TASK_VOFA_DEBUG_H
#define APP_TASK_VOFA_DEBUG_H

#include "stm32f4xx_hal.h"

/**
 * @brief VOFA 调试任务入口。
 * @param argument FreeRTOS 任务参数，当前未使用。
 * @retval 无；任务入口不会返回。
 */
void task_vofa_debug_entry(void *argument);

/**
 * @brief 处理 USART1 错误并恢复单字节 DMA 接收。
 * @param huart 产生错误的 UART 句柄。
 * @retval 无。
 * @note 由 HAL UART 中断回调调用；只恢复接收状态，不执行 Flash 或阻塞发送。
 */
void Vofa_Debug_OnUartError(UART_HandleTypeDef *huart);

#endif /* APP_TASK_VOFA_DEBUG_H */

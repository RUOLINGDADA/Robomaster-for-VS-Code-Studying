/**
  ******************************************************************************
  * @file    m3508_c620.c
  * @brief   C620 电调 + M3508 电机 CAN 驱动实现。
  *          Driver implementation for the C620 ESC and M3508 motor.
  *
  * 设计要点 / Design notes:
  *   1. 固定大小的静态注册表：CAN 接收中断需要在最短时间内由 StdId 找到句柄，
  *      遍历 8 个静态槽位比哈希或动态内存更可预测，也避免在中断上下文分配内存。
  *      A fixed-size static registry lets the RX interrupt map StdId to a handle by
  *      scanning 8 slots - predictable, and no allocation in interrupt context.
  *   2. 中断路径只做“过滤 -> 解码 -> 打时间戳”，不做控制、日志和阻塞调用。
  *      The ISR path only filters, decodes and timestamps.
  *   3. 所有 CAN 字段按大端（高字节在前）传输，STM32F407 内存为小端，因此必须
  *      逐字节移位拼接，不能把 uint8_t* 强转成 int16_t* 后直接读取。
  *      All CAN fields are big-endian while the STM32F407 core is little-endian, so
  *      bytes are combined by shifting; never cast the payload to int16_t*.
  *   4. 目标电流是命令缓存而非硬件寄存器，必须由上层周期调用 SendAll() 刷新。
  *      The target current is a command cache, not a hardware register, so the upper
  *      layer must call SendAll() periodically.
  ******************************************************************************
  */

#include "bsp/m3508_c620/m3508_c620.h"

#include <string.h>

/* ---------------------------------------------------------------------------
 * 静态注册表 / Static registry
 *
 * @note 使用文件级 static 数组而不是链表：
 *       - 位于 .bss 段，链接期即确定大小，不会因为 malloc 失败而在运行中退化；
 *       - 中断中遍历固定 8 项，最坏耗时恒定，便于估算中断时间；
 *       - 数组本身是文件私有（static），外部模块只能通过本文件的 API 访问，
 *         不会有人绕过状态机直接改句柄。
 *       A file-scope static array lives in .bss, has a fixed interrupt-time cost and
 *       stays private to this translation unit.
 * ------------------------------------------------------------------------- */
typedef struct {
  C620_M3508_HandleTypeDef *handle; /* 已注册句柄地址 / address of a registered handle */
  bool in_use;                      /* 槽位是否被占用 / slot occupancy flag */
} C620_M3508_SlotTypeDef;

static C620_M3508_SlotTypeDef g_c620_m3508_slots[C620_M3508_MAX_DEVICE_COUNT];

/* ---------------------------------------------------------------------------
 * 私有辅助函数 / Private helpers
 * ------------------------------------------------------------------------- */

/**
 * @brief  判断电调 ID 是否在协议允许的 1 ~ 8 范围内。
 *         Check whether the ESC ID is within the protocol range 1 ~ 8.
 * @param  motor_id 待检查的电调 ID / ESC ID to check.
 * @retval true  合法 / valid.
 * @retval false 越界 / out of range.
 */
static bool C620_M3508_IsValidId(uint8_t motor_id) {
  return motor_id >= C620_M3508_MIN_DEVICE_ID &&
         motor_id <= C620_M3508_MAX_DEVICE_ID;
}

/**
 * @brief  查询句柄是否已经在注册表中。
 *         Check whether the handle is already present in the registry.
 * @param  hmotor 待查询的句柄，可为 NULL / handle to query, may be NULL.
 * @retval true  已注册 / registered.
 * @retval false 未注册或为 NULL / not registered or NULL.
 */
static bool C620_M3508_IsRegistered(const C620_M3508_HandleTypeDef *hmotor) {
  if (hmotor == NULL) {
    return false;
  }
  for (uint8_t i = 0U; i < C620_M3508_MAX_DEVICE_COUNT; i++) {
    if (g_c620_m3508_slots[i].in_use &&
        g_c620_m3508_slots[i].handle == hmotor) {
      return true;
    }
  }
  return false;
}

/**
 * @brief  按“CAN 总线 + 电调 ID”查找已注册电机。
 *         Look up a registered motor by CAN bus and ESC ID.
 * @param  hcan 目标 CAN 总线句柄 / target CAN bus handle.
 * @param  motor_id 电调 ID / ESC ID.
 * @retval 命中的句柄；未找到时返回 NULL。
 *         Matching handle, or NULL when not found.
 *
 * @note   这是 CAN 接收中断的热路径函数：只做指针和整数比较，没有循环外的
 *         额外开销，也不做任何写操作，可安全地在 ISR 中并发调用。
 *         This is the ISR hot path: pointer/integer compares only, no writes, so it
 *         is safe to call concurrently from the RX interrupt.
 */
static C620_M3508_HandleTypeDef *C620_M3508_Find(CAN_HandleTypeDef *hcan,
                                                uint8_t motor_id) {
  for (uint8_t i = 0U; i < C620_M3508_MAX_DEVICE_COUNT; i++) {
    C620_M3508_HandleTypeDef *hmotor = g_c620_m3508_slots[i].handle;
    if (g_c620_m3508_slots[i].in_use && hmotor != NULL &&
        hmotor->config.hcan == hcan && hmotor->config.motor_id == motor_id) {
      return hmotor;
    }
  }
  return NULL;
}

/**
 * @brief  查询某条 CAN 总线上是否至少注册了一个电机。
 *         Check whether at least one motor is registered on a CAN bus.
 * @param  hcan 目标 CAN 总线句柄，可为 NULL / target bus handle, may be NULL.
 * @retval true  该总线上有已注册电机 / at least one registered motor exists.
 * @retval false 没有设备，或 hcan 为 NULL / no device, or hcan is NULL.
 *
 * @note   用于快速跳过没有任何设备的 CAN2，避免在空总线上无意义地占用发送邮箱。
 *         Lets SendAll() skip an unused bus such as CAN2 without touching a mailbox.
 */
static bool C620_M3508_HasDeviceOnBus(CAN_HandleTypeDef *hcan) {
  if (hcan == NULL) {
    return false;
  }
  for (uint8_t i = 0U; i < C620_M3508_MAX_DEVICE_COUNT; i++) {
    const C620_M3508_HandleTypeDef *hmotor = g_c620_m3508_slots[i].handle;
    if (g_c620_m3508_slots[i].in_use && hmotor != NULL &&
        hmotor->config.hcan == hcan) {
      return true;
    }
  }
  return false;
}

/**
 * @brief  读取大端 int16_t（高字节在前）。
 *         Read a big-endian int16_t (high byte first).
 * @param  data 指向 2 字节数据区，形参类型不写长度以免与协议宏不一致。
 *              Pointer to 2 payload bytes.
 * @retval 解码后的有符号值 / decoded signed value.
 *
 * @note   不能写 *(const int16_t *)data：小端 CPU 会得到字节交换后的错误值，
 *         而且未对齐地址在 Cortex-M4 上虽然多数情况允许，仍是 UB 且编译器可能
 *         按对齐前提做优化。
 *         Do not cast to int16_t*: the little-endian core would byte-swap the value
 *         and the potentially unaligned access is undefined behaviour.
 */
static int16_t C620_M3508_ReadI16Be(const uint8_t *data) {
  const uint16_t raw = ((uint16_t)data[0] << 8U) | (uint16_t)data[1];
  return (int16_t)raw;
}

/**
 * @brief  读取大端 uint16_t（高字节在前）。
 *         Read a big-endian uint16_t (high byte first).
 * @param  data 指向 2 字节数据区 / pointer to 2 payload bytes.
 * @retval 解码后的无符号值（角度原始值）/ decoded unsigned value (raw angle).
 */
static uint16_t C620_M3508_ReadU16Be(const uint8_t *data) {
  return (uint16_t)(((uint16_t)data[0] << 8U) | (uint16_t)data[1]);
}

/**
 * @brief  写入大端 int16_t（高字节在前）。
 *         Write a big-endian int16_t (high byte first).
 * @param  data 目标 2 字节数据区 / destination 2 payload bytes.
 * @param  value 待发送的有符号电流原始值 / signed raw current to send.
 * @retval 无 / none.
 *
 * @note   先转成 uint16_t 再右移，避免对负的有符号数做右移（实现定义行为），
 *         这样 -1 会被正确编码为 0xFF 0xFF。
 *         Converting to uint16_t before shifting avoids implementation-defined right
 *         shift of a negative value, so -1 encodes as 0xFF 0xFF.
 */
static void C620_M3508_WriteI16Be(uint8_t *data, int16_t value) {
  const uint16_t raw = (uint16_t)value;
  data[0] = (uint8_t)(raw >> 8U); /* 协议规定高字节先发 / protocol sends MSB first. */
  data[1] = (uint8_t)(raw & 0xFFU);
}

/**
 * @brief  取得某电调 ID 所属的控制帧 StdId。
 *         Get the control frame StdId that owns a given ESC ID.
 * @param  motor_id 电调 ID 1 ~ 8 / ESC ID 1 ~ 8.
 * @retval C620_M3508_CONTROL_ID_LOW（ID 1 ~ 4）或 C620_M3508_CONTROL_ID_HIGH。
 */
static uint32_t C620_M3508_ControlId(uint8_t motor_id) {
  return (motor_id <= 4U) ? C620_M3508_CONTROL_ID_LOW
                          : C620_M3508_CONTROL_ID_HIGH;
}

/**
 * @brief  取得某电调 ID 在聚合控制帧中的字节槽位下标（0 ~ 3）。
 *         Get the byte-slot index (0 ~ 3) of an ESC ID inside its control frame.
 * @param  motor_id 电调 ID 1 ~ 8 / ESC ID 1 ~ 8.
 * @retval 槽位下标；ID 1 ~ 4 对应 0 ~ 3，ID 5 ~ 8 同样对应 0 ~ 3。
 *         Slot index: ID 1 ~ 4 map to 0 ~ 3, and ID 5 ~ 8 do the same.
 *
 * @note   数据起始字节 = 2 * 槽位下标，所以 ID 5 落在 DATA[0:1] 而不是 DATA[8:9]。
 *         The first data byte is 2 * slot, so ID 5 lands in DATA[0:1], not DATA[8:9].
 */
static uint8_t C620_M3508_ControlSlot(uint8_t motor_id) {
  return (motor_id <= 4U) ? (uint8_t)(motor_id - 1U)
                          : (uint8_t)(motor_id - 5U);
}

/**
 * @brief  通过 HAL 发送一帧标准数据帧。
 *         Send one standard data frame through HAL.
 * @param  hcan 目标 CAN 总线句柄 / target bus handle.
 * @param  std_id 11 位标准帧 ID / 11-bit standard identifier.
 * @param  data 8 字节数据区 / 8-byte payload.
 * @retval true  已写入发送邮箱 / queued into a Tx mailbox.
 * @retval false 参数为空、无空闲邮箱或 HAL 返回错误。
 *               NULL argument, no free mailbox, or HAL error.
 *
 * @note   C620 控制帧是“广播订阅”语义：一条帧同时刷新 4 个电机，因此发送失败
 *         只影响本周期，不应在上层做重试风暴，否则会挤占总线并放大延迟。
 *         A control frame is broadcast to four motors; a failure only affects this
 *         period, so the upper layer should not build a retry storm around it.
 * @note   必须在 HAL_CAN_Start() 成功之后调用，否则 HAL 会返回错误状态。
 *         Must be called after a successful HAL_CAN_Start(), otherwise HAL errors.
 */
static bool C620_M3508_SendFrame(CAN_HandleTypeDef *hcan, uint32_t std_id,
                                 const uint8_t *data) {
  if (hcan == NULL || data == NULL) {
    return false;
  }
  /* 先查空闲邮箱：CAN 只有 3 个发送邮箱，忙时 AddTxMessage 会直接失败。 */
  if (HAL_CAN_GetTxMailboxesFreeLevel(hcan) == 0U) {
    return false;
  }

  CAN_TxHeaderTypeDef header = {0};
  uint32_t mailbox = 0U;
  header.StdId = std_id;                /* 标准帧 ID，不含 RTR/IDE 位 / 11-bit SID. */
  header.IDE = CAN_ID_STD;              /* C620 只使用标准帧 / standard frames only. */
  header.RTR = CAN_RTR_DATA;            /* 数据帧，不是远程请求帧 / data frame. */
  header.DLC = C620_M3508_FRAME_DLC;    /* 固定 8 字节，不能用 sizeof(data) 代替. */
  header.TransmitGlobalTime = DISABLE;  /* 不使用时间戳，保持与 CubeMX 配置一致. */

  return HAL_CAN_AddTxMessage(hcan, &header, (uint8_t *)data, &mailbox) == HAL_OK;
}

/* ---------------------------------------------------------------------------
 * 公开接口实现 / Public API implementation
 * ------------------------------------------------------------------------- */

bool C620_M3508_Init(C620_M3508_HandleTypeDef *hmotor,
                     const C620_M3508_ConfigTypeDef *config) {
  /* 参数与冲突检查集中放在最前面，避免把句柄改到一半才失败。 */
  if (hmotor == NULL || config == NULL || config->hcan == NULL ||
      !C620_M3508_IsValidId(config->motor_id)) {
    return false;
  }
  /* 同一总线同一 ID 只能有一个实例，否则两帧反馈会命中同一个槽位，状态混乱。 */
  if (C620_M3508_Find(config->hcan, config->motor_id) != NULL) {
    return false;
  }

  /* 清零整块句柄：未显式赋值的字段（state、标志位、反馈）全部为 0/false。 */
  memset(hmotor, 0, sizeof(*hmotor));

  /*
   * 这里做结构体值拷贝（*config），不是指针赋值。
   * 若写 hmotor->config = config 只保存地址，调用方传入栈上的局部 config 后，
   * 函数返回即失效，后续 hmotor->config.hcan 变成野指针并在中断里触发 HardFault。
   * Copy by value: storing the pointer would dangle as soon as the caller's local
   * config goes out of scope, and the RX interrupt would then dereference garbage.
   */
  hmotor->config = *config;
  if (hmotor->config.feedback_timeout_ms == 0U) {
    hmotor->config.feedback_timeout_ms = C620_M3508_FEEDBACK_TIMEOUT_MS;
  }

  /* 在静态注册表中找一个空槽；所有槽都占用时返回 false，不做动态扩展。 */
  for (uint8_t i = 0U; i < C620_M3508_MAX_DEVICE_COUNT; i++) {
    if (!g_c620_m3508_slots[i].in_use) {
      g_c620_m3508_slots[i].handle = hmotor;
      g_c620_m3508_slots[i].in_use = true;
      /*
       * 初始状态必须是 OFFLINE 而不是 ONLINE：此刻还没有任何反馈证据，
       * 只有真正收到 0x20x 帧之后才允许上层把它当作在线设备。
       * Start OFFLINE: no feedback exists yet, so nothing may be treated as online.
       */
      hmotor->state = C620_M3508_STATE_OFFLINE;
      hmotor->initialized = true;
      return true;
    }
  }

  return false;
}

bool C620_M3508_DeInit(C620_M3508_HandleTypeDef *hmotor) {
  if (!C620_M3508_IsRegistered(hmotor)) {
    return false;
  }

  for (uint8_t i = 0U; i < C620_M3508_MAX_DEVICE_COUNT; i++) {
    if (g_c620_m3508_slots[i].handle == hmotor) {
      g_c620_m3508_slots[i].handle = NULL;
      g_c620_m3508_slots[i].in_use = false;
      break;
    }
  }
  /* 清零句柄本身，使再次 Init() 前的一切 API 调用都因 initialized=false 失败。 */
  memset(hmotor, 0, sizeof(*hmotor));
  return true;
}

bool C620_M3508_SetCurrent(C620_M3508_HandleTypeDef *hmotor,
                           int16_t current_raw) {
  if (!C620_M3508_IsRegistered(hmotor) || !hmotor->initialized) {
    return false;
  }

  /*
   * 饱和而不是回绕或直接拒绝：C620 的线性区约为 ±16384，
   * 上层控制器输出超限时应当被钳位在硬件可表达的最大值，而不是触发回绕
   * （-16385 回绕会变成 +16383，方向反转，非常危险）。
   * Saturate instead of wrapping: -16385 would wrap to +16383 and reverse torque.
   */
  if (current_raw < C620_M3508_CURRENT_RAW_MIN) {
    current_raw = C620_M3508_CURRENT_RAW_MIN;
  } else if (current_raw > C620_M3508_CURRENT_RAW_MAX) {
    current_raw = C620_M3508_CURRENT_RAW_MAX;
  }
  hmotor->target_current_raw = current_raw;
  return true;
}

bool C620_M3508_SetOutputEnabled(C620_M3508_HandleTypeDef *hmotor,
                                 bool enabled) {
  if (!C620_M3508_IsRegistered(hmotor) || !hmotor->initialized) {
    return false;
  }

  /* 保存并恢复 PRIMASK，避免任务改状态时接收 ISR 插入；不依赖 RTOS。
   * Preserve the previous interrupt mask while updating shared output state. */
  const uint32_t saved_primask = __get_PRIMASK();
  __disable_irq();
  hmotor->output_enabled = enabled;
  if (enabled) {
    /* 重新使能即视为一次明确的人工/上层确认，清除掉线后的重新锁定标志。 */
    hmotor->requires_rearm = false;
    /* 输出开关不是通信证据；离线使能不能伪造 ONLINE。 / Arming cannot fake feedback. */
    hmotor->state = C620_M3508_IsOnline(hmotor)
                        ? C620_M3508_STATE_READY
                        : C620_M3508_STATE_OFFLINE;
  } else {
    /* 关闭输出必须同时清零目标，否则下一个周期还会把旧电流发出去。 */
    hmotor->target_current_raw = 0;
    hmotor->state = C620_M3508_IsOnline(hmotor)
                        ? C620_M3508_STATE_DISABLED
                        : C620_M3508_STATE_OFFLINE;
    /* 关闭输出不解除超时锁止；仅显式使能才清除 requires_rearm。 */
  }
  __set_PRIMASK(saved_primask);
  return true;
}

bool C620_M3508_HandleRxMessage(CAN_HandleTypeDef *hcan,
                                const CAN_RxHeaderTypeDef *rx_header,
                                const uint8_t data[C620_M3508_FRAME_DLC]) {
  /* 帧合法性检查：只接受标准数据帧、8 字节、ID 落在 0x201 ~ 0x208。 */
  if (hcan == NULL || rx_header == NULL || data == NULL ||
      rx_header->IDE != CAN_ID_STD || rx_header->RTR != CAN_RTR_DATA ||
      rx_header->DLC != C620_M3508_FRAME_DLC ||
      rx_header->StdId <= C620_M3508_FEEDBACK_ID_BASE ||
      rx_header->StdId > C620_M3508_FEEDBACK_ID_BASE +
                             C620_M3508_MAX_DEVICE_ID) {
    return false;
  }

  const uint8_t motor_id =
      (uint8_t)(rx_header->StdId - C620_M3508_FEEDBACK_ID_BASE);
  C620_M3508_HandleTypeDef *hmotor = C620_M3508_Find(hcan, motor_id);
  if (hmotor == NULL) {
    /* 过滤器可能放过 0x200（广播帧）或其它 ID，此处按未注册处理并丢弃。 */
    return false;
  }

  /*
   * 标准反馈帧布局（C620 说明书）：
   *   DATA[0:1] 转子机械角度原始值，uint16 大端，0 ~ 8191
   *   DATA[2:3] 转子转速，int16 大端，单位 rpm
   *   DATA[4:5] 实际转矩电流，int16 大端，与指令同一原始标度
   *   DATA[6]   电调温度，uint8，单位摄氏度
   *   DATA[7]   原始错误码，用户资料给出枚举；原样保存，不按状态位拆分。
   * 中断里只解码并记录时间，控制决策留给任务，避免拖长中断时间影响 CAN 吞吐。
   * The ISR decodes and timestamps only; control decisions stay in the task.
   */
  hmotor->feedback.angle_raw = C620_M3508_ReadU16Be(&data[0]);
  hmotor->feedback.speed_rpm = C620_M3508_ReadI16Be(&data[2]);
  hmotor->feedback.current_raw = C620_M3508_ReadI16Be(&data[4]);
  hmotor->feedback.temperature_c = data[6];
  hmotor->feedback.error_code = data[7];
  /*
   * 使用 HAL_GetTick() 而不是 FreeRTOS 的 xTaskGetTickCount()：
   * HAL_GetTick() 由 TIM6 中断维护，在调度器启动前和中断上下文里都可用；
   * xTaskGetTickCount() 在调度器运行前返回值没有意义，且不能在 ISR 中随意使用。
   * HAL_GetTick() works before the scheduler starts and inside ISRs.
   */
  hmotor->feedback.last_feedback_tick = HAL_GetTick();
  /* 两个时间戳必须同步，否则 Process() 会在上电 100 ms 后永久超时。
   * Keep the diagnostic and timeout timestamps in sync on every valid frame. */
  hmotor->last_feedback_tick = hmotor->feedback.last_feedback_tick;
  hmotor->feedback_received = true;

  /* 收到有效反馈即证明通信链路可用，据此提升状态（不改变输出使能）。 */
  if (hmotor->output_enabled) {
    hmotor->state = C620_M3508_STATE_READY;
  } else if (hmotor->state == C620_M3508_STATE_OFFLINE) {
    hmotor->state = C620_M3508_STATE_ONLINE;
  }
  return true;
}

bool C620_M3508_RxFifoCallback(CAN_HandleTypeDef *hcan, uint32_t rx_fifo) {
  CAN_RxHeaderTypeDef rx_header = {0};
  uint8_t data[C620_M3508_FRAME_DLC] = {0};

  /*
   * 每次只取一帧：本函数由 FIFO0 pending 中断驱动，只要 FIFO 中还有帧，
   * HAL 会再次进入中断。用循环一次取空反而会延长单次中断时间，恶化实时性。
   * Fetch one frame per interrupt; HAL re-enters while frames remain pending.
   */
  if (hcan == NULL ||
      HAL_CAN_GetRxMessage(hcan, rx_fifo, &rx_header, data) != HAL_OK) {
    return false;
  }
  return C620_M3508_HandleRxMessage(hcan, &rx_header, data);
}

bool C620_M3508_SendAll(CAN_HandleTypeDef *hcan) {
  /* 该总线上没有任何注册设备时直接返回成功，不占用发送邮箱。 */
  if (!C620_M3508_HasDeviceOnBus(hcan)) {
    return true;
  }

  /*
   * 两条帧的载荷先全部填 0，再按注册顺序把各电机电流写进对应槽位。
   * 未被任何电机占用的槽位保持 0，等价于“该 ID 的电机电流指令为 0”，
   * 因此不会出现“某电调收到上一次残留数据”的情况。
   * Start from an all-zero payload so unused slots command exactly 0 A.
   */
  uint8_t low_data[C620_M3508_FRAME_DLC] = {0};   /* ID 1 ~ 4 的 0x200 载荷. */
  uint8_t high_data[C620_M3508_FRAME_DLC] = {0};  /* ID 5 ~ 8 的 0x1FF 载荷. */
  bool low_used = false;                          /* 0x200 是否需要发送. */
  bool high_used = false;                         /* 0x1FF 是否需要发送. */

  for (uint8_t i = 0U; i < C620_M3508_MAX_DEVICE_COUNT; i++) {
    C620_M3508_HandleTypeDef *hmotor = g_c620_m3508_slots[i].handle;
    if (!g_c620_m3508_slots[i].in_use || hmotor == NULL ||
        hmotor->config.hcan != hcan) {
      continue; /* 跳过空槽和其它总线上的电机 / skip empty slots and other buses. */
    }

    /* 未使能输出时强制 0；掉线后 requires_rearm 未清除时同样强制 0。 */
    const int16_t current =
        (hmotor->output_enabled && !hmotor->requires_rearm)
            ? hmotor->target_current_raw
            : (int16_t)0;

    /*
     * 控制帧 ID 与字节槽位由同一个 motor_id 唯一决定：
     * 两条帧（0x200 / 0x1FF）结构完全相同，先算 ID 再按槽位写载荷，
     * 可以避免“ID 算对了但写进了另一条帧”这类难以察觉的错误。
     * The frame ID and the byte slot are both derived from the same motor_id.
     */
    const uint32_t control_id = C620_M3508_ControlId(hmotor->config.motor_id);
    const uint8_t slot = C620_M3508_ControlSlot(hmotor->config.motor_id);
    if (control_id == C620_M3508_CONTROL_ID_LOW) {
      /*
       * slot 与起始字节的对应关系：
       *   slot=0 -> DATA[0:1] (ID1)   slot=1 -> DATA[2:3] (ID2)
       *   slot=2 -> DATA[4:5] (ID3)   slot=3 -> DATA[6:7] (ID4)
       */
      C620_M3508_WriteI16Be(&low_data[2U * slot], current);
      low_used = true;
    } else {
      C620_M3508_WriteI16Be(&high_data[2U * slot], current);
      high_used = true;
    }
  }

  /*
   * 只有帧内确实有本总线的设备时才发送，避免每周期向总线注入无意义的帧。
   * 一旦 low_used 为真就必须尝试发送：失败也返回 false 交由上层统计，
   * 但驱动不在这里阻塞等待邮箱，控制周期的稳定性优先于单帧可靠性。
   * Transmit only frames that own a device; a failure is reported, never retried here.
   */
  if (low_used &&
      !C620_M3508_SendFrame(hcan, C620_M3508_CONTROL_ID_LOW, low_data)) {
    return false;
  }
  if (high_used &&
      !C620_M3508_SendFrame(hcan, C620_M3508_CONTROL_ID_HIGH, high_data)) {
    return false;
  }
  return true;
}

bool C620_M3508_Process(C620_M3508_HandleTypeDef *hmotor, uint32_t now_tick) {
  if (!C620_M3508_IsRegistered(hmotor) || !hmotor->initialized) {
    return false;
  }

  /* 保护时间戳判定和状态写回，避免新反馈被随后写入的 OFFLINE 覆盖。
   * Keep the timeout decision and state update atomic with respect to RX. */
  const uint32_t saved_primask = __get_PRIMASK();
  __disable_irq();
  /*
   * 接收时间戳来自 HAL_GetTick()，调用方 now_tick 必须用同一 HAL 毫秒时钟。
   * 若混用 FreeRTOS tick，两者基准不同，
   * 时间差会变成无意义的巨大数字并导致电机被误判为永久离线。
   * Both timestamps must use the HAL clock; mixing FreeRTOS tick with
   * HAL tick would produce a meaningless difference and a false permanent timeout.
   *
   * 无符号减法天然处理回绕：真实间隔须小于 2^31 ms（约 24.9 天），
   * 即使 HAL tick 在两次调用之间溢出，差值依然正确。
   * Unsigned subtraction handles wrap-around for gaps shorter than ~24.9 days.
   */
  const uint32_t elapsed_ms = now_tick - hmotor->last_feedback_tick;
  /* 任务采样 now_tick 后 ISR 可能更新更晚的时间戳；半周期内的未来值视为新反馈。
   * A newer ISR timestamp is fresh, not a wrapped multi-day timeout. */
  if (!hmotor->feedback_received ||
      (elapsed_ms <= UINT32_MAX / 2U &&
       elapsed_ms > hmotor->config.feedback_timeout_ms)) {
    /*
     * 掉线处理顺序：先清零目标、再关闭输出、最后置重新锁定标志。
     * 三者缺一不可：
     *   - 只清零目标不关输出，下一帧反馈恢复时旧电流可能已被上层重新写入；
     *   - 不置 requires_rearm，通信恢复后 SendAll() 会立刻恢复掉线前的力矩，
     *     这在底盘上表现为“接触不良时突然窜车”。
     * Zero the target, disarm the output, then latch requires_rearm so a recovered
     * link cannot silently resume the pre-fault torque.
     */
    hmotor->target_current_raw = 0;
    hmotor->output_enabled = false;
    hmotor->requires_rearm = hmotor->feedback_received;
    hmotor->state = C620_M3508_STATE_OFFLINE;
    __set_PRIMASK(saved_primask);
    return true;
  }

  /*
   * 通信恢复 / Link recovered:
   * 这里只把状态从 OFFLINE 提升回 ONLINE，**不清除 requires_rearm**。
   * 原因：上层任务常见的写法是每个周期无条件调用 SetCurrent()，也就是掉线期间
   * target_current_raw 会被反复写回非零值。如果这里顺手清掉 requires_rearm，
   * 那么本函数之后的 SendAll() 就会把掉线前的旧电流直接发出去 ——
   * 而这恰好是 requires_rearm 要防的“接触不良恢复瞬间窜车”。
   * 因此重新允许输出的唯一入口是上层的 SetOutputEnabled(handle, true)，
   * 由它清除 requires_rearm；驱动不在后台自动解除锁止。
   * Only SetOutputEnabled(true) clears requires_rearm. Clearing it here would let
   * SendAll() resume a non-zero target that the caller re-wrote while offline.
   * 状态要重新变成 READY，需要收到下一帧反馈（见 HandleRxMessage）或上层使能。
   */
  if (hmotor->state == C620_M3508_STATE_OFFLINE) {
    hmotor->state = C620_M3508_STATE_ONLINE;
  }
  __set_PRIMASK(saved_primask);
  return true;
}

bool C620_M3508_GetFeedback(const C620_M3508_HandleTypeDef *hmotor,
                            C620_M3508_FeedbackTypeDef *feedback) {
  if (!C620_M3508_IsRegistered(hmotor) || !hmotor->initialized ||
      feedback == NULL) {
    return false;
  }
  /* 复制期间短暂屏蔽 ISR，保证角度、电流与时间戳来自同一帧。
   * A short interrupt-masked copy returns a consistent feedback snapshot. */
  const uint32_t saved_primask = __get_PRIMASK();
  __disable_irq();
  *feedback = hmotor->feedback;
  __set_PRIMASK(saved_primask);
  return true;
}

bool C620_M3508_IsOnline(const C620_M3508_HandleTypeDef *hmotor) {
  if (hmotor == NULL || !hmotor->initialized) {
    return false;
  }
  /* DISABLED 仅表示输出关闭，必须有真实反馈才算在线。 / Require real feedback. */
  return hmotor->feedback_received && hmotor->state != C620_M3508_STATE_OFFLINE &&
         hmotor->state != C620_M3508_STATE_UNINITIALIZED;
}

bool C620_M3508_RequiresRearm(const C620_M3508_HandleTypeDef *hmotor) {
  return (hmotor != NULL) && hmotor->initialized && hmotor->requires_rearm;
}

C620_M3508_StateTypeDef
C620_M3508_GetState(const C620_M3508_HandleTypeDef *hmotor) {
  if (hmotor == NULL || !hmotor->initialized) {
    return C620_M3508_STATE_UNINITIALIZED;
  }
  return hmotor->state;
}

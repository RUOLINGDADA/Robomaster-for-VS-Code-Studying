# task_vofa_debug —— USART1 蓝牙调参与 VOFA 波形

任务使用 CubeMX 已配置的 USART1（9600 baud、8N1、DMA2 Stream2/7）。RX 使用 Stream2 的
单字节循环 DMA，每收到一个字节进入轻量解析器；每 100 ms 发送一帧
VOFA JustFloat，19 个通道依次为四轮目标转速、四轮反馈转速、四轮反馈电流、四个 DR16 通道和
Kp/Ki/Kd。TX DMA 忙时跳过本周期，避免阻塞底盘控制。

上位机发送 18 字节小端帧：`A5 5A cmd len payload CRC16`。`cmd=1` 更新统一四轮速度 PID，
`cmd=2` 保存到 Sector 11，`cmd=3` 返回当前参数。CRC 使用 CRC-16/IBM，参数使用有限值和安全
范围校验。ACK 使用 `cmd|0x80`、状态码、可选参数和 CRC16。

数值滑条可以通过“绑定命令”发送文本行直接调参。需要先在 VOFA+ 的“命令”面板/命令管理器
中新建三个 `Str` 类型命令（例如 `Set_KP`、`Set_KI`、`Set_KD`），再右键滑条选择“绑定命令”
并选中对应命令。三个命令内容分别为
`KP=%f\r\n`、`KI=%f\r\n`、`KD=%f\r\n`；VOFA+ 会把 `%f` 替换为滑条当前值。
不要把这三个命令设为 `Hex` 类型。固件也支持 `KP=4.5`、`KI:2.0`、`KD 0.5`，以及一次发送
`PID=4.5,2.0,0.5`。文本调参只更新 RAM 待应用值，保存仍使用二进制 `SAVE` 命令；
成功时回送 `OK\r\n`，错误时回送 `ERR\r\n`，生效后的 Kp/Ki/Kd 可从 JustFloat 的 16~18 通道确认。

SET 参数先写入待应用区，由普通底盘或小陀螺任务在控制周期边界应用并清除 PID 历史。SAVE 时
模式管理器挂起所有工作任务、清零并发送零电流，完成 Flash 擦写后恢复模式。Flash 保存失败时
继续保持维护停机，直到复位或后续成功保存。任务不操作 CAN，DMA 回调不执行 Flash 和阻塞调用。

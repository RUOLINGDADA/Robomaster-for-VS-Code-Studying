# task_m3508_can_test —— 底盘 CAN 环路自检任务

## 模块职责

任务只负责 DR16 `switch_s1=1` 时的电机自检。底盘遥控由独立的
`task_chassis_control` 负责，二者由 `task_chassis_mode_manager` 互斥挂起和唤醒。
具体验证两件事：

1. **发送侧**：每 2 ms 向 CAN1 发出 `0x200` 聚合控制帧，帧内 4 个槽位分别对应电调
   ID 1 ~ 4，电机应当能被驱动；
2. **接收侧**：电调每约 1 ms 主动上报 `0x201 ~ 0x204`，确认能收到角度、转速、实际电流、
   温度和错误码。

它仍不负责 PID、速度环和功率限制。

## 文件

```text
Core/Src/app/task_m3508_can_test/app_task_m3508_can_test.c
Core/Inc/app/task_m3508_can_test/app_task_m3508_can_test.h
```

任务对象在 `Core/Src/freertos.c` 的 `USER CODE BEGIN Variables` 中声明，
并在 `USER CODE BEGIN RTOS_THREADS` 中创建。

## 依赖

| 依赖 | 用途 |
|---|---|
| `bsp/board_can` | `BoardCan_PollRxFifo0()` 在中断里被调用 |
| `bsp/m3508_c620` | 设备注册、反馈读取、聚合发送 |
| `app/chassis_motors` | 统一电机句柄、超时处理和安全停止 |
| `can.h` | `hcan1` |
| FreeRTOS / CMSIS-RTOS V2 | 任务、`vTaskDelayUntil`、`osThreadNew` |

前置条件：`main()` 已完成 `MX_GPIO_Init()`、`MX_CAN1_Init()`、`BoardCan_Init()`。

## 任务参数

| 项目 | 值 | 依据 |
|---|---|---|
| 任务名 | `chassisCanTest` | — |
| 栈 | 512 字 = **2048 字节** | 调用 `printf`，`newlib-nano` 格式化路径栈开销大 |
| 优先级 | `osPriorityNormal` | 控制帧靠固定 2 ms 周期保证，不需要抢占 |
| 周期 | 2 ms（`vTaskDelayUntil`） | C620 电流指令需要连续刷新；固定节拍避免累计漂移 |
| 阻塞点 | `vTaskSuspend`、`vTaskDelayUntil` | 非测试模式永久挂起，任务入口不返回 |

## 状态机

| 阶段 | 行为 | 退出条件 |
|---|---|---|
| `WAIT_FEEDBACK` | 输出关闭，持续发送零电流 | 至少 1 个电调有反馈 → `ARM_DELAY` |
| `ARM_DELAY` | 继续零电流，等待机械稳定 50 ms | 超时 → `SPIN_POSITIVE` |
| `SPIN_POSITIVE` | 按掩码输出 +500 原始值（约 +0.6 A）1000 ms | 超时 → `SPIN_NEGATIVE` |
| `SPIN_NEGATIVE` | 输出 -500 原始值 1000 ms | 超时 → `SPIN_POSITIVE`（循环） |

每轮只选取 `M3508_TEST_SPIN_MASK` 内已经收到反馈的电机；自转期间这些电机掉线或需要重新使能时，
立即清空所有目标电流并退回 `WAIT_FEEDBACK`。未接入的其它电机槽位保持 0，不阻断单电机台架测试。

## 安全策略

1. **先零电流再使能**：上电后只发零电流，确认至少一个电调有反馈后才允许叠加测试电流。
   这样即使接线错误或电调 ID 不对，也不会有意外力矩。
2. **只让已收到反馈的掩码电机转**：当前掩码为 `0x0F`，但每轮只冻结启动时在线的电机；
   未接入或未收到反馈的槽位保持零电流。只测试 ID 2 时把掩码改成 `0x02`。
3. **落回等待阶段**：任何链路抖动都不会直接继续输出，而是回到零电流等待重新确认。
4. **测试电流很小**：`M3508_TEST_CURRENT_RAW = 500`，约 0.6 A，只够空载缓慢转动。
5. **驱动层兜底**：即使任务逻辑出错，驱动的 `Process()` 仍会在超时后清零并锁止输出。

## 关键参数

| 宏 | 默认值 | 含义 / 调整建议 |
|---|---|---|
| `M3508_TEST_PERIOD_MS` | 2 | 控制周期。底盘电流环常用 1 ~ 2 ms，不建议大于 5 ms |
| `C620_M3508_FEEDBACK_TIMEOUT_MS` | 100 | 反馈超时阈值 |
| `M3508_TEST_FEEDBACK_WARN_MS` | 3000 | 等待反馈多久后打印一次排查提示 |
| `M3508_TEST_ARM_DELAY_MS` | 50 | 收到反馈后到叠加电流之间的缓冲 |
| `M3508_TEST_PHASE_MS` | 1000 | 每个正/反转测试段的时长 |
| `M3508_TEST_CURRENT_RAW` | 500 | 测试电流原始值（约 0.6 A） |
| `M3508_TEST_SPIN_MASK` | `0x0F` | bit0 ~ bit3 对应 1 ~ 4 号电机；每轮只选启动时有反馈者 |
| `M3508_TEST_LOG_PERIOD_MS` | 500 | 日志限频；串口远慢于 CAN，必须独立限频 |

## 任务互斥

`switch_s1=1` 时本任务由模式管理任务唤醒；切换到其它档位时先挂起本任务、清零并发送一帧，
然后才唤醒目标任务。本任务不会读取底盘目标数组，也不会与底盘任务同时发送 CAN。

## 测试模式与 PID

`M3508Test_BuildTargetCurrents()` 是目前唯一决定“发多少电流”的函数。接入 PID 时把它内部
的 `test_value` 换成控制器输出即可；底盘模式的 PID 扩展点位于
`app/chassis_control`，发送时序、在线判断和驱动 API 不需要改动：

```c
static void M3508Test_BuildTargetCurrents(
    int16_t target_current[CHASSIS_MOTORS_COUNT]) {
  /* 现在：固定测试电流。将来：current_raw[i] = (int16_t)Pid_Calc(&g_pid[i], feedback, target); */
}
```

## 中断入口

`HAL_CAN_RxFifo0MsgPendingCallback()` 已集中放在 `app/chassis_motors`，本任务不再拥有
CAN 回调。该回调运行在 `CAN1_RX0_IRQn`（优先级 5），只做取帧和解码，**不打印、不阻塞、
不调用非 `FromISR` 的 FreeRTOS API**。

## 调试与日志现状（重要）

任务使用 `printf()` 输出状态，但**当前工程没有任何串口输出**：

- `.ioc` 未启用任何 USART；
- `syscalls.c` 的 `_write()` 把字节交给 `__io_putchar()`，而后者只有 `weak` 声明，
  全工程无强定义；
- 结果是 `printf()` 正常返回但不产生任何字符。

因此当前阶段的调试手段是**用调试器观察变量**：

| 变量 | 期望值 |
|---|---|
| `g_c620_m3508_slots[i].in_use` | `Init()` 后 4 个槽位为 `true` |
| `g_chassis_motors[i].state` | 收到反馈后为 `ONLINE`(2) / `READY`(3) |
| `g_chassis_motors[i].feedback_received` | 收到过有效反馈后为 `true` |
| `g_chassis_motors[i].feedback.angle_raw` | 电机转动时持续变化（0 ~ 8191） |
| `g_chassis_motors[i].feedback.speed_rpm` | 自转时非零 |
| `g_chassis_motors[i].last_feedback_tick` | 持续更新，与 `HAL_GetTick()` 差距 < 100 |
| `g_chassis_can_test_task_handle` | 非 NULL，否则任务创建失败（堆不足） |

要让 `printf` 生效，需要先询问用户并二选一：启用一个 USART 并在
`/* USER CODE BEGIN 4 */` 中实现 `__io_putchar()`；或改用 SWO/ITM、RTT 实现。
详见 [../../PROJECT_CONTEXT.md](../../PROJECT_CONTEXT.md)。

## 上板验证步骤

1. 编译烧录，确认 `g_chassis_can_test_task_handle != NULL`。
2. 电调上电，观察是否至少 1 个电机的 `state` 离开 `OFFLINE`。
   - 若 3 s 后仍全部 `OFFLINE`，按顺序排查：电调上电 → CANH/CANL 是否接反 →
     120 Ω 终端电阻 → 波特率是否 1 Mbit/s → 电调 ID 是否与代码一致 →
     过滤器与 `CAN1_RX0_IRQn` 是否生效。
3. 用 CAN 分析仪确认主控每 2 ms 发出 `0x200` 帧，电调回 `0x201 ~ 0x204`。
4. 确认掩码内已在线电机在约 50 ms 后开始缓慢正转 1 s、反转 1 s，交替。
5. 确认 `feedback.current_raw` 随指令变化，`temperature_c` 在合理范围（< 60 ℃）。
6. 拔掉 CAN 线验证保护：应在 100 ms 内进入 `OFFLINE`，
   `target_current_raw == 0`、`output_enabled == false`、`requires_rearm == true`。
   插回后电机**不应**自动转动，需要上层重新使能。

## 已知限制

- 只做正反转交替的自转测试，没有速度闭环，转速会随电池电压和负载漂移。
- 没有电流、温度、功率保护，长时间堵转仍可能过热。
- 日志当前无输出（见上）。
- 测试电流和周期都是硬件相关的经验值，换电机或换电池后需重新确认。

/**
  ******************************************************************************
  * @file    chassis_motors.h
  * @brief   底盘四个 M3508 电机的公共注册和安全操作接口。
  *
  * 本模块集中保存四个电机句柄，负责注册、CAN 反馈处理和全电机停止操作。
  * 测试任务与底盘任务共享这些句柄，但同一时刻只允许一个任务发送控制帧。
  ******************************************************************************
  */

#ifndef CHASSIS_MOTORS_H
#define CHASSIS_MOTORS_H

#include "bsp/m3508_c620/m3508_c620.h"

#include <stdbool.h>
#include <stdint.h>

/** 底盘电机数量；数组顺序为下标0=ID1右前、下标1=ID2左前、下标2=ID3左后、下标3=ID4右后。 */
#define CHASSIS_MOTORS_COUNT 4U

/**
 * 四个底盘电机的公共句柄，任务共享访问；反馈字段由 CAN 接收中断更新。
 */
extern C620_M3508_HandleTypeDef g_chassis_motors[CHASSIS_MOTORS_COUNT];

/**
 * @brief 注册并初始化 CAN1 上的四个底盘电机。
 * @retval true 四个电机全部注册成功。
 * @retval false 任一电机注册失败。
 * @note 运行在模式管理任务中；必须在工作任务开始前调用一次。
 */
bool ChassisMotors_Init(void);

/**
 * @brief 处理四个电机的反馈超时和状态迁移。
 * @param now_tick 与 HAL_GetTick() 同源的当前毫秒 tick。
 * @retval 无。
 * @note 运行在当前拥有电机控制权的工作任务中。
 */
void ChassisMotors_Process(uint32_t now_tick);

/**
 * @brief  写入一个电机的逻辑目标电流，并自动修正安装方向。
 * @param  motor_index 电机数组下标，0~3 对应电调 ID 1~4。
 * @param  logical_current_raw 上层逻辑电流，正值统一表示该轮正方向。
 * @retval true 下标有效且目标已写入；false 下标越界或电机尚未初始化。
 * @note   运行在任务上下文；不会立即发送 CAN，发送由 ChassisMotors_Send() 完成。
 */
bool ChassisMotors_SetCurrent(uint32_t motor_index,
                              int16_t logical_current_raw);

/**
 * @brief 获取与逻辑电流方向一致的转子转速。
 * @param motor_index 下标0~3，对应电调 ID 1~4。
 * @param speed_rpm 输出逻辑转子 rpm，不能为 NULL；轮子 rpm 须再除以减速比。
 * @retval true 已取得在线电机反馈；false 越界、离线或读取失败，输出置0。
 * @note 任务调用，内部复制反馈快照；与 SetCurrent 共用方向表，原始反馈保持不变。
 */
bool ChassisMotors_GetSpeedRpm(uint32_t motor_index, float *speed_rpm);

/**
 * @brief 获取与逻辑方向一致的电调反馈电流。
 * @param motor_index 下标0~3，对应电调 ID 1~4。
 * @param current_a 输出电流，单位 A，不能为 NULL。
 * @retval true 已取得在线反馈；false 越界、离线或读取失败，输出置0。
 * @note 使用 C620 原始量换算，约 16384 raw = 20 A，并应用安装方向修正。
 */
bool ChassisMotors_GetCurrentA(uint32_t motor_index, float *current_a);

/**
 * @brief 关闭并清零四个电机。
 * @retval 无。
 * @note 可由模式管理任务或工作任务调用；不会阻塞等待 CAN 邮箱。
 */
void ChassisMotors_StopAll(void);

/**
 * @brief 发送四个电机的聚合控制帧。
 * @retval true HAL 接受发送请求。
 * @retval false 当前没有可用 CAN 发送邮箱或发送失败。
 */
bool ChassisMotors_Send(void);

#endif /* CHASSIS_MOTORS_H */

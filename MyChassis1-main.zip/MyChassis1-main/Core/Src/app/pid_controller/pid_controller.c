/**
  ******************************************************************************
  * @file    pid_controller.c
  * @brief   带工程常用保护项的 PID 和双环级联计算。
  *
  * 普通任务调用，控制器对象由单一调用方独占；不操作硬件、不阻塞、不处理角度回绕。
  ******************************************************************************
  */

#include "app/pid_controller/pid_controller.h"

#include <math.h>
#include <stddef.h>

/** 2π，用于把微分截止频率 Hz 换算为一阶滤波时间常数。 */
#define PID_TWO_PI 6.283185307f

static float Pid_Abs(float value) { return value >= 0.0f ? value : -value; }

static float Pid_Limit(float value, float limit) {
  if (limit < 0.0f) {
    limit = -limit;
  }
  if (value > limit) {
    return limit;
  }
  if (value < -limit) {
    return -limit;
  }
  return value;
}

static float Pid_IntegralRate(const Pid_ControllerConfigTypeDef *config,
                              float error) {
  /* 用户指定倒数形式：大误差时平滑减弱积分，a=0 时恢复普通梯形积分。 */
  return 1.0f / (1.0f + config->integral_error_scale * Pid_Abs(error));
}

bool Pid_Controller_Init(Pid_ControllerTypeDef *controller,
                         const Pid_ControllerConfigTypeDef *config) {
  if (controller == NULL) {
    return false;
  }
  *controller = (Pid_ControllerTypeDef){0};
  if (config == NULL || !isfinite(config->kp) || !isfinite(config->ki) ||
      !isfinite(config->kd) || !isfinite(config->output_limit) ||
      !isfinite(config->integral_limit) ||
      !isfinite(config->integral_error_scale) ||
      !isfinite(config->derivative_cutoff_hz) || config->output_limit < 0.0f ||
      config->integral_limit < 0.0f || config->integral_error_scale < 0.0f ||
      config->derivative_cutoff_hz < 0.0f) {
    return false;
  }
  controller->config = *config;
  Pid_Controller_Reset(controller);
  return true;
}

void Pid_Controller_Reset(Pid_ControllerTypeDef *controller) {
  if (controller == NULL) {
    return;
  }
  controller->integral = 0.0f;
  controller->previous_error = 0.0f;
  controller->previous_measurement = 0.0f;
  controller->derivative_filtered = 0.0f;
  controller->initialized = false;
}

float Pid_Controller_Calc(Pid_ControllerTypeDef *controller, float target,
                          float measurement, float dt_s) {
  if (controller == NULL || !isfinite(target) || !isfinite(measurement) ||
      !isfinite(dt_s) || dt_s <= 0.0f) {
    return 0.0f;
  }

  const float error = target - measurement;
  if (!controller->initialized) {
    controller->previous_error = error;
    controller->previous_measurement = measurement;
    controller->initialized = true;
  }

  /* 梯形积分：使用前后两个误差，减少固定采样周期下的积分偏差。 */
  const float integral_area =
      0.5f * (error + controller->previous_error) * dt_s;
  const float integral_change = controller->config.ki * integral_area *
      Pid_IntegralRate(&controller->config, error);
  const float candidate_integral = Pid_Limit(
      controller->integral + integral_change, controller->config.integral_limit);

  /* 微分先行：只对测量值求导，目标阶跃不会直接制造微分尖峰。 */
  const float derivative_measurement =
      (measurement - controller->previous_measurement) / dt_s;
  float derivative_output = -controller->config.kd * derivative_measurement;
  if (controller->config.derivative_cutoff_hz > 0.0f) {
    const float rc = 1.0f / (PID_TWO_PI *
                             controller->config.derivative_cutoff_hz);
    const float alpha = dt_s / (rc + dt_s);
    controller->derivative_filtered +=
        alpha * (derivative_output - controller->derivative_filtered);
    derivative_output = controller->derivative_filtered;
  } else {
    controller->derivative_filtered = derivative_output;
  }

  /* 输出已饱和时不继续同方向累积积分，但允许反向积分把输出拉回，防止 wind-up。 */
  const float proportional_derivative = controller->config.kp * error +
                                        derivative_output;
  const float candidate_output = proportional_derivative + candidate_integral;
  if (!((candidate_output > controller->config.output_limit && integral_change > 0.0f) ||
        (candidate_output < -controller->config.output_limit && integral_change < 0.0f))) {
    controller->integral = candidate_integral;
  }
  const float output = proportional_derivative + controller->integral;
  controller->previous_error = error;
  controller->previous_measurement = measurement;
  return Pid_Limit(output, controller->config.output_limit);
}

bool Pid_CascadeController_Init(
    Pid_CascadeControllerTypeDef *cascade,
    const Pid_ControllerConfigTypeDef *position_config,
    const Pid_ControllerConfigTypeDef *speed_config) {
  if (cascade == NULL) {
    return false;
  }
  *cascade = (Pid_CascadeControllerTypeDef){0};
  Pid_ControllerTypeDef position_pid;
  Pid_ControllerTypeDef speed_pid;
  if (!Pid_Controller_Init(&position_pid, position_config) ||
      !Pid_Controller_Init(&speed_pid, speed_config)) {
    return false;
  }
  cascade->position_pid = position_pid;
  cascade->speed_pid = speed_pid;
  return true;
}

void Pid_CascadeController_Reset(Pid_CascadeControllerTypeDef *cascade) {
  if (cascade == NULL) {
    return;
  }
  Pid_Controller_Reset(&cascade->position_pid);
  Pid_Controller_Reset(&cascade->speed_pid);
}

float Pid_CascadeController_Calc(Pid_CascadeControllerTypeDef *cascade,
                                 float position_target,
                                 float position_measurement,
                                 float speed_measurement, float dt_s) {
  if (cascade == NULL || !isfinite(position_target) ||
      !isfinite(position_measurement) || !isfinite(speed_measurement) ||
      !isfinite(dt_s) || dt_s <= 0.0f) {
    return 0.0f;
  }
  const float speed_target = Pid_Controller_Calc(
      &cascade->position_pid, position_target, position_measurement, dt_s);
  return Pid_Controller_Calc(&cascade->speed_pid, speed_target,
                             speed_measurement, dt_s);
}

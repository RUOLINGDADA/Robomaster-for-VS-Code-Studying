/**
  ******************************************************************************
  * @file    chassis_control.c
  * @brief   DR16 摇杆目标转速混控与四个速度 PID 电流输出。
  *
  * ch[2] 为左右平移 Vx，ch[3] 为前后平移 Vy，ch[0] 为底盘旋转角速度 ω；
  * ch[1] 属于云台 Yaw，暂不使用。任务调用，PID 使用转子 rpm；理论限幅仅作参考，
  * 实际限幅作为最终输出保护。
  * 不操作 CAN、不改方向配置、不计算未知减速比下的轮子 rpm。
  ******************************************************************************
  */

#include "app/chassis_control/chassis_control.h"
#include "app/pid_controller/pid_controller.h"

#include <math.h>

volatile int16_t
    g_chassis_target_current_raw[CHASSIS_CONTROL_MOTOR_COUNT];
volatile float g_chassis_target_speed_rpm[CHASSIS_CONTROL_MOTOR_COUNT];
volatile float g_chassis_feedback_speed_rpm[CHASSIS_CONTROL_MOTOR_COUNT];
volatile float g_chassis_spin_heading_rad;
volatile float g_chassis_spin_target_omega_rad_s;
volatile float g_chassis_spin_feedback_omega_rad_s;
volatile float
    g_chassis_spin_target_speed_rpm[CHASSIS_CONTROL_MOTOR_COUNT];
volatile int16_t g_chassis_theoretical_current_limit_raw =
    CHASSIS_CONTROL_THEORETICAL_CURRENT_RAW_MAX;
volatile int16_t g_chassis_actual_current_limit_raw =
    CHASSIS_CONTROL_ACTUAL_CURRENT_RAW_MAX;
volatile float g_chassis_keyboard_command_vx_rpm;
volatile float g_chassis_keyboard_command_vy_rpm;
volatile float g_chassis_keyboard_command_wz_rpm;
volatile float g_chassis_keyboard_ramped_vx_rpm;
volatile float g_chassis_keyboard_ramped_vy_rpm;
volatile float g_chassis_keyboard_ramped_wz_rpm;

/* PID 对象由底盘任务独占；模式管理任务只在工作任务挂起后清除历史。 */
static Pid_ControllerTypeDef g_speed_pid[CHASSIS_CONTROL_MOTOR_COUNT];
static bool g_control_initialized;
static ChassisSpeedPidGainsTypeDef g_speed_pid_gains = {
    CHASSIS_CONTROL_SPEED_KP,
    CHASSIS_CONTROL_SPEED_KI,
    CHASSIS_CONTROL_SPEED_KD};
static ChassisSpeedPidGainsTypeDef g_pending_speed_pid_gains;
static volatile bool g_speed_pid_gains_pending;
/* 奇数表示写入中，偶数表示快照稳定；避免 VOFA 任务和控制任务读到半组参数。 */
static volatile uint32_t g_active_gains_sequence;
static volatile uint32_t g_pending_gains_sequence;

/** 键盘单轴斜坡状态；只由底盘控制任务访问，不跨任务共享。 */
typedef struct {
  float value_rpm;
  float start_rpm;
  float target_rpm;
  float pending_target_rpm;
  float elapsed_s;
  bool active;
  bool pending_valid;
} ChassisKeyboardRampAxisTypeDef;

static ChassisKeyboardRampAxisTypeDef
    g_keyboard_ramp[3U]; /* 0=Vx，1=Vy，2=Wz。 */

static bool ChassisControl_IsValidCurrentLimit(int16_t limit_raw) {
  return limit_raw > 0 && limit_raw <= 16384;
}

static bool ChassisControl_IsValidSpeedPidGains(
    const ChassisSpeedPidGainsTypeDef *gains) {
  return gains != NULL && isfinite(gains->kp) && isfinite(gains->ki) &&
         isfinite(gains->kd) && gains->kp >= 0.0f &&
         gains->kp <= CHASSIS_CONTROL_SPEED_KP_MAX && gains->ki >= 0.0f &&
         gains->ki <= CHASSIS_CONTROL_SPEED_KI_MAX && gains->kd >= 0.0f &&
         gains->kd <= CHASSIS_CONTROL_SPEED_KD_MAX;
}

static int32_t ChassisControl_ApplyDeadZone(int16_t value) {
  if (value > (int16_t)CHASSIS_CONTROL_RC_MAX) {
    return CHASSIS_CONTROL_RC_MAX;
  }
  if (value < (int16_t)-CHASSIS_CONTROL_RC_MAX) {
    return -CHASSIS_CONTROL_RC_MAX;
  }
  if (value > -CHASSIS_CONTROL_RC_DEAD_ZONE &&
      value < CHASSIS_CONTROL_RC_DEAD_ZONE) {
    return 0;
  }
  return value;
}

static float ChassisControl_ScaleSpeed(int32_t mix_value) {
  float speed_rpm =
      (float)mix_value * CHASSIS_CONTROL_SPEED_RPM_MAX / CHASSIS_CONTROL_RC_MAX;
  if (speed_rpm > CHASSIS_CONTROL_SPEED_RPM_MAX) {
    speed_rpm = CHASSIS_CONTROL_SPEED_RPM_MAX;
  } else if (speed_rpm < -CHASSIS_CONTROL_SPEED_RPM_MAX) {
    speed_rpm = -CHASSIS_CONTROL_SPEED_RPM_MAX;
  }
  return speed_rpm;
}

static float ChassisControl_ScaleSpeedFloat(float mix_value) {
  if (mix_value > (float)CHASSIS_CONTROL_RC_MAX) {
    mix_value = (float)CHASSIS_CONTROL_RC_MAX;
  } else if (mix_value < -(float)CHASSIS_CONTROL_RC_MAX) {
    mix_value = -(float)CHASSIS_CONTROL_RC_MAX;
  }
  return mix_value * CHASSIS_CONTROL_SPEED_RPM_MAX /
         (float)CHASSIS_CONTROL_RC_MAX;
}

/**
 * @brief 计算直线起步和对数后段的归一化速度 / Linear start with a smoothed log tail.
 * @param elapsed_s 当前过渡已经经过的时间，单位秒。
 * @retval 0~1 的速度比例。
 * @note 任务上下文调用；对数段叠加三次端点修正，使T1斜率连续、T3斜率为零。
 */
static float ChassisControl_KeyboardProfile(float elapsed_s) {
  const float linear_ratio = CHASSIS_CONTROL_KEYBOARD_LINEAR_RATIO;
  if (elapsed_s <= 0.0f) {
    return 0.0f;
  }
  if (elapsed_s < CHASSIS_CONTROL_KEYBOARD_RAMP_T1_S) {
    return linear_ratio * elapsed_s /
           CHASSIS_CONTROL_KEYBOARD_RAMP_T1_S;
  }
  if (elapsed_s >= CHASSIS_CONTROL_KEYBOARD_RAMP_T3_S) {
    return 1.0f;
  }

  const float duration_s = CHASSIS_CONTROL_KEYBOARD_RAMP_T3_S -
                           CHASSIS_CONTROL_KEYBOARD_RAMP_T1_S;
  const float progress =
      (elapsed_s - CHASSIS_CONTROL_KEYBOARD_RAMP_T1_S) / duration_s;
  const float remaining = 1.0f - progress;
  const float shape = CHASSIS_CONTROL_KEYBOARD_LOG_SHAPE;
  const float log_scale = logf(1.0f + shape);
  const float log_start_slope = shape / log_scale;
  const float log_end_slope = log_start_slope / (1.0f + shape);
  const float join_slope = linear_ratio * duration_s /
      (CHASSIS_CONTROL_KEYBOARD_RAMP_T1_S * (1.0f - linear_ratio));

  /* 对数基线先快后慢；修正项在两端值均为0，只调整接入和收尾斜率。
     The cubic corrections preserve endpoint values and match endpoint slopes. */
  float curve = logf(1.0f + shape * progress) / log_scale;
  curve += (join_slope - log_start_slope) * progress * remaining * remaining;
  curve += log_end_slope * progress * progress * remaining;
  const float value = linear_ratio + (1.0f - linear_ratio) * curve;
  return fminf(1.0f, fmaxf(linear_ratio, value));
}

static void ChassisControl_ResetKeyboardAxis(
    ChassisKeyboardRampAxisTypeDef *axis) {
  if (axis == NULL) {
    return;
  }
  axis->value_rpm = 0.0f;
  axis->start_rpm = 0.0f;
  axis->target_rpm = 0.0f;
  axis->pending_target_rpm = 0.0f;
  axis->elapsed_s = 0.0f;
  axis->active = false;
  axis->pending_valid = false;
}

static void ChassisControl_StartKeyboardTransition(
    ChassisKeyboardRampAxisTypeDef *axis, float target_rpm) {
  axis->start_rpm = axis->value_rpm;
  axis->target_rpm = target_rpm;
  axis->elapsed_s = 0.0f;
  axis->active = true;
}

/**
 * @brief 更新一个键盘轴的目标过渡。
 * @param axis 轴斜坡状态。
 * @param desired_rpm 当前按键对应的目标转速，单位 rpm。
 * @param dt_s 实际控制间隔，单位秒。
 * @retval 当前曲线输出，单位 rpm。
 * @note 方向改变时先排队经过零速，避免目标转速直接跨过零点。
 */
static float ChassisControl_UpdateKeyboardAxis(
    ChassisKeyboardRampAxisTypeDef *axis, float desired_rpm, float dt_s) {
  const float epsilon_rpm = 0.001f;
  if (axis == NULL) {
    return 0.0f;
  }

  if (fabsf(desired_rpm) <= epsilon_rpm) {
    /* 松开运动键立即清零，避免停止时仍保持一段减速曲线。 */
    ChassisControl_ResetKeyboardAxis(axis);
    return 0.0f;
  } else if (axis->active) {
    if (fabsf(axis->target_rpm - desired_rpm) <= epsilon_rpm) {
      /* 目标未变化，继续当前曲线，不重新计时。 */
    } else if (fabsf(axis->target_rpm) <= epsilon_rpm) {
      if (fabsf(axis->value_rpm) > epsilon_rpm &&
          ((axis->value_rpm > 0.0f) == (desired_rpm > 0.0f))) {
        /* 同方向快速重新按下，从当前速度继续加速。 */
        axis->pending_valid = false;
        ChassisControl_StartKeyboardTransition(axis, desired_rpm);
      } else {
        axis->pending_target_rpm = desired_rpm;
        axis->pending_valid = true;
      }
    } else if ((axis->target_rpm > 0.0f) != (desired_rpm > 0.0f)) {
      axis->pending_target_rpm = desired_rpm;
      axis->pending_valid = true;
      ChassisControl_StartKeyboardTransition(axis, 0.0f);
    } else {
      ChassisControl_StartKeyboardTransition(axis, desired_rpm);
    }
  } else if (fabsf(axis->value_rpm) <= epsilon_rpm) {
    ChassisControl_StartKeyboardTransition(axis, desired_rpm);
  } else if ((axis->value_rpm > 0.0f) != (desired_rpm > 0.0f)) {
    axis->pending_target_rpm = desired_rpm;
    axis->pending_valid = true;
    ChassisControl_StartKeyboardTransition(axis, 0.0f);
  } else {
    ChassisControl_StartKeyboardTransition(axis, desired_rpm);
  }

  if (axis->active) {
    axis->elapsed_s += dt_s;
    if (axis->elapsed_s >= CHASSIS_CONTROL_KEYBOARD_RAMP_T3_S) {
      axis->value_rpm = axis->target_rpm;
      axis->active = false;
      if (fabsf(axis->value_rpm) <= epsilon_rpm) {
        axis->value_rpm = 0.0f;
        if (axis->pending_valid) {
          const float pending_target_rpm = axis->pending_target_rpm;
          axis->pending_valid = false;
          ChassisControl_StartKeyboardTransition(axis, pending_target_rpm);
        }
      }
    } else {
      const float profile =
          ChassisControl_KeyboardProfile(axis->elapsed_s);
      axis->value_rpm = axis->start_rpm +
                        (axis->target_rpm - axis->start_rpm) * profile;
    }
  }
  return axis->value_rpm;
}

static int32_t ChassisControl_GetKeyboardAxis(uint16_t keyboard,
                                               uint16_t positive_key,
                                               uint16_t negative_key) {
  const bool positive = (keyboard & positive_key) != 0U;
  const bool negative = (keyboard & negative_key) != 0U;
  if (positive == negative) {
    return 0;
  }
  return positive ? CHASSIS_CONTROL_RC_MAX : -CHASSIS_CONTROL_RC_MAX;
}

static void ChassisControl_WriteMix(float vx_rpm, float vy_rpm,
                                    float wz_rpm) {
  /* 混控后逐轮限幅，避免组合键让单个电机目标超过转子安全上限。 */
  const float mix[CHASSIS_CONTROL_MOTOR_COUNT] = {
      vy_rpm - vx_rpm - wz_rpm,
      vy_rpm + vx_rpm + wz_rpm,
      vy_rpm - vx_rpm + wz_rpm,
      vy_rpm + vx_rpm - wz_rpm};
  for (uint32_t i = 0U; i < CHASSIS_CONTROL_MOTOR_COUNT; i++) {
    float target_speed_rpm = mix[i];
    if (target_speed_rpm > CHASSIS_CONTROL_SPEED_RPM_MAX) {
      target_speed_rpm = CHASSIS_CONTROL_SPEED_RPM_MAX;
    } else if (target_speed_rpm < -CHASSIS_CONTROL_SPEED_RPM_MAX) {
      target_speed_rpm = -CHASSIS_CONTROL_SPEED_RPM_MAX;
    }
    g_chassis_target_speed_rpm[i] = target_speed_rpm;
  }
}

static void ChassisControl_WriteMixRaw(int32_t vx, int32_t vy, int32_t wz) {
  /* 普通摇杆模式保留原有顺序：先在 DBUS 原始量上混控，再换算每轮 rpm。 */
  const int32_t mix[CHASSIS_CONTROL_MOTOR_COUNT] = {
      vy - vx - wz,
      vy + vx + wz,
      vy - vx + wz,
      vy + vx - wz};
  for (uint32_t i = 0U; i < CHASSIS_CONTROL_MOTOR_COUNT; i++) {
    g_chassis_target_speed_rpm[i] = ChassisControl_ScaleSpeed(mix[i]);
  }
}

static float ChassisControl_SpinRpmPerRadS(void) {
  return CHASSIS_SPIN_REDUCTION_RATIO *
         (CHASSIS_SPIN_HALF_LENGTH_M + CHASSIS_SPIN_HALF_WIDTH_M) /
         CHASSIS_SPIN_WHEEL_RADIUS_M * 60.0f / 6.283185307f;
}

bool ChassisControl_Init(void) {
  if (g_control_initialized) {
    return true;
  }
  g_control_initialized = false;
  const Pid_ControllerConfigTypeDef config = {
      .kp = g_speed_pid_gains.kp,
      .ki = g_speed_pid_gains.ki,
      .kd = g_speed_pid_gains.kd,
      .output_limit = (float)g_chassis_actual_current_limit_raw,
      .integral_limit = CHASSIS_CONTROL_INTEGRAL_RAW_MAX,
      .integral_error_scale = CHASSIS_CONTROL_INTEGRAL_ERROR_SCALE,
      .derivative_cutoff_hz = CHASSIS_CONTROL_DERIVATIVE_CUTOFF_HZ,
  };
  ChassisControl_Clear();
  for (uint32_t i = 0U; i < CHASSIS_CONTROL_MOTOR_COUNT; i++) {
    if (!Pid_Controller_Init(&g_speed_pid[i], &config)) {
      ChassisControl_Clear();
      return false;
    }
  }
  g_control_initialized = true;
  return true;
}

bool ChassisControl_SetSpeedPidGains(
    const ChassisSpeedPidGainsTypeDef *gains) {
  if (!ChassisControl_IsValidSpeedPidGains(gains)) {
    return false;
  }
  if (!g_control_initialized) {
    g_active_gains_sequence++;
    g_speed_pid_gains = *gains;
    g_active_gains_sequence++;
    g_speed_pid_gains_pending = false;
  } else {
    g_pending_gains_sequence++;
    g_pending_speed_pid_gains = *gains;
    g_pending_gains_sequence++;
    g_speed_pid_gains_pending = true;
  }
  return true;
}

void ChassisControl_GetSpeedPidGains(ChassisSpeedPidGainsTypeDef *gains) {
  if (gains != NULL) {
    for (;;) {
      const uint32_t sequence_before = g_active_gains_sequence;
      if ((sequence_before & 1U) != 0U) {
        continue;
      }
      *gains = g_speed_pid_gains;
      if (sequence_before == g_active_gains_sequence) {
        break;
      }
    }
  }
}

bool ChassisControl_ApplyPendingSpeedPidGains(void) {
  if (!g_control_initialized || !g_speed_pid_gains_pending) {
    return false;
  }
  const uint32_t sequence_before = g_pending_gains_sequence;
  if ((sequence_before & 1U) != 0U) {
    return false;
  }
  const ChassisSpeedPidGainsTypeDef pending_gains = g_pending_speed_pid_gains;
  if (sequence_before != g_pending_gains_sequence) {
    return false;
  }
  g_active_gains_sequence++;
  g_speed_pid_gains = pending_gains;
  g_active_gains_sequence++;
  g_speed_pid_gains_pending = false;
  for (uint32_t i = 0U; i < CHASSIS_CONTROL_MOTOR_COUNT; i++) {
    g_speed_pid[i].config.kp = g_speed_pid_gains.kp;
    g_speed_pid[i].config.ki = g_speed_pid_gains.ki;
    g_speed_pid[i].config.kd = g_speed_pid_gains.kd;
    Pid_Controller_Reset(&g_speed_pid[i]);
  }
  return true;
}

void ChassisControl_ResetMotor(uint32_t motor_index) {
  if (motor_index >= CHASSIS_CONTROL_MOTOR_COUNT) {
    return;
  }
  Pid_Controller_Reset(&g_speed_pid[motor_index]);
  g_chassis_target_speed_rpm[motor_index] = 0.0f;
  g_chassis_feedback_speed_rpm[motor_index] = 0.0f;
  g_chassis_target_current_raw[motor_index] = 0;
  g_chassis_spin_target_speed_rpm[motor_index] = 0.0f;
}

int16_t ChassisControl_CalcCurrent(uint32_t motor_index, float speed_rpm,
                                  float dt_s) {
  if (motor_index >= CHASSIS_CONTROL_MOTOR_COUNT) {
    return 0;
  }
  if (!g_control_initialized || !isfinite(speed_rpm) || !isfinite(dt_s) || dt_s <= 0.0f) {
    ChassisControl_ResetMotor(motor_index);
    return 0;
  }
  g_chassis_feedback_speed_rpm[motor_index] = speed_rpm;
  /* 先在浮点域限幅再转换，避免整数回绕；数组保存逻辑电流，方向由公共输出层处理。 */
  const int16_t current_raw = (int16_t)Pid_Controller_Calc(
      &g_speed_pid[motor_index], g_chassis_target_speed_rpm[motor_index],
      speed_rpm, dt_s);
  g_chassis_target_current_raw[motor_index] = current_raw;
  return current_raw;
}

void ChassisControl_Clear(void) {
  for (uint32_t i = 0U; i < CHASSIS_CONTROL_MOTOR_COUNT; i++) {
    ChassisControl_ResetMotor(i);
  }
  for (uint32_t i = 0U; i < 3U; i++) {
    ChassisControl_ResetKeyboardAxis(&g_keyboard_ramp[i]);
  }
  g_chassis_keyboard_command_vx_rpm = 0.0f;
  g_chassis_keyboard_command_vy_rpm = 0.0f;
  g_chassis_keyboard_command_wz_rpm = 0.0f;
  g_chassis_keyboard_ramped_vx_rpm = 0.0f;
  g_chassis_keyboard_ramped_vy_rpm = 0.0f;
  g_chassis_keyboard_ramped_wz_rpm = 0.0f;
  g_chassis_spin_heading_rad = 0.0f;
  g_chassis_spin_target_omega_rad_s = 0.0f;
  g_chassis_spin_feedback_omega_rad_s = 0.0f;
  g_chassis_theoretical_current_limit_raw =
      CHASSIS_CONTROL_THEORETICAL_CURRENT_RAW_MAX;
  g_chassis_actual_current_limit_raw = CHASSIS_CONTROL_ACTUAL_CURRENT_RAW_MAX;
  if (g_control_initialized) {
    for (uint32_t i = 0U; i < CHASSIS_CONTROL_MOTOR_COUNT; i++) {
      g_speed_pid[i].config.output_limit =
          (float)CHASSIS_CONTROL_ACTUAL_CURRENT_RAW_MAX;
    }
  }
}

void ChassisControl_Update(const DR16_Dbus_DataTypeDef *data) {
  if (data == NULL || !data->online || data->switch_s1 != DR16_DBUS_SWITCH_DOWN) {
    ChassisControl_Clear();
    return;
  }

  const int32_t vx = ChassisControl_ApplyDeadZone(data->channel[2]);
  const int32_t vy = ChassisControl_ApplyDeadZone(data->channel[3]);
  const int32_t wz = ChassisControl_ApplyDeadZone(data->channel[0]);
  /* 保留已确认混控，数组按 ID 排列：1右前、2左前、3左后、4右后。 */
  ChassisControl_WriteMixRaw(vx, vy, wz);
}

void ChassisControl_UpdateKeyboard(const DR16_Dbus_DataTypeDef *data,
                                   float dt_s) {
  if (data == NULL || !data->online || !isfinite(dt_s) || dt_s <= 0.0f) {
    ChassisControl_Clear();
    return;
  }

  const uint16_t keyboard = data->keyboard;
  const float vx_rpm = ChassisControl_ScaleSpeedFloat((float)
      ChassisControl_GetKeyboardAxis(keyboard, DR16_DBUS_KEY_D,
                                     DR16_DBUS_KEY_A));
  const float vy_rpm = ChassisControl_ScaleSpeedFloat((float)
      ChassisControl_GetKeyboardAxis(keyboard, DR16_DBUS_KEY_W,
                                     DR16_DBUS_KEY_S));
  const float wz_rpm = ChassisControl_ScaleSpeedFloat((float)
      ChassisControl_GetKeyboardAxis(keyboard, DR16_DBUS_KEY_E,
                                     DR16_DBUS_KEY_Q));
  g_chassis_keyboard_command_vx_rpm = vx_rpm;
  g_chassis_keyboard_command_vy_rpm = vy_rpm;
  g_chassis_keyboard_command_wz_rpm = wz_rpm;

  g_chassis_keyboard_ramped_vx_rpm =
      ChassisControl_UpdateKeyboardAxis(&g_keyboard_ramp[0U], vx_rpm, dt_s);
  g_chassis_keyboard_ramped_vy_rpm =
      ChassisControl_UpdateKeyboardAxis(&g_keyboard_ramp[1U], vy_rpm, dt_s);
  g_chassis_keyboard_ramped_wz_rpm =
      ChassisControl_UpdateKeyboardAxis(&g_keyboard_ramp[2U], wz_rpm, dt_s);
  ChassisControl_WriteMix(g_chassis_keyboard_ramped_vx_rpm,
                          g_chassis_keyboard_ramped_vy_rpm,
                          g_chassis_keyboard_ramped_wz_rpm);
}

void ChassisControl_SetCurrentLimitsRaw(int16_t theoretical_limit_raw,
                                        int16_t actual_limit_raw) {
  if (!ChassisControl_IsValidCurrentLimit(theoretical_limit_raw) ||
      !ChassisControl_IsValidCurrentLimit(actual_limit_raw)) {
    theoretical_limit_raw = CHASSIS_CONTROL_THEORETICAL_CURRENT_RAW_MAX;
    actual_limit_raw = CHASSIS_CONTROL_ACTUAL_CURRENT_RAW_MAX;
  }
  g_chassis_theoretical_current_limit_raw = theoretical_limit_raw;
  g_chassis_actual_current_limit_raw = actual_limit_raw;
  if (!g_control_initialized) {
    return;
  }
  for (uint32_t i = 0U; i < CHASSIS_CONTROL_MOTOR_COUNT; i++) {
    g_speed_pid[i].config.output_limit = (float)actual_limit_raw;
  }
}

void ChassisControl_SetActualCurrentLimitRaw(int16_t actual_limit_raw) {
  ChassisControl_SetCurrentLimitsRaw(
      g_chassis_theoretical_current_limit_raw, actual_limit_raw);
}

void ChassisControl_UpdateSpin(const DR16_Dbus_DataTypeDef *data,
                               float heading_rad,
                               float target_omega_rad_s) {
  if (data == NULL || !data->online ||
      data->switch_s1 != DR16_DBUS_SWITCH_DOWN || !isfinite(heading_rad) ||
      !isfinite(target_omega_rad_s)) {
    ChassisControl_Clear();
    return;
  }

  const float sin_heading = sinf(heading_rad);
  const float cos_heading = cosf(heading_rad);
  const float earth_vx = (float)ChassisControl_ApplyDeadZone(data->channel[2]);
  const float earth_vy = (float)ChassisControl_ApplyDeadZone(data->channel[3]);
  const float body_vx = earth_vx * cos_heading - earth_vy * sin_heading;
  const float body_vy = earth_vx * sin_heading + earth_vy * cos_heading;
  const float vx_rpm = ChassisControl_ScaleSpeedFloat(body_vx);
  const float vy_rpm = ChassisControl_ScaleSpeedFloat(body_vy);
  const float wz_rpm = target_omega_rad_s * ChassisControl_SpinRpmPerRadS();
  g_chassis_spin_heading_rad = heading_rad;
  g_chassis_spin_target_omega_rad_s = target_omega_rad_s;
  ChassisControl_WriteMix(vx_rpm, vy_rpm, wz_rpm);
  for (uint32_t i = 0U; i < CHASSIS_CONTROL_MOTOR_COUNT; i++) {
    g_chassis_spin_target_speed_rpm[i] = g_chassis_target_speed_rpm[i];
  }
}

void ChassisControl_SetSpinFeedbackOmega(float omega_rad_s) {
  g_chassis_spin_feedback_omega_rad_s = isfinite(omega_rad_s) ? omega_rad_s : 0.0f;
}

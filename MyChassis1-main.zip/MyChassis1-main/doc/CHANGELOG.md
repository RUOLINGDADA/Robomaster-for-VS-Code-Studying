# 变更记录

## 2026-10-07 —— 键盘启动后段改为平滑对数曲线

- 保留前0.20 s直线到目标的1/3，后段采用归一化对数和端点斜率修正，1.00 s达到满速。
  直线/对数交界处速度和斜率连续，末端斜率归零；默认曲线单调上升、后段斜率逐渐减小。
- 删除旧t2节点，新增直线末端比例和对数弯曲系数宏；保持松键立即清零、反向过零、
  摇杆/小陀螺/测试模式和 PID/电流限幅行为。
- 增加真实C接口数值测试，覆盖六个运动键的曲线、连接斜率、末端、组合键、不同周期和掉线复位。
- 验证：`python tools/test_pid.py` 全部通过；`tools/verify.ps1` 的51个源文件完整编译链接通过，
  0错误、0告警。实际速度跟随效果仍需上板观察。

## 2026-10-06 —— 完善 USART1 DMA 调试链路

- 启用 USART1 中断，补齐普通 DMA 发送完成后的 TC 回调，避免首帧发送后 TX 永久保持忙状态。
- 增加 USART1 UART 错误后的单字节 DMA 接收恢复，并将 USART3 错误恢复统一分发到 DBUS 驱动。
- 增加 VOFA 调参协议主机回归测试和协议文档，覆盖 CRC、参数范围、ACK、19 通道 JustFloat 和
  Flash CRC 校验。

## 2026-10-06 —— 增加 USART1 VOFA 波形与 PID 参数持久化

- 新增 USART1 DMA 调试任务：9600 baud 下每 100 ms 发送 19 通道 JustFloat 波形，包含四轮
  目标转速、反馈转速、反馈电流、DR16 通道和当前 Kp/Ki/Kd。
- 新增固定 18 字节二进制 PID 调参协议，支持 SET、GET、SAVE 和 CRC16 ACK；调参参数统一作用于
  四个速度环，并在控制任务安全边界应用。
- 预留 STM32F407 Sector 11（`0x080E0000`）保存带版本和 CRC32 的 PID 参数；无效记录回退默认值。
- SAVE 执行前停止工作任务并发送零电流，Flash 操作完成后恢复模式。

## 2026-10-06 —— 增加键盘模式三段式速度曲线

- 键盘 W/S、A/D、Q/E 三个轴分别增加基于实际 `dt_s` 的目标转速斜坡，默认在 0.20 s、
  0.60 s、1.00 s 到达目标的 1/3、2/3、100%。
- 中段和末段使用端点斜率连续的三次 Hermite 曲线；反向先经过零速，
  模式切换和掉线清除曲线状态。
- 后续调整为松键立即清零目标速度，反向切换仍先经过零速再启动反向曲线。
- 增加键盘即时/曲线目标调试变量；摇杆、小陀螺、测试任务和 PID 参数保持不变。

### 验证

- `python tools/test_pid.py` 通过，覆盖曲线节点、组合键、松键、反向和重新按键行为。

## 2026-10-06 —— 增加独立键盘控制会话

- 增加 W/S/A/D/Q/E/Shift/Ctrl 键位定义；Shift 按下沿开启或关闭普通底盘键盘会话。
- 键盘会话忽略摇杆和 S1/S2，支持普通底盘组合键，掉线立即退出并清零。
- 不新增 FreeRTOS 工作任务，不修改 `.ioc`；主机数值测试和 ARM 全量编译均通过。

## 2026-10-06 —— 简化键盘模式并修正 DR16 键位

- 键盘会话只保留普通底盘控制，不再通过键盘进入小陀螺任务。
- 按实测 DR16 位定义修正为 Bit4=Shift、Bit5=Ctrl、Bit6=Q、Bit7=E，避免 Q/E 被误识别为
  Shift/Ctrl。

## 2026-10-05 —— 分离理论电流限幅与实际输出限幅

- 普通底盘使用理论 ±3.5 A / 实际 ±6.0 A；小陀螺使用理论 ±6.5 A / 实际 ±10.0 A。
- 理论限幅仅作为满速参考和调试变量，PID 抗积分饱和与最终 CAN 输出只使用实际限幅，
  避免满摇杆目标转速因理论电流值提前饱和。
- 模式切换时预装载对应双限幅，退出或清零后恢复普通模式默认值；新增主机测试覆盖限幅切换和复位。

## 2026-10-04 —— 增加底盘小陀螺模式

- `S1=2 && S2=2` 唤醒独立小陀螺任务；普通底盘、测试和小陀螺任务保持互斥。
- 使用目标右转角速度积分航向角，将 `ch[2]/ch[3]` 从大地坐标转换到底盘坐标后参与四轮混控，
  小陀螺模式忽略 `ch[0]`。
- 当前使用四个 M3508 CAN 转速估算车体角速度，复用四轮速度 PID，电流总限幅提高到约 ±6 A；
  普通底盘仍为约 ±3.5 A。轮径、底盘尺寸和减速比暂为可调临时参数。

### 验证

- `python tools/test_pid.py` 通过，覆盖坐标变换、右转符号、模式限幅和清零复位。
- `tools/verify.ps1` 通过，49 个源文件编译链接无错误、无告警。

## 2026-10-04 —— 底盘速度 PID 与可复用位置-速度双环

- DR16 死区和混控先产生转子目标 rpm，用电调 CAN 速度反馈计算限幅电流；上限仍为 ±3.5 A。
- 新增 `app/pid_controller`，包括梯形积分、用户指定的倒数变速积分、积分限幅、微分先行、
  微分一阶低通、输出限幅与抗积分饱和；提供位置-速度级联接口，底盘只启用速度环。
- 保留用户的方向表 `{-1,+1,+1,-1}`，对反馈和电流同时转换。模式切换、离线与采样停顿清 PID 历史。
- 新增目标转速/反馈转速观察数组，保留逻辑 PID 电流数组；最大轮速和减速比未确定，
  6000转子 rpm与Kp/Ki/Kd/a均为可调起始值，待实机整定。

### 验证

- `tools/verify.ps1` 48 个源文件编译链接通过，无错误、无告警。
- `python tools/test_pid.py` 真实 C 数值测试通过，涵盖倒数/梯形积分、微分和滤波、饱和、级联、
  混控、方向、复位与闭环模型；未上板整定，仿真不代表实机性能。

## 2026-10-04 —— 修正 3、4 号电机方向

- 1、2 号电机保持原电流符号；3、4 号电机在公共输出层自动取反。
- 测试任务和底盘任务统一通过 `ChassisMotors_SetCurrent()` 输出，正值现在对应四个轮子的统一正方向。

## 2026-10-04 —— 修正底盘电机位置映射

- 统一四个电机位置：1号右前、2号左前、3号左后、4号右后。
- 更新公共电机数组、混控顺序注释和调试文档；电调 ID 仍按 1、2、3、4 注册。

## 2026-10-04 —— 拆分底盘测试与遥控任务

- 新增 `task_chassis_can_test`、`task_chassis_control` 和 `task_chassis_mode_manager` 三个独立任务文件。
- 模式管理任务按 DR16 `switch_s1` 互斥挂起/唤醒两个工作任务：1 为测试模式，2 为底盘模式，
  其它状态或遥控器离线时发送零电流。
- 新增 `app/chassis_motors` 统一注册四个 M3508、处理 CAN 接收回调和聚合发送，避免两个任务
  争用同一组电机句柄和 CAN 控制帧。

### 验证

- `tools/verify.ps1`：47 个源文件编译、汇编和链接通过，0 错误、0 用户代码告警。

## 2026-10-04 —— 增加 DR16 底盘模式电流换算

- `switch_s1=1` 时运行原有四电机自检；`switch_s1=2` 时进入底盘遥控模式。
- 新增 `app/chassis_control`，按 `Vx=ch[2]`、`Vy=ch[3]`、`ω=ch[0]` 做死区、麦克纳姆混控和
  ±3.5 A 电流限幅，目标值保存到 `g_chassis_target_current_raw[4]`。
- `ch[1]` 暂不参与底盘输出，为后续云台 Yaw 扩展保留接口；当前未加入 PID。

## 2026-10-04 —— 新增 DR16 DBUS 接收与解码

- 新增 `bsp/dr16_dbus`：USART3 DMA M0/M1 双缓冲 + IDLE 接收 18 字节 DBUS 帧，解码四通道、S1/S2、
  鼠标、键盘和在线超时状态。
- 按协议使用 100 kbit/s、8E1；由于当前 `.ioc` 只保存了 USART3 的波特率/RX 配置，
  `main.c` 在启动 DMA 前用 HAL 重新初始化为 `UART_WORDLENGTH_9B + UART_PARITY_EVEN`。
- 驱动不创建任务、不绑定电机；上层通过 `DR16_Dbus_GetData()` 读取一致快照，便于后续
  增加遥控映射、运动学和 PID。

### 验证

- `tools/verify.ps1` 已完成 43 个源文件的全量编译与链接，0 错误、0 用户代码告警；
  仍需上板验证 DBUS 实帧，串口接收硬件反相和 DR16 电源也需确认。

## 2026-10-04 —— 修复电机启动短暂转动后停止

### 原因与修复

- `C620_M3508_IsOnline()` 之前把 `DISABLED`（输出关闭）当作在线状态，任务尚未收到反馈
  也会在 50 ms 后误使能；100 ms 后初始时间戳超时，电机随即停止。
- 接收 ISR 只更新反馈快照时间戳，没有更新驱动用于超时判断的时间戳，正常反馈运行超过 100 ms
  也会被误判掉线。现在两处时间戳同步更新，并增加 `feedback_received` 作为真实反馈证据。
- 自检任务只冻结启动时有反馈且在掩码内的电机，未接入的其它槽位保持 0；ARM_DELAY 期间维持零电流，
  延时结束后再显式重新使能。

### 验证

- `tools/verify.ps1`：39 个源文件编译、链接通过，0 错误、0 用户代码告警。
- 尚未上板验证；需观察 `last_feedback_tick` 持续更新、`feedback_received=true`，以及 CAN 分析仪上的
  `0x200` 帧持续为 2 ms 周期。

## 2026-xx-xx —— 修复 Bus-Off 导致的"板子像死的" + 过滤器 bank bug

### 背景

上板实测：编译下载后电机完全不动，调试器显示
`g_m3508_test_motors[1].feedback.last_feedback_tick == 0`、`state == DISABLED`，
即**一个反馈帧都没收到**。进一步读 CAN 寄存器：

```
ESR = 0x00F80057   TEC=248, REC=0, BOFF=1, EWGF=1, EPVF=1, LEC=BIT_DOMINANT_ERROR
TSR = 0x82000000   TXOK0..2 = 无, TME0..2 = 0
```

TEC 涨到 248 说明发送硬件确实在工作，但没有任何节点 ACK，最终触发 Bus-Off。
根因是物理层（收发器/接线/终端电阻）不通，且外设进入 Bus-Off 后**无软件恢复路径**，
永久沉默。

### 修复（3 处代码改动）

| 文件 | 改动 | 原因 |
|---|---|---|
| `Core/Src/bsp/board_can/board_can.c` | 新增 `BoardCan_RecoverIfBusOff()`、`BoardCan_IsBusOff()`、`BoardCan_GetBusOffCount()` | Bus-Off 后外设被硬件摘除，`.ioc` 的 `AutoBusOff=DISABLE` 使其永不恢复。恢复走完整 `Stop → 重配过滤器 → Start → 重挂中断` |
| `Core/Src/bsp/board_can/board_can.c` | `filter.SlaveStartFilterBank` 由 `14U` 改为 `0U` | **真 bug**：该字段会写入 `CAN_FMR.CAN2SB`，而 `MX_CAN2_Init()` 会把它设成 0，导致 28 个 bank 全归未启动的 CAN2。详见 `TROUBLESHOOTING.md` 故障 3 |
| `Core/Src/app/task_m3508_can_test/app_task_m3508_can_test.c` | 新增 `M3508_TEST_SPIN_MOTOR_ID`，`M3508_TEST_SPIN_MASK` 改为由它推导；新增 `M3508_TEST_SKIP_FEEDBACK_WAIT` 台架旁路；循环首部调用 Bus-Off 恢复 | 原 `SPIN_MASK` 写死 `0x01`，实际电调是 ID 2 时"电机完全不动"且难以定位 |

### 新增文档

- `doc/TROUBLESHOOTING.md`：CAN 收不到反馈 / 电机不动的完整排查流程，含寄存器判读表、
  硬件检查清单、三个已发生故障的根因分析。

### 验证结果

- 默认配置：39 个源文件编译 + 链接通过，**0 错误 0 告警**，
  `text 32516 / data 108 / bss 21068`，RAM 16.16% / FLASH 3.11%。
- `M3508_TEST_SKIP_FEEDBACK_WAIT = 1` 的 `#if` 分支单独编译验证通过后已还原为 `0`。

### 未验证部分

- **物理层根因仍未确认**：软件恢复不能修好接线/收发器/终端电阻。若物理层未修复，
  恢复后很快会再次 Bus-Off，`BoardCan_GetBusOffCount()` 会持续增长。
- 修复后尚未重新上板验证（需要用户实测）。
- `printf` 仍未重定向，`AutoBusOff=ENABLE` 需要改 `.ioc`，两者都待用户确认。

### 后续实测数据（同一轮修复后）

用户上板后读到：

```
ESR = 15204435 (0x00E80053)   BOFF=0, LEC=5(BIT_DOMINANT_ERROR), TEC=232, REC=0
TSR = 469762057 (0x1C000009)  TXOK2=1, TME0..2=0
BoardCan_GetBusOffCount() = 99
```

判读：

- `GetBusOffCount = 99` **证明恢复逻辑生效**（外设被救回 99 次），原先"Bus-Off 后
  永久沉默"的缺陷已解决；
- `BOFF=0` 但 `TEC=232` 属"恢复后再次冲刺 Bus-Off"的中间态；
- `TXOK2=1` 证明发送通道本身没坏；
- **`REC` 始终为 0** → 99 轮下来一个 bit 都没收到，**物理层确认断开**；
- `LEC=5 (BIT_DOMINANT_ERROR)` 指向**短路/被拽在显性电平**（而非断路，断路通常报 LEC=4），
  最可能是 CANH/CANL 短接、对地/对电源短路，或收发器处于永久使能。

据此补充改动：

| 文件 | 改动 |
|---|---|
| `Core/Src/bsp/board_can/board_can.c` | 新增 Bus-Off 去抖（`BOARD_CAN_BUSOFF_DEBOUNCE_MS = 100`）：要求 BOFF 连续稳定存在 100 ms 才执行恢复，避免瞬态掉线被误恢复、以及物理层坏掉时每 2 ms 重配一次外设 |
| `doc/TROUBLESHOOTING.md` | 新增 CANH/CANL 对地电压判读表（决定性测量）、LEC 故障类型对照表、本次实测案例的完整判读 |

编译验证：39 个源文件 + 链接通过，**0 错误 0 告警**，RAM 16.16% / FLASH 3.12%。

**待用户提供**：CANH/CANL 对地电压（主控侧与电调侧各一次）、断电时 CANH–CANL 电阻。

---

## 2026-xx-xx —— 任务 1：CAN 通信控制 M3508（收发闭环）

### 新增文件

| 文件 | 说明 |
|---|---|
| `Core/Inc/bsp/m3508_c620/m3508_c620.h` | C620 + M3508 CAN 驱动的类型、协议常量与 12 个公开 API |
| `Core/Src/bsp/m3508_c620/m3508_c620.c` | 静态注册表、反馈解析、聚合控制帧打包发送、超时与状态机 |
| `Core/Inc/bsp/board_can/board_can.h` | 板级 CAN 接口（过滤器、启动、FIFO 路由） |
| `Core/Src/bsp/board_can/board_can.c` | CAN1 过滤器配置、`HAL_CAN_Start()`、FIFO0 中断激活与路由 |
| `Core/Src/app/task_m3508_can_test/app_task_m3508_can_test.c` | 底盘 CAN 环路自检任务（4 电机、2 ms 周期、正反转交替） |
| `AGENTS.md` | 工程规则（目录、命名、中英双注释、FreeRTOS、CubeMX、构建） |
| `doc/README.md` | 文档入口与模块索引 |
| `doc/PROJECT_CONTEXT.md` | 工程现状、硬件资源、日志现状 |
| `doc/CODING_STYLE.md` | 注释规范与已踩过的坑 |
| `doc/protocol/c620_can.md` | C620 CAN 协议字段级说明 |
| `doc/modules/board_can/README.md` | 板级层模块文档 |
| `doc/modules/m3508_c620/README.md` | 驱动模块文档 |
| `doc/modules/task_m3508_can_test/README.md` | 任务模块文档 |
| `doc/OPEN_QUESTIONS.md` | 待确认项 |

### 修改文件

| 文件 | 改动 | 位置 |
|---|---|---|
| `CMakeLists.txt` | 加入 3 个新增 `.c` 与 `Core/Inc` 包含路径 | `target_sources` / `target_include_directories` 用户区 |
| `Core/Src/main.c` | 包含 `board_can.h`；在 `USER CODE BEGIN 2` 调用 `BoardCan_Init()` | 仅 `USER CODE` 区 |
| `Core/Src/freertos.c` | 声明并创建自检任务；新增任务对象与属性 | 仅 `USER CODE` 区 |

**未修改**：`MyChassis1.ioc`、`Core/Src/can.c`、`Core/Src/gpio.c`、
`cmake/stm32cubemx/CMakeLists.txt` 以及所有生成代码的非 `USER CODE` 区域。

### 接口变化

- 新增模块 `bsp/board_can`：`BoardCan_Init()`、`BoardCan_PollRxFifo0()`。
- 新增模块 `bsp/m3508_c620`：`C620_M3508_Init/DeInit/SetCurrent/SetOutputEnabled/`
  `Process/SendAll/HandleRxMessage/RxFifoCallback/GetFeedback/IsOnline/RequiresRearm/GetState`。
- 新增应用任务入口 `task_chassis_can_test_entry()`（在 `freertos.c` 中声明并创建）。
- 新增覆盖 HAL `__weak` 的 `HAL_CAN_RxFifo0MsgPendingCallback()`。

### 任务 / 中断上下文

| 代码 | 上下文 |
|---|---|
| `BoardCan_PollRxFifo0`、`C620_M3508_RxFifoCallback`、`C620_M3508_HandleRxMessage` | CAN1_RX0 ISR（优先级 5） |
| `BoardCan_Init` | `main()`，调度器启动前 |
| 任务注册、`Process`、`SetCurrent`、`SetOutputEnabled`、`SendAll`、`GetFeedback` | `chassisCanTest` 任务 |

### 验证结果

工具链：`arm-none-eabi-gcc 14.3.1+st.2`（`C:\Users\zoutou\AppData\Local\stm32cube\bundles`）。

- **全工程编译 + 链接通过**（0 error、0 warning），使用 `build/Debug/build.ninja` 中的实际
  编译参数（`-mcpu=cortex-m4 -mfpu=fpv4-sp-d16 -mfloat-abi=hard -Wall -O0 -g3 -std=gnu11`）。
- 新增与修改文件另做 `-Wall -Wextra` 检查：零告警。
  （`freertos.c` 中 `StartDefaultTask` 的 `unused parameter` 告警为 CubeMX 生成代码原有。）
- 链接结果：`text 32172 / data 108 / bss 21060`，RAM 使用 21168 B (16.15%)，
  FLASH 使用 32288 B (3.08%)。
- 符号确认：`task_chassis_can_test_entry`、`C620_M3508_SendAll`、`C620_M3508_Init`、
  `BoardCan_Init`、`HAL_CAN_RxFifo0MsgPendingCallback`、`g_c620_m3508_slots`、
  `g_m3508_test_motors` 均已进入最终镜像。
- 静态栈分析（`-fstack-usage`）：本工程新增代码单函数栈开销最大 96 字节
  （`task_chassis_can_test_entry`），驱动层最大 56 字节，任务栈 2048 字节有充足余量。

### 未验证部分

- **未上板**：没有实机、电调和 CAN 分析仪，收发时序、电调 ID、实际波特率与电机转向
  均未实机确认。
- **未集成构建**：`build/` 目录存在权限限制，无法在其中执行 `cmake --preset Debug`
  的完整构建；改用真实工具链等参数编译链接，结果等价但未走 CMake。
- 日志当前无输出（`.ioc` 无 USART + `__io_putchar()` 无强定义），见
  `PROJECT_CONTEXT.md` 与 `OPEN_QUESTIONS.md`。

### 设计决策记录

1. **新增板级层 `board_can` 而不是把过滤器写进生成文件 `can.c`**：过滤器分组是板级资源，
   放进生成文件会在重新生成时丢失，且 CAN2 接入时难以统一规划。
2. **CAN2 保持未启动**：STM32F407 的 CAN1/CAN2 共享 28 个过滤器，CAN2 只能用 14 ~ 27 号，
   而这些过滤器只能在 CAN1 处于初始化模式时修改。因此必须在 CAN1 启动前一次性规划，
   不能在 CAN2 启动后追加。
3. **接收时间戳统一用 `HAL_GetTick()`**：`HAL_GetTick()` 由 TIM6 维护，在调度器启动前和
   中断上下文都可用；`Process(now_tick)` 与接收时间戳同源才能正确判超时。
4. **引入 `requires_rearm` 标志**：仅靠 `output_enabled` 无法区分“从未使能”和
   “掉线后清了输出”，会导致通信恢复瞬间恢复到掉线前力矩。
5. **`SetOutputEnabled(true)` 不把状态直接推到 `READY`**：避免“重新使能”到“下一帧反馈
   到达”之间出现“无反馈依据却显示在线”的窗口。
6. **只写一个最小任务而不是 PID 框架**：PID 属于后续任务；任务中唯一决定电流值的函数
   `M3508Test_BuildTargetCurrents()` 是后续替换点，其余时序保持不变。
## 2026-10-07 —— VOFA 数值滑条文本调参

- USART1 VOFA 调试任务兼容 `KP=数值`、`KI=数值`、`KD=数值` 和 `PID=kp,ki,kd` 文本命令，
  便于数值滑条以 `Str` 命令 `KP=%f\r\n` 等格式直接修改运行中的速度 PID。
- 文本命令沿用与二进制 SET_PID 相同的有限值和参数范围校验；仍需 SAVE 命令写入 Flash，
  JustFloat 的 16~18 通道可确认当前已生效的参数。

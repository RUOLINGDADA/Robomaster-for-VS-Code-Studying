/**
  ******************************************************************************
  * @file    app_task_chassis_mode_manager.h
  * @brief   测试任务与底盘任务的互斥模式管理接口。
  *
  * 模式管理任务根据 DR16 的 S1 开关挂起一个工作任务、唤醒另一个工作任务。
  * 切换前先停止并发送零电流，保证同一时刻只有一个任务拥有 CAN 输出权。
  ******************************************************************************
  */

#ifndef APP_TASK_CHASSIS_MODE_MANAGER_H
#define APP_TASK_CHASSIS_MODE_MANAGER_H

#include "FreeRTOS.h"
#include "task.h"

#include <stdbool.h>

/** 模式管理器当前拥有的工作模式。 */
typedef enum {
  CHASSIS_MODE_NONE = 0,
  CHASSIS_MODE_TEST,
  CHASSIS_MODE_CONTROL,
  CHASSIS_MODE_SPIN
} ChassisModeTypeDef;

/**
  * @brief  设置三个工作任务的 FreeRTOS 句柄。
  * @param  test_task M3508 自检任务句柄。
  * @param  chassis_task 底盘遥控任务句柄。
  * @param  chassis_spin_task 小陀螺任务句柄。
  * @retval 无。
  * @note   必须在调度器启动前调用一次，之后只由模式管理任务使用。
  */
void ChassisModeManager_SetTasks(TaskHandle_t test_task,
                                 TaskHandle_t chassis_task,
                                 TaskHandle_t chassis_spin_task);

/**
  * @brief  查询键盘控制会话是否已开启。
  * @param  无。
  * @retval true 当前由键盘会话接管模式和输入；false 使用 S1/S2。
  */
bool ChassisModeManager_IsKeyboardActive(void);

/**
 * @brief 进入 Flash 参数维护状态并停止三个工作任务。
 * @retval true 电机初始化完成且零电流帧已入队；false 保持停机，不能写 Flash。
 * @note 任务上下文调用；调用后保持零电流，直到 ExitMaintenance() 成功恢复。
 */
bool ChassisModeManager_EnterMaintenance(void);

/**
 * @brief 结束 Flash 参数维护状态。
 * @retval 无；模式管理任务下一周期按当前遥控器状态恢复工作模式。
 */
void ChassisModeManager_ExitMaintenance(void);

/**
  * @brief  获取模式管理器当前已应用的工作模式。
  * @param  无。
  * @retval 当前模式；任务切换窗口返回 CHASSIS_MODE_NONE。
  */
ChassisModeTypeDef ChassisModeManager_GetMode(void);

/**
  * @brief  模式管理任务入口。
  * @param  argument FreeRTOS 任务参数，当前未使用。
  * @retval 无；任务入口不会返回。
  */
void task_chassis_mode_manager_entry(void *argument);

#endif /* APP_TASK_CHASSIS_MODE_MANAGER_H */

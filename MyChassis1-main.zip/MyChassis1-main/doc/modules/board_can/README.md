# board_can —— CAN 板级层

## 模块职责

把“CubeMX 不管、但应用必须做”的 CAN 工作集中到一处：

- 配置 CAN1 接收过滤器（只放行底盘电机反馈帧）；
- 调用 `HAL_CAN_Start()` 让 CAN1 进入 LISTENING 状态；
- 激活 FIFO0 message-pending 中断；
- 把 FIFO0 的报文路由给对应的协议驱动。

它**不负责**：位时序、GPIO 复用、NVIC 优先级（CubeMX 生成代码负责）；协议字段解析
（`bsp/m3508_c620` 负责）；任务调度（`app/*` 负责）。

## 文件

```text
Core/Inc/bsp/board_can/board_can.h   # 两个公开函数
Core/Src/bsp/board_can/board_can.c   # 过滤器、启动、FIFO 路由
```

## 为什么需要这一层

CubeMX 生成的 `Core/Src/can.c` 只做三件事：配位时序、配 GPIO 复用、开 NVIC。它既不配置
接收过滤器，也不调用 `HAL_CAN_Start()`。而“哪些 ID 该被接收”属于应用需求，不是硬件配置
参数，CubeMX 无法表达。

如果把这些代码直接写进 `can.c` 的 `USER CODE` 区域，有两个问题：

1. 重新生成 CubeMX 代码时容易丢失或被覆盖；
2. 过滤器分组是板级资源，散落在生成文件里会让 CAN2 接入时难以统一规划。

因此单独成层，并且把过滤器配置做成 `static` 函数 —— 电机驱动不应该知道自己的报文占用了
几号过滤器。

## 公开 API

| 函数 | 调用上下文 | 说明 |
|---|---|---|
| `bool BoardCan_Init(void)` | 调度器启动前，或任务中，只能调用一次 | 配过滤器 → 启动 CAN1 → 激活 FIFO0 中断 |
| `bool BoardCan_PollRxFifo0(void)` | **CAN1_RX0 中断** | 从 FIFO0 取一帧并交给 C620 驱动解析 |

### 初始化顺序（不可交换）

```text
1. HAL_CAN_ConfigFilter()        —— 过滤器只能在 CAN 处于初始化状态时修改
2. HAL_CAN_Start()               —— 进入 LISTENING，参与总线仲裁与 ACK
3. HAL_CAN_ActivateNotification() —— 此时才有必要开始响应接收事件
```

若先 `Start` 再配过滤器，`HAL_CAN_ConfigFilter()` 直接返回错误；若提前开中断，
中断可能在过滤器还没配好时就被触发。

`BoardCan_Init()` 内部在激活中断失败时会调用 `HAL_CAN_Stop()`，避免留下
“能发不能收”的半初始化 CAN。

## 过滤器配置

```c
filter.FilterMode          = CAN_FILTERMODE_IDMASK;
filter.FilterScale         = CAN_FILTERSCALE_32BIT;
filter.FilterIdHigh        = 0x200 << 5;   /* 匹配值 */
filter.FilterMaskIdHigh    = 0x7F8 << 5;   /* 掩码：低 3 位不关心 */
filter.FilterFIFOAssignment = CAN_RX_FIFO0;
filter.FilterBank          = 0;            /* CAN1 可用 0 ~ 13 */
filter.FilterActivation    = ENABLE;
filter.SlaveStartFilterBank = 0;           /* 当前 CAN2 未使用，全部 bank 归 CAN1 */
```

接纳集合：`(StdId & 0x7F8) == 0x200` → `0x200 ~ 0x207`（8 个 ID）。
本工程用到 `0x201 ~ 0x204`。

详见 [../../protocol/c620_can.md](../../protocol/c620_can.md)。

## CAN2 的处理方式（重要）

CAN2 在 `.ioc` 中已使能，`MX_CAN2_Init()` 会被 `main()` 调用，但：

- `BoardCan_Init()` 目前**只处理 CAN1**，CAN2 没有配过滤器、没有 `HAL_CAN_Start()`；
- 未启动的 CAN2 不会收发，不影响 CAN1；
- 于是 `can.h` 中的 `hcan2` 是一个已初始化但未运行的外设实例。

### 为什么不能简单地“顺手也启动 CAN2”

STM32F407 的 CAN1 与 CAN2 共享同一组 28 个过滤器，CAN2 只能使用 **14 ~ 27 号**过滤器，
而这些过滤器只有在 **CAN1 处于初始化模式**时才允许修改。也就是说：

- 一旦 CAN1 已经 `HAL_CAN_Start()`（进入 LISTENING），就无法再为 CAN2 添加过滤器；
- 正确做法是在 CAN1 启动**之前**，一次性把两条总线的过滤器都配好
  （CAN2 用 `SlaveStartFilterBank` 之后的 bank 编号）。

因此接入云台电机时，应当在 `BoardCan_Init()` 内部统一规划过滤器分组，而不是在 CAN2
已经启动后临时追加。这一点已记录在本模块和 `OPEN_QUESTIONS.md` 中。

## 中断与并发

- `BoardCan_PollRxFifo0()` 运行在 `CAN1_RX0_IRQn`（抢占优先级 5）。
- 优先级 5 等于 `configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY`，因此中断里**可以**调用
  `FromISR` 接口；但当前接收路径刻意不调用任何 FreeRTOS API，只做取帧和解码。
- 中断中不得 `printf`、不得阻塞；否则会拖长中断时间并造成 CAN 丢帧。
- 每次中断只取一帧。FIFO 里还有报文时 HAL 会再次进入中断，用循环一次取空反而会延长单次
  中断时间、恶化实时性。

## 失败处理

| 情况 | 行为 |
|---|---|
| 过滤器配置失败 | `BoardCan_Init()` 返回 `false`，外设未启动 |
| `HAL_CAN_Start()` 失败 | 返回 `false` |
| 激活接收中断失败 | 调用 `HAL_CAN_Stop()` 后返回 `false` |
| `main()` 中初始化失败 | 打印提示并进入 `Error_Handler()`，不进入电机任务 |

## 验证方式

1. 编译：`cmake --preset Debug && cmake --build --preset Debug`。
2. 上板：确认 `BoardCan_Init()` 返回 `true`。
3. 回路验证：给电调上电，用示波器或 CAN 分析仪确认
   - 主控周期性发出 `0x200` 帧（周期 2 ms，8 字节）；
   - 电调周期性发出 `0x201 ~ 0x204` 帧（周期约 1 ms）。
4. 若收不到反馈，按顺序检查：电调上电、CANH/CANL 是否接反、120 Ω 终端电阻、
   波特率是否 1 Mbit/s、电调 ID 是否与代码一致、过滤器与中断是否生效。

## 已知限制

- 只处理 CAN1；CAN2 的过滤器分组需要在接入云台时统一重排（见上）。
- 只支持标准帧、8 字节 DLC；不支持扩展帧。
- 没有总线错误计数、Bus-Off 恢复策略和总线负载统计，这些属于后续任务。
- `AutoBusOff` / `AutoRetransmission` 在 `.ioc` 中为 `DISABLE`，即发送失败不自动重传。
  这是刻意选择（避免错误帧挤占总线），但意味着驱动层的发送失败统计更有意义。

# m3508_c620 —— C620 电调 + M3508 电机 CAN 驱动

## 模块职责

面向 C620 电调与 M3508 电机的 RoboMaster 标准 CAN 协议驱动，提供：

- 一条 CAN 总线上最多 8 个设备的**静态注册**（不使用动态内存）；
- CAN 反馈帧过滤、字段解码和字节序处理；
- 目标电流缓存，以及 `0x200` / `0x1FF` **聚合控制帧**打包与发送；
- 反馈超时检测、在线/离线状态和掉线后的输出锁止；
- 面向上层任务的反馈快照读取。

它**不负责**：CAN 外设与 GPIO 初始化、过滤器配置、外设启动（`bsp/board_can` 负责）；
FreeRTOS 任务创建与调度（`app/*` 负责）；PID、速度环、运动学、功率限制、温度保护
（后续任务）。

## 文件

```text
Core/Inc/bsp/m3508_c620/m3508_c620.h   # 类型、协议常量、公开 API
Core/Src/bsp/m3508_c620/m3508_c620.c   # 静态注册表、解析、打包、状态机
```

## 协议依据

字段含义、ID 分配和字节序见 [../../protocol/c620_can.md](../../protocol/c620_can.md)。
要点：

- 反馈帧 `StdId = 0x200 + 电调 ID`，8 字节，字段全部**大端**；
- 控制帧 `0x200` 携带 ID 1 ~ 4，`0x1FF` 携带 ID 5 ~ 8，每电机 2 字节；
- 电流指令是**周期刷新量**，超时不发帧电调会停机。

## 公开 API

| 函数 | 上下文 | 说明 |
|---|---|---|
| `C620_M3508_Init` | 任务 / 调度器启动前 | 注册句柄，状态置 `OFFLINE` |
| `C620_M3508_DeInit` | 任务 | 注销并从聚合帧中移除 |
| `C620_M3508_SetCurrent` | 任务 | 只写 RAM 目标值，带 ±16384 饱和 |
| `C620_M3508_SetOutputEnabled` | 任务 | 使能/关闭本电机输出，关闭时清零目标 |
| `C620_M3508_Process` | 任务，必须先于 `SendAll` | 超时检测、清零、锁止、状态迁移 |
| `C620_M3508_SendAll` | 固定周期任务 | 发送该总线上所有电机的聚合控制帧 |
| `C620_M3508_HandleRxMessage` | **ISR** 或任务 | 解析一帧已取出的数据 |
| `C620_M3508_RxFifoCallback` | **ISR** | 从 FIFO 取一帧并解析 |
| `C620_M3508_GetFeedback` | 任务 | 复制反馈快照 |
| `C620_M3508_IsOnline` | 任务 / ISR | 只有收到过真实反馈且未超时才在线，不受输出开关影响 |
| `C620_M3508_RequiresRearm` | 任务 | 掉线后是否必须先重新使能 |
| `C620_M3508_GetState` | 任务 | 读取状态机状态 |

## 状态机

| 当前状态 | 事件 | 新状态 |
|---|---|---|
| `UNINITIALIZED` | `Init()` 成功 | `OFFLINE` |
| `OFFLINE` | 收到有效反馈帧 | `ONLINE` |
| `OFFLINE` | `SetOutputEnabled(true)` | 无反馈时保持 `OFFLINE`；有反馈时 `READY` |
| `ONLINE` | `SetOutputEnabled(true)` | `READY` |
| `ONLINE` / `READY` | 收到有效反馈帧且输出已使能 | `READY` |
| 任意状态 | `SetOutputEnabled(false)` | `DISABLED`（目标清零） |
| `DISABLED` | `SetOutputEnabled(true)` | 有反馈时 `READY`，无反馈时仍为 `OFFLINE` |
| 任意状态 | `Process()` 检测到反馈超时 | `OFFLINE`（目标清零 + 输出锁止 + `requires_rearm`） |
| `OFFLINE` | `Process()` 发现反馈已恢复 | `ONLINE` 或 `READY`（按 `output_enabled`，**不清除 `requires_rearm`**） |

```text
   Init()           收到反馈             SetOutputEnabled(true)
UNINITIALIZED ──→ OFFLINE ──────→ ONLINE ──────────────────→ READY
                     ↑              │                          │
                     │              │ SetOutputEnabled(false)   │ SetOutputEnabled(false)
                     │              ↓                          ↓
                     │           DISABLED ←────────────────────┘
                     │              │
                     │              │ SetOutputEnabled(true)
                     │              ↓
                     └─────────── ONLINE（等下一帧反馈才回到 READY）

  任意状态 ──Process() 超时──→ OFFLINE（目标清零 + 输出锁止 + requires_rearm）
```

### 为什么使能不会直接把状态推到 `READY`

`SetOutputEnabled(true)` 只做一件事：允许输出。状态提升到 `READY` 需要**证据** ——
要么当前已经是 `ONLINE`（说明 `Process()` 刚确认反馈未超时），要么等下一帧反馈到达。

这样设计的原因是一次具体的错误场景：电机掉线 → `Process()` 置 `OFFLINE` 并锁止 →
上层紧接着调用 `SetOutputEnabled(true)` 重新使能。如果使能直接把状态写成 `READY`，
那么从“重新使能”到“收到下一帧反馈”之间存在一个窗口期，期间状态显示在线，上层可能据此
下发非零电流。虽然 `requires_rearm` 在使能时被清除，但此时并没有任何新反馈证明链路真的
恢复了。因此使能时若状态是 `OFFLINE` 且没有收到过反馈，仍保持 `OFFLINE`；有反馈证据时才进入 `READY`。

### `requires_rearm` 为什么存在

`Process()` 检测到超时后会清零目标、关闭输出，并置 `requires_rearm = true`。
`SendAll()` 在 `requires_rearm` 为真时对该电机强制写 0。

如果没有这个标志，只靠 `output_enabled` 判断：超时清零目标后若上层在下个周期又写入目标值
（很多任务的写法是每周期无条件调用 `SetCurrent`），通信恢复的瞬间就会立刻恢复到掉线前的
力矩。在底盘上的表现是“接触不良时突然窜车”。

恢复流程是两步而非自动，**驱动不会在后台自动解除锁止**：

1. 上层显式调用 `SetOutputEnabled(handle, true)`：清除 `requires_rearm`，允许输出。
   这是清除该标志的**唯一入口**；
2. 收到下一帧反馈后状态升为 `READY`，链路被证据确认。

第 1 步之所以必须显式，是因为上层任务常见的写法是每个周期无条件调用 `SetCurrent()`。
掉线期间 `target_current_raw` 会被反复写回非零值，如果驱动在 `Process()` 里顺手清除
`requires_rearm`，紧接着的 `SendAll()` 就会把旧电流发出去 —— 这正是该标志要防的场景。

## 调用顺序（固定周期任务）

```c
const uint32_t now_ms = HAL_GetTick();          /* 与 SendAll 同源时钟 */

C620_M3508_Process(&motor, now_ms);            /* 1. 先判超时 */
if (C620_M3508_IsOnline(&motor)) {
  C620_M3508_SetCurrent(&motor, target_raw);   /* 2. 再写目标 */
}
C620_M3508_SendAll(&hcan1);                    /* 3. 最后聚合发送 */
```

顺序**不能交换**：`Process()` 可能刚刚把超时电机切成离线并锁止输出，如果先发送，
本周期就会把掉线前的旧电流再发一帧出去。

## 中断与并发

| 数据 | 写者 | 读者 | 一致性 |
|---|---|---|---|
| `feedback.*` / `feedback_received` / `last_feedback_tick` | 接收 ISR | 任务 | `GetFeedback()` 和 `Process()` 内短临界区保护 |
| `target_current_raw` | 任务 | `SendAll`（任务） | 同一任务内，天然安全 |
| `state` / `output_enabled` | RX ISR / 任务 | 任务 | 单字段原子访问；状态更新在任务与 ISR 间短暂交错 |
| 静态注册表 | `Init`/`DeInit`（任务） | `Find`（ISR） | 只在初始化阶段写入；运行期稳定 |

接收 ISR 只做四件事：帧合法性检查 → 由 StdId 查注册表 → 解码 6 个字段 → 记时间戳。
不打印、不阻塞、不调用任何 FreeRTOS API。

## 关键实现说明（避坑）

1. **大端处理**：CAN 字段大端，STM32F407 小端。用 `C620_M3508_ReadI16Be/ReadU16Be` 逐字节
   拼接，禁止 `*(int16_t *)data`（字节序错误 + 非对齐 UB）。
2. **写大端时先转 `uint16_t` 再右移**：对有符号负数右移是实现定义行为；转成无符号后
   `-1` 会被正确编码为 `0xFF 0xFF`。
3. **配置值拷贝**：`hmotor->config = *config` 而非 `= config`。保存指针会在调用方的局部
   `config` 出栈后变成悬垂指针，并在中断里触发 HardFault。
4. **句柄生命周期**：驱动内部只保存句柄地址，句柄必须是静态或任务级存储，不能是栈局部变量。
5. **`HAL_GetTick()` 而非 `xTaskGetTickCount()`**：`HAL_GetTick()` 由 TIM6 维护，在调度器
   启动前和中断上下文都可用。超时判断要求 `Process(now_tick)` 与接收时间戳同源，因此统一
   使用 `HAL_GetTick()`。
6. **时间戳必须同步**：接收 ISR 同时更新 `feedback.last_feedback_tick` 与驱动超时基准
   `last_feedback_tick`；两者若分开维护，会在上电约 100 ms 后把正常电机误判为掉线。
7. **无符号 Tick 差值**：`now_tick - last_feedback_tick` 处理毫秒 Tick 回绕；正常运行间隔远小于
   24.9 天的半回绕窗口。
8. **饱和而非回绕**：`SetCurrent` 把输入钳到 ±16384。直接窄化会回绕，
   `-16385` 变成 `+16383`，转矩方向反转。

## 使用示例

```c
/* 1. 定义静态句柄（不能是任务栈局部变量） */
static C620_M3508_HandleTypeDef g_motor;

/* 2. 注册（可在调度器启动前或任务中） */
const C620_M3508_ConfigTypeDef config = {
    .hcan = &hcan1,
    .motor_id = 1U,
    .feedback_timeout_ms = 100U,
};
(void)C620_M3508_Init(&g_motor, &config);

/* 3. 中断回调（应用层定义一次，覆盖 HAL 的 __weak 空实现） */
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan) {
  if (hcan == &hcan1) {
    (void)C620_M3508_RxFifoCallback(hcan, CAN_RX_FIFO0);
  }
}

/* 4. 固定周期任务循环体（见上面的“调用顺序”） */
```

前置条件：`main()` 已完成 `MX_CAN1_Init()` 和 `BoardCan_Init()`。

## 安全行为

| 情况 | 行为 |
|---|---|
| 输出未使能 | 聚合帧中该电机的两个字节强制为 `0` |
| 掉线且未重新使能（`requires_rearm`） | 同上，强制 `0` |
| 反馈超时 | 目标清零、输出关闭、状态 `OFFLINE`、置 `requires_rearm` |
| 电流超范围 | 饱和到 `-16384` / `16384` |
| 无空闲发送邮箱 | `SendAll()` 返回 `false`，不阻塞等待、不重试 |
| ID 重复或注册表已满 | `Init()` 返回 `false` |

## 构建与验证

- 本模块已通过真实 `arm-none-eabi-gcc 14.3.1` 编译（`-Wall -Wextra` 零告警）并参与全工程链接。
- 静态栈分析（`-fstack-usage`）显示本模块单函数栈开销最大 56 字节
  （`C620_M3508_SendFrame` / `C620_M3508_SendAll` / `C620_M3508_RxFifoCallback`）。
- 上板验证见 `task_m3508_can_test` 模块文档。

## 已知限制

- 不支持扩展帧，只支持标准帧 + 8 字节 DLC。
- `DATA[7]` 只解释 `bit0`（过温）；其余位保存原始字节，见 `OPEN_QUESTIONS.md`。
- 单圈角度不累计；多圈角度和速度环需要上层实现。
- 没有堵转检测、温度保护和功率限制。
- `GetFeedback()` 的多字段复制不是原子快照。

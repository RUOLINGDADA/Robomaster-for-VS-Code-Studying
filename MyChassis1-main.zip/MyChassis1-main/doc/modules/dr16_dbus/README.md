# dr16_dbus —— DR16 DBUS 接收驱动

## 模块职责

使用 USART3 接收 RoboMaster DR16 的 18 字节 DBUS 帧，完成通道、拨杆、鼠标和键盘字段
解码，并向上层提供带在线状态的快照。键盘字段保存为 16 位位掩码，位定义见头文件；模块不创建
任务，也不把遥控量直接映射为电机电流。

协议字段见 [../../protocol/dr16_dbus.md](../../protocol/dr16_dbus.md)。

## 硬件与接收参数

| 项目 | 值 |
|---|---|
| 外设 | USART3 RX，PC11 |
| 波特率 | 100 kbit/s |
| 帧格式 | 8E1（HAL 配置为 `UART_WORDLENGTH_9B` + `UART_PARITY_EVEN`） |
| 接收方式 | DMA M0/M1 双缓冲 + IDLE，单帧 18 字节 |
| DBUS 电平 | 反相 TTL，需由板级反相电路处理 |

当前 `.ioc` 保留 USART3 的波特率和 RX 配置，`main.c` 在启动 DMA 前补上 8E1 初始化，
避免把协议设置误当作普通 8N1 串口。

## 文件与 API

```text
Core/Inc/bsp/dr16_dbus/dr16_dbus.h
Core/Src/bsp/dr16_dbus/dr16_dbus.c
```

| 函数 | 上下文 | 说明 |
|---|---|---|
| `DR16_Dbus_Init` | 初始化代码 | 注册 USART3，清空快照 |
| `DR16_Dbus_Start` | 初始化代码 | 启动或重启 DMA M0/M1 双缓冲 + IDLE 接收 |
| `DR16_Dbus_GetData` | 任务 / 主循环 | 复制一份一致的解码快照 |
| `DR16_Dbus_IsOnline` | 任务 / 主循环 | 按 HAL 毫秒 tick 判断 100 ms 超时 |

最小初始化示例：

```c
MX_DMA_Init();
MX_USART3_UART_Init();
/* main.c 会把 USART3 重新设为 8E1，然后再启动 DBUS DMA。 */
DR16_Dbus_Init(&huart3);
DR16_Dbus_Start();
```

上层任务读取示例：

```c
DR16_Dbus_DataTypeDef rc = {0};
if (DR16_Dbus_GetData(&rc) && rc.online) {
  const int16_t forward = rc.channel[1];
  const uint8_t mode = rc.switch_s1;
  /* 在这里接运动学/PID，不在 DBUS 驱动内写电机电流。 */
}
```

## 并发与失败处理

- `USART3_IRQHandler()` 运行在 USART ISR，依据 DMA 的 CT 位切换 M0/M1，并只对完成的 18 字节帧解码；
  不打印、不阻塞、不调用 FreeRTOS API。
- `DR16_Dbus_GetData()` 用短临界区复制快照，避免任务读到半帧字段。
- DBUS 没有帧头；回调必须收到完整 18 字节且四个通道和拨杆编码合理才提交快照。
  错位、奇偶校验错误或短帧只增加 `error_count`，不会覆盖上一份有效控制数据。
- 连续超过 100 ms 没有有效帧时 `online=false`；上层应把目标速度/电流归零。

## 已知限制

- 当前只注册一个 DBUS 接收器，适配本工程 USART3 的单个 DR16 接收机。
- `channel[]` 是减去 1024 中心值后的原始计数，尚未做死区、比例或单位换算。
- 鼠标和键盘字段已解码，但没有绑定任何业务动作。

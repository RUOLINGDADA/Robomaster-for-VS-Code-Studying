/* 主机测试 CAN1 句柄声明。 */
#ifndef TEST_CAN_H
#define TEST_CAN_H
#include "bsp/m3508_c620/m3508_c620.h"
extern CAN_HandleTypeDef hcan1;
#endif

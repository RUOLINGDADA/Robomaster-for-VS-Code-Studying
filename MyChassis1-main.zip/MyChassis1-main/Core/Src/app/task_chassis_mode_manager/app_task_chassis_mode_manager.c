/**
  ******************************************************************************
  * @file    app_task_chassis_mode_manager.c
  * @brief   M3508 自检、普通底盘与小陀螺任务的互斥调度。
  *
  * 本任务每 10 ms 读取一次 DR16。S1=1 唤醒自检任务；S1=2 且 S2=2 唤醒小陀螺任务；
  * S1=2 且 S2!=2 唤醒普通底盘任务；其余状态或遥控器离线时三个任务都挂起。
  * 切换顺序固定为“挂起旧任务、清零并发送、
  * 唤醒新任务”，避免两个任务同时发送 CAN 控制帧。
  ******************************************************************************
  */

#include "app/chassis_motors/chassis_motors.h"
#include "app/chassis_control/chassis_control.h"
#include "app/task_chassis_mode_manager/app_task_chassis_mode_manager.h"
#include "bsp/dr16_dbus/dr16_dbus.h"

#include "FreeRTOS.h"
#include "task.h"

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

/** 模式管理任务周期，单位：毫秒。 */
#define CHASSIS_MODE_MANAGER_PERIOD_MS 10U

static TaskHandle_t g_test_task_handle;
static TaskHandle_t g_chassis_task_handle;
static TaskHandle_t g_chassis_spin_task_handle;
static volatile ChassisModeTypeDef g_current_mode;
static volatile bool g_keyboard_active;
static bool g_keyboard_wait_shift_release;
static uint16_t g_keyboard_previous_keys;
static bool g_applied_keyboard_active;
static volatile bool g_maintenance_active;
static volatile bool g_motors_ready;

static void ChassisModeManager_SuspendWorkers(void);

void ChassisModeManager_SetTasks(TaskHandle_t test_task,
                                 TaskHandle_t chassis_task,
                                 TaskHandle_t chassis_spin_task) {
  g_test_task_handle = test_task;
  g_chassis_task_handle = chassis_task;
  g_chassis_spin_task_handle = chassis_spin_task;
}

bool ChassisModeManager_IsKeyboardActive(void) { return g_keyboard_active; }

bool ChassisModeManager_EnterMaintenance(void) {
  /* 与模式切换串行，仍允许 CAN ISR 收反馈 / serialize with mode changes. */
  vTaskSuspendAll();
  if (!g_motors_ready) {
    (void)xTaskResumeAll();
    return false;
  }
  g_maintenance_active = true;
  ChassisModeManager_SuspendWorkers();
  ChassisControl_Clear();
  ChassisMotors_StopAll();
  const bool stopped = ChassisMotors_Send();
  g_current_mode = CHASSIS_MODE_NONE;
  (void)xTaskResumeAll();
  return stopped;
}

void ChassisModeManager_ExitMaintenance(void) {
  g_maintenance_active = false;
}

ChassisModeTypeDef ChassisModeManager_GetMode(void) { return g_current_mode; }

static void ChassisModeManager_SuspendWorkers(void) {
  if (g_test_task_handle != NULL) {
    vTaskSuspend(g_test_task_handle);
  }
  if (g_chassis_task_handle != NULL) {
    vTaskSuspend(g_chassis_task_handle);
  }
  if (g_chassis_spin_task_handle != NULL) {
    vTaskSuspend(g_chassis_spin_task_handle);
  }
}

static void ChassisModeManager_SwitchTo(ChassisModeTypeDef next_mode) {
  vTaskSuspendAll();
  if (g_maintenance_active) {
    next_mode = CHASSIS_MODE_NONE;
  }
  const bool keyboard_state_changed =
      g_applied_keyboard_active != g_keyboard_active;
  if (next_mode == g_current_mode && !keyboard_state_changed) {
    (void)xTaskResumeAll();
    return;
  }

  /* 先暂停两个工作任务，再清零并发送一帧，切换期间总线上保持安全状态。 */
  ChassisModeManager_SuspendWorkers();
  /* 工作任务已挂起才能复位共享 PID 和目标数组，避免切换后遗留积分。 */
  ChassisControl_Clear();
  ChassisMotors_StopAll();
  (void)ChassisMotors_Send();
  g_current_mode = CHASSIS_MODE_NONE;

  /* 在唤醒新任务前先装载该模式的双限幅，避免切换窗口沿用旧模式参数。 */
  if (next_mode == CHASSIS_MODE_SPIN) {
    ChassisControl_SetCurrentLimitsRaw(
        CHASSIS_SPIN_THEORETICAL_CURRENT_RAW_MAX,
        CHASSIS_SPIN_ACTUAL_CURRENT_RAW_MAX);
  } else {
    ChassisControl_SetCurrentLimitsRaw(
        CHASSIS_CONTROL_THEORETICAL_CURRENT_RAW_MAX,
        CHASSIS_CONTROL_ACTUAL_CURRENT_RAW_MAX);
  }

  /* 先发布最终模式，再恢复任务；否则恢复任务可能抢先读到 NONE 并立即退出。 */
  g_current_mode = next_mode;
  g_applied_keyboard_active = g_keyboard_active;

  if (next_mode == CHASSIS_MODE_TEST && g_test_task_handle != NULL) {
    vTaskResume(g_test_task_handle);
  } else if (next_mode == CHASSIS_MODE_SPIN &&
             g_chassis_spin_task_handle != NULL) {
    vTaskResume(g_chassis_spin_task_handle);
  } else if (next_mode == CHASSIS_MODE_CONTROL &&
             g_chassis_task_handle != NULL) {
    vTaskResume(g_chassis_task_handle);
  }
  (void)xTaskResumeAll();
}

static ChassisModeTypeDef ChassisModeManager_ReadRadioMode(
    const DR16_Dbus_DataTypeDef *remote_data) {
  if (remote_data == NULL || !remote_data->online) {
    return CHASSIS_MODE_NONE;
  }
  if (remote_data->switch_s1 == DR16_DBUS_SWITCH_UP) {
    return CHASSIS_MODE_TEST;
  }
  if (remote_data->switch_s1 == DR16_DBUS_SWITCH_DOWN) {
    if (remote_data->switch_s2 == DR16_DBUS_SWITCH_DOWN) {
      return CHASSIS_MODE_SPIN;
    }
    return CHASSIS_MODE_CONTROL;
  }
  return CHASSIS_MODE_NONE;
}

static ChassisModeTypeDef ChassisModeManager_ReadMode(
    const DR16_Dbus_DataTypeDef *remote_data) {
  if (g_maintenance_active) {
    return CHASSIS_MODE_NONE;
  }
  if (remote_data == NULL || !remote_data->online) {
    /* 只有已经进入会话或确实检测到 Shift 按下时，掉线才要求先松键。 */
    const bool shift_was_pressed =
        (g_keyboard_previous_keys & DR16_DBUS_KEY_SHIFT) != 0U;
    g_keyboard_wait_shift_release = g_keyboard_active || shift_was_pressed;
    g_keyboard_active = false;
    g_keyboard_previous_keys = 0U;
    return CHASSIS_MODE_NONE;
  }

  const uint16_t keys = remote_data->keyboard;
  const bool shift_pressed = (keys & DR16_DBUS_KEY_SHIFT) != 0U;
  const bool shift_rising = shift_pressed &&
                            (g_keyboard_previous_keys & DR16_DBUS_KEY_SHIFT) == 0U;
  g_keyboard_previous_keys = keys;

  if (g_keyboard_wait_shift_release && !shift_pressed) {
    g_keyboard_wait_shift_release = false;
  }

  if (shift_rising && !g_keyboard_wait_shift_release) {
    if (g_keyboard_active) {
      g_keyboard_active = false;
    } else {
      g_keyboard_active = true;
    }
  }

  if (g_keyboard_active) {
    /* 键盘会话只支持普通底盘；即使切换前是小陀螺，也先切到普通任务。 */
    return CHASSIS_MODE_CONTROL;
  }
  return ChassisModeManager_ReadRadioMode(remote_data);
}

/**
  * @brief  模式管理任务入口。
  * @param  argument FreeRTOS 任务参数，当前未使用。
  * @retval 无；任务入口不会返回。
  * @note   电机初始化失败时保留任务并等待，便于调试器检查注册表和 CAN 状态。
  */
void task_chassis_mode_manager_entry(void *argument) {
  (void)argument;

  /* 给两个工作任务时间进入自己的永久等待，再初始化共享电机注册表。 */
  vTaskDelay(pdMS_TO_TICKS(20U));
  if (!ChassisMotors_Init()) {
    ChassisModeManager_SuspendWorkers();
    printf("[chassis_mode] motor init failed\r\n");
    for (;;) {
      vTaskDelay(pdMS_TO_TICKS(1000U));
    }
  }

  g_current_mode = CHASSIS_MODE_NONE;
  g_keyboard_active = false;
  g_keyboard_wait_shift_release = false;
  g_keyboard_previous_keys = 0U;
  g_applied_keyboard_active = false;
  ChassisModeManager_SuspendWorkers();
  ChassisMotors_StopAll();
  (void)ChassisMotors_Send();

  g_motors_ready = true;

  TickType_t last_wake_tick = xTaskGetTickCount();
  for (;;) {
    DR16_Dbus_DataTypeDef remote_data = {0};
    const bool data_valid = DR16_Dbus_GetData(&remote_data);
    ChassisModeManager_SwitchTo(
        ChassisModeManager_ReadMode(data_valid ? &remote_data : NULL));
    vTaskDelayUntil(&last_wake_tick,
                    pdMS_TO_TICKS(CHASSIS_MODE_MANAGER_PERIOD_MS));
  }
}

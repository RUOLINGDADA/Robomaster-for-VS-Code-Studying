"""在 Windows 上用已有 Visual Studio C11 编译器运行真实 C 数值测试，无需烧录或改工程配置。"""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent.parent
vswhere = Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Microsoft Visual Studio/Installer/vswhere.exe"
installation = subprocess.check_output(
    [str(vswhere), "-latest", "-products", "*", "-requires",
     "Microsoft.VisualStudio.Component.VC.Tools.x86.x64", "-property", "installationPath"],
    text=True).strip()
if not installation:
    raise SystemExit("需要 Visual Studio 的 C++ 工具组件以执行主机测试。")
vcvars = Path(installation) / "VC/Auxiliary/Build/vcvars64.bat"
sources = [
    ROOT / "Core/Src/app/pid_controller/pid_controller.c",
    ROOT / "Core/Src/app/chassis_control/chassis_control.c",
    ROOT / "Core/Src/app/chassis_motors/chassis_motors.c",
    ROOT / "tools/tests/test_pid.c",
]
with tempfile.TemporaryDirectory(prefix="mychassis-pid-",
                                 ignore_cleanup_errors=True) as output:
    executable = Path(output) / "test_pid.exe"
    arguments = ["cl", "/nologo", "/std:c11", "/W4", "/WX", "/utf-8",
                 "/I" + str(ROOT / "tools/tests/stubs"), "/I" + str(ROOT / "Core/Inc"),
                 *map(str, sources), "/Fe:" + str(executable)]
    # 仅固定编译参数和受控路径进入 shell；文件清理由 TemporaryDirectory 完成。
    runner = Path(output) / "build_tests.cmd"
    runner.write_text(f'@echo off\ncall "{vcvars}" >nul\nif errorlevel 1 exit /b 1\n'
                      + subprocess.list2cmdline(arguments) + '\nexit /b %errorlevel%\n',
                      encoding="utf-8")
    subprocess.run(f'cmd /d /c "{runner}"', cwd=output, check=True)
    subprocess.run([str(executable)], cwd=output, check=True)
    # Windows 编译器辅助进程可能短暂占用工作目录，留出退出时间再清理。
    time.sleep(0.5)

subprocess.run([sys.executable, str(ROOT / "tools/tests/test_vofa_protocol.py")],
               cwd=ROOT, check=True)

/**
  ******************************************************************************
  * @file    app_task_chassis_control.h
  * @brief   DR16 底盘遥控任务接口。
  *
  * 任务读取 DR16 快照和电调转子速度，通过底盘速度 PID 输出电流并每 2 ms 发送 CAN。
  * 位置-速度双环接口在 pid_controller；底盘只使用速度环，不处理云台位置控制。
  ******************************************************************************
  */

#ifndef APP_TASK_CHASSIS_CONTROL_H
#define APP_TASK_CHASSIS_CONTROL_H

/**
  * @brief  底盘遥控任务入口。
  * @param  argument FreeRTOS 任务参数，当前未使用。
  * @retval 无；任务入口不会返回。
  */
void task_chassis_control_entry(void *argument);

#endif /* APP_TASK_CHASSIS_CONTROL_H */

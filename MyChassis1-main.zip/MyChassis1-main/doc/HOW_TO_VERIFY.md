# 如何验证这份代码

本文件说明怎么检查代码是否正确。**从第 1 步开始，三步全部通过才算真正验证完。**

---

## 第 1 步：编译自检（几秒钟，随时可做）

改完任何代码后先跑这个。它用一个命令完成「编译 39 个源文件 → 链接成 .elf → 报告
Flash/RAM 占用 → 报告用户代码的栈用量」。

```powershell
# 在工程根目录 D:\CubeMxProject\MyChassis1 下执行
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\verify.ps1
```

耗时约 40 秒。常用变体：

```powershell
# 只做语法检查，最快（约 7 秒），适合频繁改代码时用
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\verify.ps1 -SyntaxOnly

# 保留中间产物，可以看 .su 栈用量文件和 .map 映射文件
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\verify.ps1 -Keep

# 额外开启 -Wextra 严格告警（HAL 库自身可能有告警，属正常）
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\verify.ps1 -Wextra
```

### 怎么看结果

**看最后两行就够：**

```
==================== 汇总 ====================
结果: 通过 (0 错误, 0 个文件有告警)
```

- `结果: 通过` + 退出码 `0` → 编译没问题。
- `结果: 失败` → 上面会以红色逐行打印错误位置。
- **告警要当回事**：如果有告警，脚本会单独标成黄色并在汇总里计数。本工程的基线是
  **0 告警**，一旦出现新告警，说明改动引入了问题。

### 脚本为什么值得信

它用的是 STM32Cube 自带的**真实编译器** `arm-none-eabi-gcc 14.3.1`，参数与
`cmake/gcc-arm-none-eabi.cmake`、`build/Debug/build.ninja` 完全一致
（`-mcpu=cortex-m4 -mfpu=fpv4-sp-d16 -mfloat-abi=hard -Wall -O0 -g3 -std=gnu11`），
所以编译结果等价于真实构建。

**注意**：新增 `.c` 文件时，除了改 `CMakeLists.txt`，还要把文件名加到
`tools/verify.ps1` 的 `$UserSrc` 列表里，否则该文件不会被检查。

### 当前基线（可以通过）

```
RAM:   21168 B / 128 KB (16.15%)
FLASH: 32288 B / 1 MB  (3.08%)
结果: 通过 (0 错误, 0 个文件有告警)
```

RAM 从 0 涨到 16% 主要是 FreeRTOS 堆（`configTOTAL_HEAP_SIZE = 15360`）和任务栈，
代码本身很小。**如果 FLASH 突然暴涨几 KB，通常是把 `printf` 的浮点格式化拉进来了**，
检查是不是用了 `%f`。

---

## 第 2 步：代码走查（10 分钟，重点是「有没有骗你」）

编译器只能查语法，查不出逻辑。重点看这几处，它们是我这次改动里**最容易出错的地方**：

### 2.1 生成的代码有没有被动过

我只允许自己在 `/* USER CODE BEGIN */` 和 `/* USER CODE END */` 之间写代码。
用这条命令确认，输出应该只有 3 个文件、且都在 USER CODE 区：

```powershell
cd D:\CubeMxProject\MyChassis1
git --no-pager diff -- Core/Src/main.c Core/Src/freertos.c CMakeLists.txt
```

再确认 `.ioc` 和 CubeMX 生成的核心文件没被改：

```powershell
git status --porcelain
```

**应该看不到** `MyChassis1.ioc`、`Core/Src/can.c`、`Core/Src/gpio.c`、
`cmake/stm32cubemx/CMakeLists.txt`。如果它们出现在列表里，就是我不该改却改了。

### 2.2 CAN 帧的字节序（最容易写错）

打开 `Core/Src/bsp/m3508_c620/m3508_c620.c`，搜 `ReadI16Be`。要点：

- CAN 协议是**大端**（高字节先发），STM32 内存是**小端**，必须逐字节移位拼接；
- **绝对不能**写成 `*(int16_t *)data`。如果看到这种写法就是错的。

### 2.3 发出去的到底是哪条帧

搜 `C620_M3508_SendAll`。四个轮子（ID 1~4）应该**只发一条 `0x200` 帧**，
每个电机占 2 字节：

```
DATA[0:1] = ID1 电流    DATA[2:3] = ID2 电流
DATA[4:5] = ID3 电流    DATA[6:7] = ID4 电流
```

如果发成了 4 条独立帧，或者把 ID5~8 也塞进 `0x200`，就是错的。

### 2.4 掉线保护（安全相关，务必看）

搜 `requires_rearm`，确认这两条逻辑都在：

1. `C620_M3508_Process()` 检测超时后：清零目标 → 关闭输出 → 置 `requires_rearm`；
2. `C620_M3508_SendAll()` 在 `requires_rearm` 为真时，对该电机**强制写 0**。

**为什么必须有**：上层任务通常每周期无条件调用 `SetCurrent()`。如果掉线后只是清了标志，
通信恢复的一瞬间就会把掉线前的旧力矩发出去 —— 实车表现是「接触不良时突然窜车」。
清除 `requires_rearm` 的唯一入口应该是上层显式调 `SetOutputEnabled(handle, true)`。

### 2.5 上电不会自己转

打开 `Core/Src/app/task_m3508_can_test/app_task_m3508_can_test.c`，搜
`M3508_TEST_SPIN_MASK`，默认是 `0x0F`（**1~4 号电机都参与**），
且 `WAIT_FEEDBACK` 阶段全程零电流。这样即使接线错误也不会有意外动作。

---

## 第 3 步：上板验证（真正的验证，编译器做不到）

前两步只证明「代码能编译、逻辑看起来对」。**CAN 能不能真的通、电机能不能真的转，
必须上板。** 我这边没有实机，所以这部分完全没验证过。

### 3.1 先解决一个前提：日志现在看不到

`.ioc` 没有启用任何 USART，`__io_putchar()` 也没有强定义，所以 `printf` 的输出
**被静默丢弃**。在补上串口之前，调试只能靠**调试器看变量**。

补串口需要改 `.ioc`，**你确认用哪个 USART 之后我再动**。

### 3.2 用调试器看这些变量

| 变量 | 期望值 | 不对说明什么 |
|---|---|---|
| `g_chassis_can_test_task_handle` | 非 NULL | NULL = FreeRTOS 堆不足，任务没建起来 |
| `g_c620_m3508_slots[i].in_use` | 4 个都是 `true` | 少于 4 个 = 注册失败或 ID 重复 |
| `g_chassis_motors[i].state` | 收到反馈后为 `2`(ONLINE) 或 `3`(READY) | 一直 `1`(OFFLINE) = 收不到反馈 |
| `...feedback.angle_raw` | 转动时持续变化（0~8191） | 不变 = 反馈没更新 |
| `...feedback.speed_rpm` | 自转时非零 | — |
| `...last_feedback_tick` | 持续更新，与 `HAL_GetTick()` 差距 < 100 | 差距大 = 已掉线 |

### 3.3 收不到反馈时的排查顺序

按这个顺序查，命中率最高：

1. 电调上电了吗？（C620 需要 24 V 供电，不是只插 CAN 线就行）
2. CANH / CANL 接反了吗？
3. 总线两端有 120 Ω 终端电阻吗？
4. 波特率是 1 Mbit/s 吗？（`Prescaler=3`、`BS1=10TQ`、`BS2=3TQ`，APB1=42 MHz）
5. 电调拨码 ID 和代码里的 ID 一致吗？（反馈 ID = `0x200` + 电调 ID）
6. 过滤器生效了吗？`CAN1_RX0_IRQn` 使能了吗？

### 3.4 用 CAN 分析仪确认时序

- 主控应每 **2 ms** 发一条 `0x200` 帧（8 字节）；
- 电调应每约 **1 ms** 回一条 `0x201 ~ 0x204` 帧。

### 3.5 验证掉线保护

拔掉 CAN 线，100 ms 内应该看到：

```
target_current_raw == 0
output_enabled     == false
requires_rearm     == true
state              == 1 (OFFLINE)
```

**插回后电机不应该自动转动** —— 必须上层重新使能。这一条如果没通过，说明安全逻辑有问题，
先别上实车。

---

## 附：为什么不能用 STM32CubeIDE 直接构建

已实测：`.ioc` 的 `TargetToolchain=CMake`，但 `build/Debug/CMakeCache.txt` 依赖的
`cube-cmake` 包装器**不在 PATH 上**（`Get-Command cube-cmake` 查不到），
所以 IDE 里的 CMake 构建和 `cmake --preset Debug` 当前都跑不起来。

这也是我写 `tools/verify.ps1` 的原因：它绕过 `cube-cmake`，直接用真实编译器，
结果等价。修 CMake 链的几种做法记在 `OPEN_QUESTIONS.md` Q8。

---

## 附：脚本本身的注意事项

`tools/verify.ps1` 含中文，**必须保存为带 UTF-8 BOM 的格式**。
Windows PowerShell 5.1 读取 `.ps1` 时默认按 ANSI 解码，没有 BOM 会导致中文变乱码
并引发语法错误（报 `Missing argument in parameter list` 之类的怪错）。
用 VSCode 保存时选编码 `UTF-8 with BOM`。

# task_chassis_spin —— 底盘小陀螺任务

## 职责

普通遥控模式只在 `switch_s1=2 && switch_s2=2` 时运行；键盘会话由模式管理器切换到同一任务。
任务以 2 ms 周期读取 DR16、
用目标角速度积分航向角、读取四个 M3508 的 CAN 转速并发送小陀螺目标电流。

普通底盘任务和测试任务由模式管理器挂起，三个任务不会同时发送底盘 CAN 控制帧。

## 坐标与混控

进入小陀螺模式时航向角清零。右转为正方向，默认目标角速度为 `+2.0 rad/s`。
遥控器只使用 `ch[2]` 和 `ch[3]`，`ch[0]` 在此模式下忽略。

大地坐标输入先转换到底盘坐标：

```text
body_vx = earth_vx*cos(theta) - earth_vy*sin(theta)
body_vy = earth_vx*sin(theta) + earth_vy*cos(theta)
theta += target_omega * dt
```

随后和自转目标合成为 ID1~ID4 的目标转子 rpm，并使用已有的四个速度 PID。

## 角速度反馈

当前没有 IMU 驱动，任务使用四个 M3508 的逻辑转速估算车体右转角速度：

```text
omega = (v_ID2 + v_ID3 - v_ID1 - v_ID4)
        / (4 * (half_length + half_width))
```

轮半径、半长、半宽和减速比集中定义在 `chassis_control.h`，目前是临时值。
后续接入陀螺仪时，只需替换角速度读取函数，任务调度和坐标变换不变。

## 电流限制

- 普通底盘：理论 `±2867 raw`（约 `±3.5 A`），实际 `±4915 raw`（约 `±6 A`）。
- 小陀螺：理论 `±5325 raw`（约 `±6.5 A`），实际 `±8192 raw`（约 `±10 A`）。

小陀螺的平移输入作为等效目标转速，与自转目标合并后由一个速度 PID 输出总电流。
理论限幅只用于观察满速参考，PID 输出和最终 CAN 指令使用实际 ±10 A 限制。

## 任务接口

| 接口 | 上下文 | 说明 |
|---|---|---|
| `task_chassis_spin_entry` | FreeRTOS 任务 | 小陀螺任务入口，永久等待模式管理器唤醒 |
| `ChassisControl_UpdateSpin` | 小陀螺任务 | 坐标转换和四轮目标转速生成 |
| `ChassisControl_SetCurrentLimitsRaw` | 小陀螺任务 | 设置理论 ±6.5 A、实际 ±10 A |

DBUS 离线、CAN Bus-Off、电机离线或周期超过 100 ms 时，任务清零航向和 PID 历史并发送零电流。

键盘会话不会进入本任务；本任务仍由 S1=2、S2=2 和摇杆控制。

## 验证

```powershell
python tools/test_pid.py
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\verify.ps1
```

主机测试验证坐标变换、右转符号、限幅和复位；真实角速度和几何参数仍需上板确认。

/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include "app/task_m3508_can_test/app_task_m3508_can_test.h"
#include "app/task_chassis_control/app_task_chassis_control.h"
#include "app/task_chassis_spin/app_task_chassis_spin.h"
#include "app/task_chassis_mode_manager/app_task_chassis_mode_manager.h"
#include "app/task_vofa_debug/app_task_vofa_debug.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
/*
 * 底盘 CAN 自检任务的对象与属性。
 *
 * 栈：512 字（2048 字节）。比默认任务的 512 字节大得多，原因是任务里调用了
 *     printf，newlib-nano 的格式化路径栈开销较大；栈不足的典型表现是打印内容
 *     错乱或直接 HardFault。osThreadAttr_t.stack_size 的单位是字节，
 *     所以必须乘以 sizeof(StackType_t) 才能得到“字”数对应的字节数。
 * Stack: 2048 bytes because printf is stack hungry. stack_size is in bytes, hence
 * the sizeof(StackType_t) factor.
 *
 * 优先级：osPriorityNormal。CAN 控制帧靠固定 2 ms 周期保证，不需要抢占其它任务；
 *         提高优先级反而可能让 printf 阻塞时拖慢更高优先级的系统任务。
 * Priority: Normal; the 2 ms period keeps the control frame regular, not priority.
 */
static osThreadId_t g_chassis_can_test_task_handle = NULL;
static osThreadId_t g_chassis_control_task_handle = NULL;
static osThreadId_t g_chassis_spin_task_handle = NULL;
static osThreadId_t g_chassis_mode_manager_task_handle = NULL;
static osThreadId_t g_vofa_debug_task_handle = NULL;
static const osThreadAttr_t g_chassis_can_test_task_attributes = {
    .name = "chassisCanTest",
    .attr_bits = 0U,                /* 不使用 TrustZone/特权相关属性. */
    .cb_mem = NULL,                 /* 控制块由 osThreadNew 动态分配. */
    .cb_size = 0U,
    .stack_mem = NULL,              /* 栈由 osThreadNew 从 FreeRTOS 堆分配. */
    .stack_size = 512U * sizeof(StackType_t),
    .priority = (osPriority_t)osPriorityNormal,
    .tz_module = 0U,                /* 非 TrustZone 工程，固定为 0. */
    .reserved = 0U,                 /* 协议要求保留字段必须为 0. */
};
static const osThreadAttr_t g_chassis_control_task_attributes = {
    .name = "chassisControl",
    .stack_size = 512U * sizeof(StackType_t),
    .priority = (osPriority_t)osPriorityNormal,
};
static const osThreadAttr_t g_chassis_spin_task_attributes = {
    .name = "chassisSpin",
    .stack_size = 512U * sizeof(StackType_t),
    .priority = (osPriority_t)osPriorityNormal,
};
static const osThreadAttr_t g_chassis_mode_manager_task_attributes = {
    .name = "chassisModeManager",
    .stack_size = 256U * sizeof(StackType_t),
    .priority = (osPriority_t)osPriorityNormal,
};
static const osThreadAttr_t g_vofa_debug_task_attributes = {
    .name = "vofaDebug",
    .stack_size = 768U * sizeof(StackType_t),
    .priority = (osPriority_t)osPriorityNormal,
};
/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
/* 底盘 M3508 CAN 环路自检任务入口。 */
void task_chassis_can_test_entry(void *argument);
/* 底盘遥控任务入口。 */
void task_chassis_control_entry(void *argument);
/* 底盘小陀螺任务入口。 */
void task_chassis_spin_entry(void *argument);
/* 测试/底盘模式管理任务入口。 */
void task_chassis_mode_manager_entry(void *argument);
/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /*
   * 创建底盘 CAN 自检任务。
   * 时机：osKernelStart() 之前的 MX_FREERTOS_Init() 中；此时 main() 已经调用过
   *      BoardCan_Init()，任务第一次进入循环时 CAN 已经具备收发能力。
   * Created before osKernelStart(), after main() already called BoardCan_Init().
   *
   * 失败处理：osThreadNew 返回 NULL 说明 FreeRTOS 堆不足以分配栈和控制块
   *          （configTOTAL_HEAP_SIZE = 15360 字节）。此时打印一条提示并继续运行
   *          默认任务，而不是调用 Error_Handler()，便于用调试器查看堆剩余量。
   * On failure, log and keep running so a debugger can inspect the remaining heap.
   */
  g_chassis_can_test_task_handle =
      osThreadNew(task_chassis_can_test_entry, NULL,
                  &g_chassis_can_test_task_attributes);
  if (g_chassis_can_test_task_handle == NULL) {
    printf("[freertos] chassis CAN test task create failed\r\n");
  }
  g_chassis_control_task_handle =
      osThreadNew(task_chassis_control_entry, NULL,
                  &g_chassis_control_task_attributes);
  if (g_chassis_control_task_handle == NULL) {
    printf("[freertos] chassis control task create failed\r\n");
  }
  g_chassis_spin_task_handle =
      osThreadNew(task_chassis_spin_entry, NULL,
                  &g_chassis_spin_task_attributes);
  if (g_chassis_spin_task_handle == NULL) {
    printf("[freertos] chassis spin task create failed\r\n");
  }
  g_chassis_mode_manager_task_handle =
      osThreadNew(task_chassis_mode_manager_entry, NULL,
                  &g_chassis_mode_manager_task_attributes);
  if (g_chassis_mode_manager_task_handle == NULL) {
    printf("[freertos] chassis mode manager task create failed\r\n");
  }
  g_vofa_debug_task_handle =
      osThreadNew(task_vofa_debug_entry, NULL, &g_vofa_debug_task_attributes);
  if (g_vofa_debug_task_handle == NULL) {
    printf("[freertos] VOFA debug task create failed\r\n");
  }
  ChassisModeManager_SetTasks((TaskHandle_t)g_chassis_can_test_task_handle,
                              (TaskHandle_t)g_chassis_control_task_handle,
                              (TaskHandle_t)g_chassis_spin_task_handle);
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  (void)argument;
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartDefaultTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */


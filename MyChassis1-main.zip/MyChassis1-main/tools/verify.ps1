﻿#Requires -Version 5.1
<#
================================================================================
 verify.ps1  ——  MyChassis1 工程离线编译/链接自检脚本
                 Offline compile/link self-check for the MyChassis1 project.

 作用 / Purpose
   不依赖 STM32CubeIDE 和 `cube-cmake` 包装器，直接用 STM32Cube 自带的
   arm-none-eabi-gcc + CMake + Ninja 把整个工程编译并链接成 .elf。
   用途：改完代码后快速确认「有没有编译错误、有没有新增告警、占用多少 Flash/RAM」。
   Builds the whole project with the bundled arm-none-eabi-gcc and reports errors,
   warnings, and memory usage. Use it after every code change.

 用法 / Usage
   pwsh -File tools\verify.ps1                # 完整编译 + 链接 + 内存占用
   pwsh -File tools\verify.ps1 -SyntaxOnly    # 只做语法检查，最快（约 10 秒）
   pwsh -File tools\verify.ps1 -Keep          # 保留中间产物 .o / .su 便于排查
   pwsh -File tools\verify.ps1 -Wextra        # 额外开启 -Wextra 严格告警

 退出码 / Exit code
   0 = 全部通过； 1 = 有编译或链接错误。
   告警不会让脚本失败，但会单独统计并打印出来，请人工确认。
================================================================================
#>
[CmdletBinding()]
param(
  # 只做语法检查（-fsyntax-only），不生成目标文件，速度最快。
  [switch]$SyntaxOnly,
  # 保留 .dsh-verify 中间目录，便于查看 .su 栈用量文件和 .map 映射文件。
  [switch]$Keep,
  # 额外开启 -Wextra（更严格，可能出现 HAL 库自身的告警）。
  [switch]$Wextra,
  # 覆盖 STM32Cube bundles 根目录（默认自动探测）。
  [string]$BundleRoot = ""
)

$ErrorActionPreference = "Stop"

# ---------------------------------------------------------------------------
# 0. 定位目录与工具链 / Locate project and toolchain
# ---------------------------------------------------------------------------
$Root = Split-Path -Parent $PSScriptRoot      # 脚本放在 tools\ 下，工程根是它的上级
if (-not (Test-Path (Join-Path $Root "MyChassis1.ioc"))) { $Root = $PSScriptRoot }
$Out = Join-Path $Root ".dsh-verify"

if ([string]::IsNullOrWhiteSpace($BundleRoot)) {
  $BundleRoot = Join-Path $env:LOCALAPPDATA "stm32cube\bundles"
}
if (-not (Test-Path $BundleRoot)) {
  Write-Host "[错误] 找不到 STM32Cube bundles 目录: $BundleRoot" -ForegroundColor Red
  Write-Host "       请用 -BundleRoot 指定，或先在 STM32CubeIDE 中安装工具链。" -ForegroundColor Red
  exit 1
}

# 在 bundles 下按名字前缀寻找唯一的可执行文件（版本号会变，所以不写死版本）。
function Find-Tool([string]$prefix, [string]$exe) {
  $hit = Get-ChildItem $BundleRoot -Recurse -Filter $exe -ErrorAction SilentlyContinue |
         Where-Object { $_.FullName -like "*$prefix*" } |
         Sort-Object FullName -Descending | Select-Object -First 1
  if ($null -eq $hit) { return $null }
  return $hit.FullName
}

$Gcc = Find-Tool "gnu-tools-for-stm32" "arm-none-eabi-gcc.exe"
$Sz  = Find-Tool "gnu-tools-for-stm32" "arm-none-eabi-size.exe"
if ($null -eq $Gcc) {
  Write-Host "[错误] 在 $BundleRoot 下找不到 arm-none-eabi-gcc.exe" -ForegroundColor Red
  exit 1
}

Write-Host "工程根目录 : $Root"
Write-Host "编译器     : $Gcc"
Write-Host ("模式       : " + $(if ($SyntaxOnly) { "语法检查 (-fsyntax-only)" } else { "完整编译 + 链接" }))
Write-Host ("严格告警   : " + $(if ($Wextra) { "开 (-Wall -Wextra)" } else { "关 (-Wall)" }))
Write-Host ""

# ---------------------------------------------------------------------------
# 1. 编译参数 / Build flags
#    这些参数必须与 cmake\gcc-arm-none-eabi.cmake 和 build\Debug\build.ninja
#    保持一致，否则验证结果不能代表真实构建。
#    Keep these in sync with cmake\gcc-arm-none-eabi.cmake and build.ninja.
# ---------------------------------------------------------------------------
$TargetFlags = @("-mcpu=cortex-m4", "-mfpu=fpv4-sp-d16", "-mfloat-abi=hard")
$WarnFlags   = @("-Wall") + $(if ($Wextra) { @("-Wextra") } else { @() })

$Defines = @("-DDEBUG", "-DSTM32F407xx", "-DUSE_HAL_DRIVER")

$IncludeDirs = @(
  "Core/Inc",
  "Drivers/STM32F4xx_HAL_Driver/Inc",
  "Drivers/STM32F4xx_HAL_Driver/Inc/Legacy",
  "Middlewares/Third_Party/FreeRTOS/Source/include",
  "Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2",
  "Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F",
  "Drivers/CMSIS/Device/ST/STM32F4xx/Include",
  "Drivers/CMSIS/Include"
) | ForEach-Object { "-I" + (Join-Path $Root $_) }

# -fstack-usage 让 GCC 为每个函数输出 .su 文件，记录该函数的栈帧大小，
# 用来核对 FreeRTOS 任务的 stack_size 是否足够（本工程任务调用了 printf）。
#
# 注意：-fstack-usage 只在真正产出目标文件时才有意义，而且它会把 .su 写在
# **当前工作目录**（文件名来自源文件，因此容易散落到工程根目录）。所以：
#   - 语法检查模式不加这个开关；
#   - 完整模式靠下面的 Push-Location 把工作目录切到输出目录再编译。
# -fstack-usage writes .su files into the CURRENT directory, so syntax-only mode
# omits it and the full build switches the working directory to the output dir.
$BaseCflags = $TargetFlags + $WarnFlags +
              @("-fdata-sections", "-ffunction-sections",
                "-O0", "-g3", "-std=gnu11") + $Defines + $IncludeDirs
$Cflags = if ($SyntaxOnly) { $BaseCflags } else { $BaseCflags + @("-fstack-usage") }

# ---------------------------------------------------------------------------
# 2. 源文件清单 / Source list
#    与 cmake\stm32cubemx\CMakeLists.txt 以及根 CMakeLists.txt 的用户源文件保持一致。
#    新增 .c 文件时，除了改 CMakeLists.txt，也要加到下面，否则本脚本会漏检。
#    Mirror of the CMake source lists; keep in sync when adding files.
# ---------------------------------------------------------------------------
$UserSrc = @(
  "Core/Src/bsp/board_can/board_can.c",
  "Core/Src/bsp/m3508_c620/m3508_c620.c",
  "Core/Src/bsp/dr16_dbus/dr16_dbus.c",
  "Core/Src/app/chassis_control/chassis_control.c",
  "Core/Src/app/pid_controller/pid_controller.c",
  "Core/Src/app/pid_parameter_store/pid_parameter_store.c",
  "Core/Src/app/task_vofa_debug/app_task_vofa_debug.c",
  "Core/Src/app/chassis_motors/chassis_motors.c",
  "Core/Src/app/task_m3508_can_test/app_task_m3508_can_test.c",
  "Core/Src/app/task_chassis_control/app_task_chassis_control.c",
  "Core/Src/app/task_chassis_spin/app_task_chassis_spin.c",
  "Core/Src/app/task_chassis_mode_manager/app_task_chassis_mode_manager.c"
)
$MxAppSrc = @(
  "Core/Src/main.c", "Core/Src/gpio.c", "Core/Src/freertos.c", "Core/Src/can.c",
  "Core/Src/dma.c", "Core/Src/usart.c",
  "Core/Src/stm32f4xx_it.c", "Core/Src/stm32f4xx_hal_msp.c",
  "Core/Src/stm32f4xx_hal_timebase_tim.c", "Core/Src/sysmem.c", "Core/Src/syscalls.c"
)
$HalSrc = @(
  "Core/Src/system_stm32f4xx.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_tim.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_tim_ex.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_can.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_uart.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc_ex.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ex.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ramfunc.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_gpio.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma_ex.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr_ex.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_cortex.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal.c",
  "Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_exti.c"
)
$FreeRtosSrc = @(
  "Middlewares/Third_Party/FreeRTOS/Source/croutine.c",
  "Middlewares/Third_Party/FreeRTOS/Source/event_groups.c",
  "Middlewares/Third_Party/FreeRTOS/Source/list.c",
  "Middlewares/Third_Party/FreeRTOS/Source/queue.c",
  "Middlewares/Third_Party/FreeRTOS/Source/stream_buffer.c",
  "Middlewares/Third_Party/FreeRTOS/Source/tasks.c",
  "Middlewares/Third_Party/FreeRTOS/Source/timers.c",
  "Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os2.c",
  "Middlewares/Third_Party/FreeRTOS/Source/portable/MemMang/heap_4.c",
  "Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F/port.c"
)

$AllSrc = $MxAppSrc + $UserSrc + $HalSrc + $FreeRtosSrc

# 只检查用户代码 = 生成代码 + 用户代码（不含 HAL/FreeRTOS 库代码）
$OwnSrc = @($MxAppSrc + $UserSrc)

# ---------------------------------------------------------------------------
# 3. 准备输出目录 / Prepare output directory
# ---------------------------------------------------------------------------
if (Test-Path $Out) { Remove-Item -Recurse -Force $Out }
New-Item -ItemType Directory -Force $Out | Out-Null

# 清理上一次中断运行（例如 Ctrl+C，或把脚本管道给 Select-Object -First 时
# 提前结束）可能残留在工程根目录的 a-*.su 栈用量文件和 _stderr.tmp。
# .su 是 GCC 用「源文件名.su」命名的，本工程的源文件名都是 a- 开头的 HAL 库文件，
# 所以这个前缀不会误删别人的文件。
# Remove leftovers from an interrupted previous run (Ctrl+C, or piping the script
# into Select-Object -First which stops it early).
Get-ChildItem $Root -Filter "a-*.su" -File -ErrorAction SilentlyContinue |
  Remove-Item -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $Root "_stderr.tmp") -Force -ErrorAction SilentlyContinue

function Get-ObjPath([string]$rel) {
  return Join-Path $Out (($rel -replace '[/\\]', '_') + ".o")
}

# 调用外部编译器并同时拿到 stdout + stderr + 退出码。
# 为什么不直接写 `& $Gcc ... 2>&1`：Windows PowerShell 5.1 会把原生程序写到 stderr 的
# 每一行包装成 ErrorRecord，一旦外面有 $ErrorActionPreference="Stop" 就可能被当成
# 终止性错误抛出。改为把 stderr 重定向到临时文件再读回来，行为在所有 PS 版本下一致。
# Capture stderr via a temp file: PS 5.1 wraps native stderr in ErrorRecords, which can
# become terminating errors under $ErrorActionPreference = "Stop".
$script:ErrFile = Join-Path $Out "_stderr.tmp"
function Invoke-Compiler([string[]]$Arguments) {
  $stdout = & $Gcc @Arguments 2>$script:ErrFile
  $stderr = if (Test-Path $script:ErrFile) { Get-Content $script:ErrFile -Raw } else { "" }
  Remove-Item $script:ErrFile -Force -ErrorAction SilentlyContinue
  $lines = @()
  if ($stdout) { $lines += $stdout }
  if ($stderr -and $stderr.Trim().Length -gt 0) { $lines += ($stderr -split "`r?`n" | Where-Object { $_ -ne "" }) }
  return [pscustomobject]@{ ExitCode = $LASTEXITCODE; Lines = $lines; Text = ($lines -join "`n") }
}

# ---------------------------------------------------------------------------
# 4. 编译 / Compile
#
# 编译期间把当前工作目录切到输出目录：-fstack-usage 生成的 .su 会落在当前目录，
# 不切换的话 39 个 a-*.su 文件会散落到工程根目录，污染工作区。
# 用 try/finally 保证无论中途是否报错都能切回来。
# Switch the working directory during the build so -fstack-usage writes its .su
# files into the output folder instead of scattering them into the project root.
# ---------------------------------------------------------------------------
$fail = 0
$warnCount = 0
$warnLines = New-Object System.Collections.Generic.List[string]
$suFiles   = New-Object System.Collections.Generic.List[string]
$objs      = New-Object System.Collections.Generic.List[string]
$elf       = Join-Path $Out "MyChassis1.elf"

Push-Location $Out
try {
Write-Host "===== 编译 $($AllSrc.Count) 个源文件 =====" -ForegroundColor Cyan
for ($i = 0; $i -lt $AllSrc.Count; $i++) {
  $rel = $AllSrc[$i]
  $obj = Get-ObjPath $rel
  $idx = "{0,3}/{1}" -f ($i + 1), $AllSrc.Count

  # 语法检查模式不产出 .o；完整模式才需要 -o 和 .su 栈用量文件。
  if ($SyntaxOnly) {
    $r = Invoke-Compiler @($Cflags + @("-fsyntax-only", (Join-Path $Root $rel)))
  } else {
    $r = Invoke-Compiler @($Cflags + @("-c", (Join-Path $Root $rel), "-o", $obj))
    $objs.Add($obj)
  }

  # 只对用户自己的代码打印告警，HAL/FreeRTOS 库代码的告警噪音太大。
  $isOwn = $OwnSrc -contains $rel
  $hasWarn = $r.Text -match "warning:"

  if ($r.ExitCode -ne 0) {
    Write-Host "$idx 失败  $rel" -ForegroundColor Red
    $r.Lines | ForEach-Object { Write-Host "        $_" -ForegroundColor Red }
    $fail++
  } elseif ($hasWarn) {
    $warnCount++
    if ($isOwn) {
      Write-Host "$idx 告警  $rel" -ForegroundColor Yellow
      $r.Lines | ForEach-Object { Write-Host "        $_" -ForegroundColor Yellow }
      $warnLines.Add("$rel : " + $r.Text)
    } else {
      Write-Host "$idx 告警(库) $rel" -ForegroundColor DarkGray
    }
  } else {
    Write-Host "$idx 通过  $rel" -ForegroundColor Green
  }

  if (-not $SyntaxOnly) {
    $su = [System.IO.Path]::ChangeExtension($obj, ".su")
    if (Test-Path $su) { $suFiles.Add($su) }
  }
}

# ---------------------------------------------------------------------------
# 5. 汇编启动文件 / Assemble startup
# ---------------------------------------------------------------------------
if (-not $SyntaxOnly) {
  Write-Host ""
  Write-Host "===== 汇编启动文件 =====" -ForegroundColor Cyan
  $startObj = Join-Path $Out "startup_stm32f407xx.o"
  $r = Invoke-Compiler @($Cflags + @("-x", "assembler-with-cpp", "-c",
                                    (Join-Path $Root "startup_stm32f407xx.s"), "-o", $startObj))
  if ($r.ExitCode -ne 0) {
    Write-Host "启动文件汇编失败" -ForegroundColor Red
    $r.Lines | ForEach-Object { Write-Host "        $_" -ForegroundColor Red }
    $fail++
  } else {
    Write-Host "通过  startup_stm32f407xx.s" -ForegroundColor Green
    $objs.Add($startObj)
  }
}

# ---------------------------------------------------------------------------
# 6. 链接 / Link
# ---------------------------------------------------------------------------
if (-not $SyntaxOnly -and $fail -eq 0) {
  Write-Host ""
  Write-Host "===== 链接 =====" -ForegroundColor Cyan
  $LdFlags = $TargetFlags + @(
    "-T", (Join-Path $Root "STM32F407xx_FLASH.ld"),
    "--specs=nano.specs",
    "-Wl,-Map=$Out/MyChassis1.map",
    "-Wl,--gc-sections",
    "-Wl,--print-memory-usage"
  )
  $r = Invoke-Compiler @($LdFlags + $objs + @("-lm", "-o", $elf))
  if ($r.ExitCode -ne 0) {
    Write-Host "链接失败" -ForegroundColor Red
    $r.Lines | ForEach-Object { Write-Host "        $_" -ForegroundColor Red }
    $fail++
  } else {
    $r.Lines | ForEach-Object { Write-Host "  $_" }
    Write-Host "链接通过 -> $elf" -ForegroundColor Green
  }
}
} finally {
  # 无论编译成功、失败还是抛异常，都要把工作目录切回调用者原来的位置。
  Pop-Location
}

# ---------------------------------------------------------------------------
# 7. 代码体积 / Firmware size
# ---------------------------------------------------------------------------
if (-not $SyntaxOnly -and (Test-Path $elf)) {
  Write-Host ""
  Write-Host "===== 固件体积 (text=Flash, data=Flash+RAM, bss=RAM) =====" -ForegroundColor Cyan
  & $Sz $elf
}

# ---------------------------------------------------------------------------
# 8. 用户任务的栈用量 / Stack usage of user code
#    重点看任务入口函数那一行，它的 Bytes 是任务自身的栈帧；
#    再加上它调用的最深的函数（printf 的 vfprintf），必须小于任务 stack_size。
# ---------------------------------------------------------------------------
if ($suFiles.Count -gt 0) {
  Write-Host ""
  Write-Host "===== 用户代码栈用量最大的 10 个函数 =====" -ForegroundColor Cyan
  $rows = foreach ($f in $suFiles) {
    foreach ($line in (Get-Content $f)) {
      if ($line -match "^\s*$") { continue }
      $p = $line -split "`t"
      if ($p.Count -ge 2) {
        [pscustomobject]@{ Bytes = [int]$p[1]; Func = ($p[0] -split '[/\\]')[-1] }
      }
    }
  }
  $rows | Sort-Object Bytes -Descending | Select-Object -First 10 |
    Format-Table -AutoSize | Out-String -Width 160 | Write-Host
  Write-Host "提示: FreeRTOS 任务栈以字节计。本工程 chassisCanTest 任务 2048 字节，" -ForegroundColor DarkGray
  Write-Host "      任务自身栈帧 + vfprintf 调用链必须留有余量。" -ForegroundColor DarkGray
}

# ---------------------------------------------------------------------------
# 9. 清理与汇总 / Cleanup and summary
# ---------------------------------------------------------------------------
if (-not $Keep) { Remove-Item -Recurse -Force $Out -ErrorAction SilentlyContinue }

Write-Host ""
Write-Host "==================== 汇总 ====================" -ForegroundColor Cyan
if ($fail -eq 0) {
  Write-Host "结果: 通过 (0 错误, $warnCount 个文件有告警)" -ForegroundColor Green
} else {
  Write-Host "结果: 失败 ($fail 个错误)" -ForegroundColor Red
}
if (-not $Keep) { Write-Host "中间产物已清理（加 -Keep 可保留 .o/.su/.map）" -ForegroundColor DarkGray }

exit $(if ($fail -eq 0) { 0 } else { 1 })

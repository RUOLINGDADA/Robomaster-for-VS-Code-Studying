"""VOFA 调参协议和 JustFloat 打包的主机级回归测试。"""

import math
import struct
import zlib


HEADER = b"\xA5\x5A"
CMD_SET = 0x01
CMD_SAVE = 0x02
CMD_GET = 0x03
KP_MAX = 100.0
KI_MAX = 100.0
KD_MAX = 10.0


def crc16(data: bytes) -> int:
    value = 0xFFFF
    for byte in data:
        value ^= byte
        for _ in range(8):
            value = (value >> 1) ^ 0xA001 if value & 1 else value >> 1
    return value


def command_frame(command: int, payload: bytes = b"") -> bytes:
    body = HEADER + bytes((command, len(payload))) + payload
    value = crc16(body)
    return body + struct.pack("<H", value)


def valid_gains(payload: bytes) -> bool:
    if len(payload) != 12:
        return False
    kp, ki, kd = struct.unpack("<3f", payload)
    return (all(math.isfinite(value) for value in (kp, ki, kd)) and
            0.0 <= kp <= KP_MAX and 0.0 <= ki <= KI_MAX and
            0.0 <= kd <= KD_MAX)


def parse_one(frame: bytes):
    if len(frame) < 6 or frame[:2] != HEADER:
        return None
    if frame[3] + 6 != len(frame):
        return None
    if crc16(frame[:-2]) != struct.unpack("<H", frame[-2:])[0]:
        return None
    command, length = frame[2], frame[3]
    if command == CMD_SET and length == 12 and valid_gains(frame[4:-2]):
        return command, frame[4:-2]
    if command in (CMD_SAVE, CMD_GET) and length == 0:
        return command, b""
    return None


def ack(command: int, status: int, payload: bytes = b"") -> bytes:
    body = HEADER + bytes((command | 0x80, status, len(payload))) + payload
    return body + struct.pack("<H", crc16(body))


def telemetry(values) -> bytes:
    assert len(values) == 19
    return struct.pack("<19f", *values) + b"\x00\x00\x80\x7F"


def slider_commands(kp: float, ki: float, kd: float):
    """VOFA+ 滑条 Str 绑定命令：%f 会由控件替换为当前浮点值。"""
    return (f"KP={kp:g}\r\n", f"KI={ki:g}\r\n", f"KD={kd:g}\r\n")


def test_protocol() -> None:
    gains = struct.pack("<3f", 4.0, 2.0, 0.5)
    set_frame = command_frame(CMD_SET, gains)
    assert len(set_frame) == 18
    assert parse_one(set_frame) == (CMD_SET, gains)

    corrupted = bytearray(set_frame)
    corrupted[-1] ^= 0x01
    assert parse_one(bytes(corrupted)) is None
    assert parse_one(command_frame(CMD_SET, b"\x00")) is None
    assert parse_one(command_frame(CMD_SAVE)) == (CMD_SAVE, b"")
    assert parse_one(command_frame(CMD_GET)) == (CMD_GET, b"")
    assert parse_one(command_frame(CMD_SET, b"\x00")) is None
    assert parse_one(command_frame(0x7F)) is None
    assert parse_one(command_frame(CMD_SET, struct.pack("<3f", math.nan, 0.0, 0.0))) is None
    assert parse_one(command_frame(CMD_SET, struct.pack("<3f", 0.0, 0.0, 11.0))) is None

    assert slider_commands(4.538, 3.045, 2.671) == (
        "KP=4.538\r\n", "KI=3.045\r\n", "KD=2.671\r\n")

    get_ack = ack(CMD_GET, 0, gains)
    assert get_ack[:5] == b"\xA5\x5A\x83\x00\x0C"
    assert crc16(get_ack[:-2]) == struct.unpack("<H", get_ack[-2:])[0]
    assert ack(CMD_SET, 0)[2:5] == b"\x81\x00\x00"

    values = [float(index) for index in range(19)]
    frame = telemetry(values)
    assert len(frame) == 19 * 4 + 4
    assert struct.unpack("<19f", frame[:-4]) == tuple(values)
    assert frame[-4:] == b"\x00\x00\x80\x7F"

    # Flash 记录的 CRC 覆盖 magic/version/sequence/三个 float，不包含 crc32 字段。
    record_body = struct.pack("<3I3f", 0x50494431, 1, 1, 4.0, 2.0, 0.5)
    record_crc = zlib.crc32(record_body) & 0xFFFFFFFF
    assert record_crc == 0x60E27D5C
    record = record_body + struct.pack("<I", record_crc)
    assert zlib.crc32(record[:-4]) & 0xFFFFFFFF == struct.unpack("<I", record[-4:])[0]


if __name__ == "__main__":
    test_protocol()
    print("PASS: VOFA protocol, CRC, ACK, telemetry and Flash CRC")

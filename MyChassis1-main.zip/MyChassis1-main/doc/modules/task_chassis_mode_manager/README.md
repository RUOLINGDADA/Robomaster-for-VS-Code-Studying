# task_chassis_mode_manager —— 底盘模式管理任务

## 职责

每 10 ms 读取 DR16，默认根据 `switch_s1/switch_s2` 选择三个互斥工作任务：

- `1`（向上）：唤醒 `task_chassis_can_test_entry`；
- `S1=2 && S2!=2`：唤醒 `task_chassis_control_entry`；
- `S1=2 && S2=2`：唤醒 `task_chassis_spin_entry`；
- 中间档、无效档或遥控器离线：三个任务都挂起。

键盘会话由 Shift 按下沿开启或关闭。开启后固定使用普通底盘任务，忽略所有摇杆和拨杆；Ctrl
当前不参与模式切换，保留给后续功能扩展。DBUS 掉线会退出键盘会话并发送零电流，重新上线后
恢复 S1/S2 选择。

## 切换顺序

切换时先挂起三个工作任务，再调用 `ChassisMotors_StopAll()` 并发送零电流，最后唤醒目标任务。
因此不会有两个任务同时发送 `0x200`，也不会把上一个模式的目标电流带入下一个模式。

## 初始化与失败处理

任务启动后调用一次 `ChassisMotors_Init()`。初始化失败时保留任务并每秒等待，方便调试器检查
CAN 注册表；不会让未初始化的工作任务发送控制帧。

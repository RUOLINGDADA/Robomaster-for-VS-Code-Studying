/**
  ******************************************************************************
  * @file    chassis_control.h
  * @brief   DR16 摇杆到转子目标转速、速度 PID 到目标电流的接口。
  *
 * 在底盘任务中执行死区、混控和四个速度 PID；支持普通底盘与小陀螺目标生成。
 * 不负责 CAN 发送、位置回绕和电机使能。
  * 目标数组由底盘控制任务更新，调试器和后续控制模块可以直接观察或继续处理。
  ******************************************************************************
  */

#ifndef CHASSIS_CONTROL_H
#define CHASSIS_CONTROL_H

#include "bsp/dr16_dbus/dr16_dbus.h"

#include <stdint.h>
#include <stdbool.h>

/** 摇杆满量程对应的转子目标转速，单位 rpm；临时值，轮子转速须除以实测减速比。 */
#define CHASSIS_CONTROL_SPEED_RPM_MAX 6000.0f

/** 速度环 Kp，单位：C620 原始电流/rpm；实际限幅和目标转速均需实机整定。 */
#define CHASSIS_CONTROL_SPEED_KP 4.0f
/** 速度环 Ki，单位：C620 原始电流/(rpm·s)。 */
#define CHASSIS_CONTROL_SPEED_KI 2.0f
/** 速度环 Kd，单位：C620 原始电流·s/rpm；先使用 PI，确认反馈噪声后再增加。 */
#define CHASSIS_CONTROL_SPEED_KD 0.0f
/** 积分项最大电流原始值，约 1.22 A。 */
#define CHASSIS_CONTROL_INTEGRAL_RAW_MAX 1000.0f
/** 倒数变速积分系数 a，单位 1/rpm；权重=1/(1+a|e|)，100 rpm 时为0.5，需整定。 */
#define CHASSIS_CONTROL_INTEGRAL_ERROR_SCALE 0.01f
/** 微分一阶低通截止频率，单位 Hz；Kd=0 时不产生微分输出。 */
#define CHASSIS_CONTROL_DERIVATIVE_CUTOFF_HZ 30.0f

/** 运行时速度环 Kp 的安全上限，单位：原始电流/rpm。 */
#define CHASSIS_CONTROL_SPEED_KP_MAX 100.0f
/** 运行时速度环 Ki 的安全上限，单位：原始电流/(rpm·s)。 */
#define CHASSIS_CONTROL_SPEED_KI_MAX 100.0f
/** 运行时速度环 Kd 的安全上限，单位：原始电流·s/rpm。 */
#define CHASSIS_CONTROL_SPEED_KD_MAX 10.0f

/** 底盘电机数量；数组按电调 ID 顺序：下标0=1号右前、下标1=2号左前、下标2=3号左后、下标3=4号右后。 */
#define CHASSIS_CONTROL_MOTOR_COUNT 4U

/** 摇杆死区，单位：DR16 中心化原始计数。 */
#define CHASSIS_CONTROL_RC_DEAD_ZONE 30

/** 摇杆满量程，单位：DR16 中心化原始计数。 */
#define CHASSIS_CONTROL_RC_MAX 660

/** 键盘直线起步时长，单位：秒；之后接入对数曲线 / Linear start duration in seconds. */
#define CHASSIS_CONTROL_KEYBOARD_RAMP_T1_S 0.20f

/** 直线段结束速度占目标的比例，无量纲 / Speed fraction at the linear/log junction. */
#define CHASSIS_CONTROL_KEYBOARD_LINEAR_RATIO (1.0f / 3.0f)

/** 对数弯曲系数，无量纲、必须大于0；默认4，调整后须核对单调性 / Log shape factor. */
#define CHASSIS_CONTROL_KEYBOARD_LOG_SHAPE 4.0f

/** 键盘起步完成时间，单位：秒；必须大于T1，到达100%且斜率归零 / Ramp end time. */
#define CHASSIS_CONTROL_KEYBOARD_RAMP_T3_S 1.00f

/** 普通底盘理论电流限幅，单位：C620 原始值，约 3.5 A；仅作满速参考。 */
#define CHASSIS_CONTROL_THEORETICAL_CURRENT_RAW_MAX 2867

/** 普通底盘实际电流限幅，单位：C620 原始值，约 6.0 A；PID 和发送保护上限。 */
#define CHASSIS_CONTROL_ACTUAL_CURRENT_RAW_MAX 4915

/** 小陀螺理论电流限幅，单位：C620 原始值，约 6.5 A；仅作满速参考。 */
#define CHASSIS_SPIN_THEORETICAL_CURRENT_RAW_MAX 5325

/** 小陀螺实际电流限幅，单位：C620 原始值，约 10.0 A；PID 和发送保护上限。 */
#define CHASSIS_SPIN_ACTUAL_CURRENT_RAW_MAX 8192

/** 小陀螺默认车体右转目标角速度，单位：rad/s；正值表示右转。 */
#define CHASSIS_SPIN_TARGET_OMEGA_RAD_S 2.0f

/** 小陀螺轮半径，单位：m；暂为可调估计值，需上板实测。 */
#define CHASSIS_SPIN_WHEEL_RADIUS_M 0.076f

/** 小陀螺底盘半轴距，单位：m；暂为可调估计值，需上板实测。 */
#define CHASSIS_SPIN_HALF_LENGTH_M 0.200f

/** 小陀螺底盘半轮距，单位：m；暂为可调估计值，需上板实测。 */
#define CHASSIS_SPIN_HALF_WIDTH_M 0.200f

/** M3508 电机转子到轮子的减速比；暂为可调估计值，需实测确认。 */
#define CHASSIS_SPIN_REDUCTION_RATIO 19.2f

/** 统一四个速度环的运行时 PID 参数 / Runtime gains shared by four speed loops. */
typedef struct {
  float kp; /**< 比例系数 / proportional gain. */
  float ki; /**< 积分系数 / integral gain. */
  float kd; /**< 微分系数 / derivative gain. */
} ChassisSpeedPidGainsTypeDef;

/**
 * 四个电机的目标电流，单位：C620 原始值；数组顺序为电调 ID 1、2、3、4。
 * 速度 PID 写入的是逻辑电流；方向变换后的电流见 g_chassis_motors[i].target_current_raw。
 * 实际范围由当前模式的实际限幅决定。volatile 便于调试器观察，
 * 不保证多个数组的原子快照。
 */
extern volatile int16_t
    g_chassis_target_current_raw[CHASSIS_CONTROL_MOTOR_COUNT];

/** ID 1~4 的逻辑转子目标转速，单位 rpm；已混控和限幅，尚未做安装方向变换。 */
extern volatile float g_chassis_target_speed_rpm[CHASSIS_CONTROL_MOTOR_COUNT];
/** ID 1~4 的逻辑实测转子转速，单位 rpm；与目标方向一致，用于调试 PID 误差。 */
extern volatile float g_chassis_feedback_speed_rpm[CHASSIS_CONTROL_MOTOR_COUNT];

/** 小陀螺积分航向角，单位 rad；进入小陀螺任务时清零。 */
extern volatile float g_chassis_spin_heading_rad;
/** 小陀螺目标车体角速度，单位 rad/s；正值表示右转。 */
extern volatile float g_chassis_spin_target_omega_rad_s;
/** 根据四轮反馈估算的车体角速度，单位 rad/s；正值表示右转。 */
extern volatile float g_chassis_spin_feedback_omega_rad_s;
/** 小陀螺四个电机的目标转子速度，单位 rpm，按电调 ID 1~4 排列。 */
extern volatile float
    g_chassis_spin_target_speed_rpm[CHASSIS_CONTROL_MOTOR_COUNT];

/** 当前模式理论电流限幅，单位：C620 原始值；只作参考和调试观察。 */
extern volatile int16_t g_chassis_theoretical_current_limit_raw;
/** 当前模式实际电流限幅，单位：C620 原始值；PID 输出的最终保护上限。 */
extern volatile int16_t g_chassis_actual_current_limit_raw;

/** 键盘即时 Vx 指令，单位 rpm；由 A/D 按键直接换算。 */
extern volatile float g_chassis_keyboard_command_vx_rpm;
/** 键盘即时 Vy 指令，单位 rpm；由 W/S 按键直接换算。 */
extern volatile float g_chassis_keyboard_command_vy_rpm;
/** 键盘即时 Wz 指令，单位 rpm；由 Q/E 按键直接换算。 */
extern volatile float g_chassis_keyboard_command_wz_rpm;
/** 键盘曲线处理后的 Vx 指令，单位 rpm；用于四轮混控。 */
extern volatile float g_chassis_keyboard_ramped_vx_rpm;
/** 键盘曲线处理后的 Vy 指令，单位 rpm；用于四轮混控。 */
extern volatile float g_chassis_keyboard_ramped_vy_rpm;
/** 键盘曲线处理后的 Wz 指令，单位 rpm；用于四轮混控。 */
extern volatile float g_chassis_keyboard_ramped_wz_rpm;

/**
 * @brief 初始化四个速度 PID 并清零目标。
 * @param 无。
 * @retval true 初始化成功；false 参数无效，禁止输出。
 * @note 底盘任务启动时调用一次；所有运行接口由底盘任务独占。
 */
bool ChassisControl_Init(void);

/**
 * @brief 提交一组统一四轮速度环 PID 参数。
 * @param gains Kp/Ki/Kd 参数，必须为有限值且在安全范围内。
 * @retval true 参数已接受；初始化前立即作为初始参数，运行中等待控制任务应用。
 * @retval false 参数为空、非有限或超出安全范围。
 * @note 运行中不会由调用方直接改 PID，避免 VOFA 任务与电机任务并发写控制器。
 */
bool ChassisControl_SetSpeedPidGains(
    const ChassisSpeedPidGainsTypeDef *gains);

/**
 * @brief 读取当前已经生效的统一速度环 PID 参数。
 * @param gains 输出参数，不能为 NULL。
 * @retval 无；参数为空时不执行任何操作。
 */
void ChassisControl_GetSpeedPidGains(ChassisSpeedPidGainsTypeDef *gains);

/**
 * @brief 在控制任务安全边界应用待处理的速度环 PID 参数。
 * @param 无。
 * @retval true 已应用一组新参数；false 当前没有待应用参数或控制器未初始化。
 * @note 应用时清除四个 PID 的积分、微分和历史误差。
 */
bool ChassisControl_ApplyPendingSpeedPidGains(void);

/**
 * @brief 根据单个电机的逻辑转速反馈计算电流。
 * @param motor_index 下标0~3，对应电调 ID 1~4。
 * @param speed_rpm 已修正安装方向的转子速度，单位 rpm。
 * @param dt_s 实际控制间隔，单位秒，必须大于0。
 * @retval 逻辑目标电流原始值，范围由当前模式限幅；非法输入返回0并复位该环。
 * @note 更新全局电流数组；不进行 CAN 发送。
 */
int16_t ChassisControl_CalcCurrent(uint32_t motor_index, float speed_rpm,
                                  float dt_s);

/**
 * @brief 清除单个离线电机的 PID 历史和调试数据。
 * @param motor_index 下标0~3，对应电调 ID 1~4。
 * @retval 无；越界不处理。
 * @note 仅由底盘任务调用；用于离线保护，避免残留积分影响重连。
 */
void ChassisControl_ResetMotor(uint32_t motor_index);

/**
 * @brief 根据一份 DR16 快照计算四个底盘电机目标转速。
 * @param data DR16 数据快照；为空、离线或不在底盘模式时目标和 PID 清零。
 * @retval 无。
 * @note 运行在底盘控制任务中；随后用反馈调用 CalcCurrent() 得到目标电流。
 */
void ChassisControl_Update(const DR16_Dbus_DataTypeDef *data);

/**
 * @brief  根据键盘位掩码和实际采样间隔生成普通底盘四轮目标转速。
 * @param  data DR16 数据快照；只读取 online 和 keyboard 字段。
 * @param  dt_s 本次控制间隔，单位秒；必须为有限正数。
 * @retval 无；键盘运动键全部释放时目标速度为零。
 * @note   键盘模式忽略摇杆和拨杆；W/S、A/D、E/Q 可以组合并抵消。
 *         按键释放立即清零目标；反向切换仍先经过零速再启动反向曲线。
 *         模式切换或掉线时由 Clear() 清除曲线历史。
 */
void ChassisControl_UpdateKeyboard(const DR16_Dbus_DataTypeDef *data,
                                   float dt_s);

/**
 * @brief 清零目标转速、电流、反馈观察值和四个速度 PID 历史。
 * @retval 无。
 * @note 底盘任务调用；模式管理任务必须先挂起底盘任务再调用。不会操作 CAN。
 */
void ChassisControl_Clear(void);

/**
 * @brief 设置当前模式的理论限幅和实际限幅。
 * @param theoretical_limit_raw 理论限幅，单位：C620 原始值，只用于参考。
 * @param actual_limit_raw 实际限幅，单位：C620 原始值，用于 PID 输出保护。
 * @retval 无；任一限幅非法时恢复普通模式默认值。
 * @note 只能由当前拥有底盘控制权的任务调用；不会清除 PID 历史。
 */
void ChassisControl_SetCurrentLimitsRaw(int16_t theoretical_limit_raw,
                                        int16_t actual_limit_raw);

/**
 * @brief 只更新当前模式的实际电流限幅。
 * @param actual_limit_raw 实际限幅，单位：C620 原始值。
 * @retval 无；非法值恢复普通模式默认实际限幅。
 * @note 理论限幅保持不变，不清除 PID 历史。
 */
void ChassisControl_SetActualCurrentLimitRaw(int16_t actual_limit_raw);

/**
 * @brief 根据大地坐标遥控输入生成小陀螺四轮目标转速。
 * @param data DR16 数据快照；必须在线且 S1=2，否则清零目标。
 * @param heading_rad 进入小陀螺模式后的积分航向角，单位 rad，正值表示右转。
 * @param target_omega_rad_s 目标车体角速度，单位 rad/s，正值表示右转。
 * @retval 无；结果写入普通目标数组和小陀螺调试数组。
 * @note 小陀螺忽略 ch[0]，只使用 ch[2]/ch[3]；角度由任务按目标角速度积分。
 */
void ChassisControl_UpdateSpin(const DR16_Dbus_DataTypeDef *data,
                               float heading_rad,
                               float target_omega_rad_s);

/**
 * @brief 写入小陀螺的车体角速度反馈观察值。
 * @param omega_rad_s 根据四轮 CAN 转速估算的车体角速度，单位 rad/s。
 * @retval 无；非法值写入0。
 */
void ChassisControl_SetSpinFeedbackOmega(float omega_rad_s);

#endif /* CHASSIS_CONTROL_H */

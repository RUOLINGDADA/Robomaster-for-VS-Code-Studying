/**
  ******************************************************************************
  * @file    app_task_m3508_can_test.h
  * @brief   M3508 电机自检任务接口。
  *
  * 任务只负责测试状态机和 2 ms 控制节拍；电机注册、CAN 接收和安全停止由
  * app/chassis_motors 模块统一处理。任务由模式管理任务挂起或唤醒。
  ******************************************************************************
  */

#ifndef APP_TASK_M3508_CAN_TEST_H
#define APP_TASK_M3508_CAN_TEST_H

/**
  * @brief  M3508 自检任务入口。
  * @param  argument FreeRTOS 任务参数，当前未使用。
  * @retval 无；任务入口不会返回。
  */
void task_chassis_can_test_entry(void *argument);

#endif /* APP_TASK_M3508_CAN_TEST_H */

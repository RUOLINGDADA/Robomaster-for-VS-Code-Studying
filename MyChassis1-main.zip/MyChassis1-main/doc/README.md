# MyChassis1 工程文档

本目录是 `D:\CubeMxProject\MyChassis1` 的长期对接入口。任何 agent 或新成员开始修改前，按顺序阅读：

1. 工程根目录 `AGENTS.md`：目录、命名、注释、FreeRTOS、CubeMX 与构建规则。
2. `PROJECT_CONTEXT.md`：当前硬件、软件入口、边界和已知状态。
3. `OPEN_QUESTIONS.md`：尚未确认的需求；实现前先读，完成后关闭相关问题。
4. `CODING_STYLE.md`：注释层次、底层解释和常见坑点的写法。
5. `protocol/` 下的协议说明：CAN 帧字段、字节序、单位和时序。
6. 对应模块目录下的 `README.md`：模块 API、任务模型和验证方法。
7. `CHANGELOG.md`：近期变更及其验证结果。

## 文档目录约定

```text
doc/
├── README.md              # 文档入口和阅读顺序（本文件）
├── PROJECT_CONTEXT.md     # 工程现状、边界、工具链
├── OPEN_QUESTIONS.md      # 需要用户确认的需求
├── CODING_STYLE.md        # 代码与注释规范
├── CHANGELOG.md           # 变更记录
├── protocol/              # CAN、串口等协议说明
└── modules/<module>/README.md
```

## 模块索引

| 模块 | 位置 | 文档 |
|---|---|---|
| CAN 板级层 | `Core/Inc/bsp/board_can/`、`Core/Src/bsp/board_can/` | [modules/board_can/README.md](modules/board_can/README.md) |
| C620 + M3508 驱动 | `Core/Inc/bsp/m3508_c620/`、`Core/Src/bsp/m3508_c620/` | [modules/m3508_c620/README.md](modules/m3508_c620/README.md) |
| 底盘 CAN 自检任务 | `Core/Src/app/task_m3508_can_test/` | [modules/task_m3508_can_test/README.md](modules/task_m3508_can_test/README.md) |
| 底盘公共电机模块 | `Core/Inc/app/chassis_motors/`、`Core/Src/app/chassis_motors/` | [modules/chassis_motors/README.md](modules/chassis_motors/README.md) |
| 底盘遥控任务 | `Core/Inc/app/task_chassis_control/`、`Core/Src/app/task_chassis_control/` | [modules/task_chassis_control/README.md](modules/task_chassis_control/README.md) |
| 底盘模式管理任务 | `Core/Inc/app/task_chassis_mode_manager/`、`Core/Src/app/task_chassis_mode_manager/` | [modules/task_chassis_mode_manager/README.md](modules/task_chassis_mode_manager/README.md) |
| 底盘小陀螺任务 | `Core/Inc/app/task_chassis_spin/`、`Core/Src/app/task_chassis_spin/` | [modules/task_chassis_spin/README.md](modules/task_chassis_spin/README.md) |
| DR16 DBUS 接收驱动 | `Core/Inc/bsp/dr16_dbus/`、`Core/Src/bsp/dr16_dbus/` | [modules/dr16_dbus/README.md](modules/dr16_dbus/README.md) |
| 底盘遥控速度与 PID 电流输出 | `Core/Inc/app/chassis_control/`、`Core/Src/app/chassis_control/` | [modules/chassis_control/README.md](modules/chassis_control/README.md) |
| 通用单环及级联 PID | `Core/Inc/app/pid_controller/`、`Core/Src/app/pid_controller/` | [modules/pid_controller/README.md](modules/pid_controller/README.md) |
| PID 参数 Flash 存储 | `Core/Inc/app/pid_parameter_store/`、`Core/Src/app/pid_parameter_store/` | 由 VOFA 调试任务调用 |
| VOFA 调试任务 | `Core/Inc/app/task_vofa_debug/`、`Core/Src/app/task_vofa_debug/` | USART1 蓝牙调参与波形输出 |
| C620 CAN 协议 | — | [protocol/c620_can.md](protocol/c620_can.md) |
| USART1 VOFA 调参协议 | — | [protocol/vofa_pid.md](protocol/vofa_pid.md) |

## 出故障了先看这里

- **CAN 收不到反馈 / 电机不动** → [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
- **不知道怎么验证代码** → [HOW_TO_VERIFY.md](HOW_TO_VERIFY.md)

`TROUBLESHOOTING.md` 记录了已实际发生的三个故障（Bus-Off、电调 ID 不一致、
过滤器 bank 被 CAN2 污染）的判读方法和根因，遇到 CAN 不通时按顺序读。

## 当前状态摘要

- 已完成：CAN1 过滤器与启动、M3508 CAN 收发闭环、反馈超时保护、CAN 环路自检任务、
  USART3 上的 DR16 DBUS DMA 双缓冲接收与解码、底盘速度 PID、可复用位置-速度级联 PID、
  普通底盘/小陀螺互斥任务、大地坐标平移转换、键盘模式直线起步与平滑对数目标速度曲线、
  USART1 VOFA 波形输出和 PID 参数 Flash 保存。
- 未完成（属于后续任务）：实机 PID 整定、云台 Yaw 控制与多圈位置反馈、功率与温度保护、
  CAN2 云台总线接入。
- 工程已通过真实 `arm-none-eabi-gcc 14.3.1` 全量编译与链接验证，见 `CHANGELOG.md`。

## 怎么验证这份代码

见 **[HOW_TO_VERIFY.md](HOW_TO_VERIFY.md)**。三步：

1. **编译自检**（几秒）：`powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\verify.ps1`
2. **代码走查**：确认没改生成代码、字节序正确、掉线保护到位
3. **上板验证**：CAN 分析仪确认帧、调试器看变量、拔线验证保护

注意：STM32CubeIDE 的 CMake 构建当前不可用（`cube-cmake` 不在 PATH 上），
`tools/verify.ps1` 是替代方案，详见 `OPEN_QUESTIONS.md` Q8。

协议和硬件文档优先记录来源、版本、单位、字节序、时序和验证日期。无法确认的内容标为
“待确认”，不要用猜测替代。

## 新模块文档最小模板

每个新增模块至少说明：用途、文件位置、公开 API、依赖、运行上下文（任务/ISR/普通调用）、
周期或超时、线程安全约束、失败处理、构建验证命令和已知限制。

/**
  ******************************************************************************
  * @file    m3508_c620.h
  * @brief   C620 电调 + M3508 电机底盘 CAN 驱动接口。
  *          Driver interface for the C620 ESC and M3508 chassis motor.
  *
  * 模块职责 / Responsibility:
  *   - 设备注册（静态注册表，不使用动态内存）
  *     Device registration through a fixed-size static table, no heap use.
  *   - CAN 反馈帧解析（0x201 ~ 0x208）
  *     Parsing of the CAN feedback frames (0x201 ~ 0x208).
  *   - 目标电流缓存（只更新 RAM，不立刻发送）
  *     Caching of the target current value (RAM only, no immediate transmit).
  *   - 同一 CAN 总线上的聚合控制帧打包与发送（0x200 / 0x1FF）
  *     Packing and transmitting of the aggregated control frames (0x200 / 0x1FF).
  *   - 反馈超时判断与在线/离线状态
  *     Feedback timeout detection and online/offline state handling.
  *
  * 运行上下文 / Execution context:
  *   - 反馈接收入口可能由 CAN 接收中断（ISR）调用，因此中断路径只做帧过滤、
  *     字段解码和时间戳更新，不执行控制器、日志或阻塞调用。
  *     The feedback entry point may be called from the CAN RX interrupt, so the
  *     ISR path only filters frames, decodes fields and refreshes timestamps.
  *   - 控制与发送接口应在普通任务或主循环中调用。
  *     The control and transmit APIs must be called from a task or the main loop.
  *
  * 不负责的内容 / Out of scope:
  *   - CAN 外设与 GPIO 初始化、过滤器配置、外设启动（属于板级层 board_can）。
  *     CAN peripheral/GPIO init, filter setup and peripheral start (see board_can).
  *   - FreeRTOS 任务创建与调度（属于 app 层）。
  *     FreeRTOS task creation and scheduling (see the app layer).
  *   - PID、速度环、底盘运动学、功率限制、温度保护。
  *     PID, velocity loop, chassis kinematics, power limiting, thermal protection.
  ******************************************************************************
  */

#ifndef M3508_C620_H
#define M3508_C620_H

#include "stm32f4xx_hal.h"

#include <stdbool.h>
#include <stdint.h>

/* ---------------------------------------------------------------------------
 * 协议常量 / Protocol constants
 *
 * 来源 / Source:
 *   RoboMaster 开发板 C 型官方教程与 C620 电调说明书中的“标准 CAN 帧格式”。
 *   The "standard CAN frame format" chapter of the RoboMaster C-board tutorial
 *   and the C620 ESC manual.
 * ------------------------------------------------------------------------- */

/** C620 反馈帧和控制帧的固定数据长度，单位：字节。
 *  Fixed payload length of both feedback and control frames, unit: byte. */
#define C620_M3508_FRAME_DLC 8U

/** 一条 CAN 总线上按标准协议编址的最大设备数（电调 ID 1 ~ 8）。
 *  Maximum number of devices addressable by the standard protocol on one bus. */
#define C620_M3508_MAX_DEVICE_COUNT 8U

/** 合法的电调 ID 下界与上界（电调拨码 ID）。
 *  Valid ESC ID lower/upper bound (set by the ESC ID DIP switch). */
#define C620_M3508_MIN_DEVICE_ID 1U
#define C620_M3508_MAX_DEVICE_ID 8U

/** 反馈帧的公共 ID 基址：反馈 StdId = 0x200 + 电调 ID。
 *  Feedback base: feedback StdId = 0x200 + ESC ID. */
#define C620_M3508_FEEDBACK_ID_BASE 0x200U

/** 电机 ID 1 ~ 4 共用的控制帧 StdId，DATA[0:7] 依次为 4 个电机的电流。
 *  Shared control frame for ID 1 ~ 4; DATA[0:7] carries four current values. */
#define C620_M3508_CONTROL_ID_LOW 0x200U

/** 电机 ID 5 ~ 8 共用的控制帧 StdId，语义与 0x200 相同。
 *  Shared control frame for ID 5 ~ 8; same layout as 0x200. */
#define C620_M3508_CONTROL_ID_HIGH 0x1FFU

/** 反馈过滤用的 ID 匹配值。0x200 的低 3 位为 0，因此掩码 0x7F8 可以一次
 *  覆盖 0x200 ~ 0x207。
 *  ID value used by the acceptance filter. The low 3 bits of 0x200 are zero,
 *  so the mask 0x7F8 covers 0x200 ~ 0x207 in a single filter. */
#define C620_M3508_FILTER_ID 0x200U

/** 反馈过滤用的 ID 掩码，只比较 StdId 的高 8 位。
 *  ID mask used by the acceptance filter; only the upper 8 StdId bits matter. */
#define C620_M3508_FILTER_MASK 0x7F8U

/** 控制电流原始值范围。C620 说明书给出的线性范围约为 -16384 ~ 16384，
 *  对应约 ±20 A 输出电流；超出范围会被 C620 截断。
 *  Raw current command range. The C620 manual specifies an approximately linear
 *  range of -16384 ~ 16384 for about ±20 A; values outside are clipped by the ESC. */
#define C620_M3508_CURRENT_RAW_MIN (-16384)
#define C620_M3508_CURRENT_RAW_MAX (16384)

/** 默认反馈超时阈值，单位：毫秒。
 *  Default feedback timeout, unit: millisecond.
 *
 * @note 该值是“通信健康”判据，不是控制周期。控制周期由上层任务决定，
 *       底盘电流环通常使用 1 ~ 2 ms 周期持续发送。
 *       This is a link-health threshold, not the control period. The control
 *       period is owned by the upper task and is usually 1 ~ 2 ms. */
#define C620_M3508_FEEDBACK_TIMEOUT_MS 100U

/** 早期接口兼容保留的宏，未用于控制或保护。
 * @note 本次用户提供的 DATA[7] 表是错误码枚举，不是 bit0 过温位；不要用此宏测试枚举。
 *       代码只保存原字节，字段说明见 doc/protocol/c620_can.md。 */
#define C620_M3508_ERROR_OVER_TEMP_BIT 0x01U

/* ---------------------------------------------------------------------------
 * 公开类型 / Public types
 * ------------------------------------------------------------------------- */

/**
 * @brief 电机运行状态 / Motor state.
 *
 * 状态迁移 / Transitions:
 *   UNINITIALIZED --Init()--> OFFLINE --收到反馈/FEEDBACK--> ONLINE
 *   ONLINE/DISABLED --SetOutputEnabled(true)--> READY（需已有反馈 / feedback required）
 *   ONLINE/READY --Process()发现超时--> OFFLINE（同时强制清零目标电流）
 *   READY --SetOutputEnabled(false)--> DISABLED（同时清零目标电流）
 */
typedef enum {
  C620_M3508_STATE_UNINITIALIZED = 0, /* 句柄尚未初始化 / handle not initialised */
  C620_M3508_STATE_OFFLINE,           /* 超时或尚未收到反馈 / timed out or no reply yet */
  C620_M3508_STATE_ONLINE,            /* 反馈正常但输出未使能 / feedback OK, output off */
  C620_M3508_STATE_READY,             /* 反馈正常且输出已使能 / feedback OK, output armed */
  C620_M3508_STATE_DISABLED           /* 输出被上层显式关闭 / output explicitly disabled */
} C620_M3508_StateTypeDef;

/**
 * @brief 一帧反馈解码后的快照 / Decoded snapshot of one feedback frame.
 *
 * @note 反馈帧由 CAN 接收 ISR 写入；任务通过 GetFeedback() 的短临界区复制快照。
 *       The RX ISR writes feedback; GetFeedback() copies it in a short critical section.
 */
typedef struct {
  /** 转子机械角度原始值，范围 0 ~ 8191，对应 0 ~ 360 度。
   *  Raw rotor mechanical angle, 0 ~ 8191 for 0 ~ 360 degrees. */
  uint16_t angle_raw;

  /** 转子转速，单位：rpm（转/分）。
   *  Rotor speed, unit: rpm. */
  int16_t speed_rpm;

  /** 实际转矩电流原始值，单位与 -16384 ~ 16384 指令同一标度。
   *  Actual torque current in the same raw scale as the -16384 ~ 16384 command. */
  int16_t current_raw;

  /** 电调温度，单位：摄氏度。
   *  ESC temperature, unit: degree Celsius. */
  uint8_t temperature_c;

  /** 电机错误原始字节，按用户资料是枚举，见 doc/protocol/c620_can.md；不做位测试。 */
  uint8_t error_code;

  /** 最后一次成功收到反馈时的 HAL tick，单位：毫秒，仅用于诊断，不参与超时判断。
   *  HAL tick of the last valid feedback, unit: ms. Diagnostic only; the timeout
   *  decision is made from the caller-supplied timestamp in C620_M3508_Process(). */
  uint32_t last_feedback_tick;
} C620_M3508_FeedbackTypeDef;

/**
 * @brief 设备初始化参数 / Device initialisation parameters.
 *
 * @note 只有 hcan 和 motor_id 是必填项；其余字段填 0 时使用默认值。
 *       Only hcan and motor_id are mandatory; zero fields fall back to defaults.
 */
typedef struct {
  /** 该电机所接的 CAN 外设句柄，例如 &hcan1；同一句柄代表同一条物理总线。
   *  CAN instance the motor is wired to, e.g. &hcan1. One handle == one bus. */
  CAN_HandleTypeDef *hcan;

  /** 电调 ID，取值 1 ~ 8，必须与电调拨码一致，否则收不到反馈。
   *  ESC ID, 1 ~ 8, must match the ESC DIP switch or no feedback arrives. */
  uint8_t motor_id;

  /** 反馈超时阈值，单位：毫秒；传 0 时使用 C620_M3508_FEEDBACK_TIMEOUT_MS。
   *  Feedback timeout in ms; 0 selects C620_M3508_FEEDBACK_TIMEOUT_MS. */
  uint32_t feedback_timeout_ms;
} C620_M3508_ConfigTypeDef;

/**
 * @brief 单个电机实例的运行数据 / Runtime data of one motor instance.
 *
 * @note 该结构体由调用方分配。驱动内部只保存它的地址，不复制数据，因此句柄
 *       必须具备静态或任务级生命周期，绝不能指向已经返回的函数栈帧。
 *       The caller owns this structure. The driver stores its address in the
 *       registry, so it must live in static or task-scope storage and must never
 *       point at a frame that has already returned.
 */
typedef struct {
  C620_M3508_ConfigTypeDef config;      /* 初始化时拷贝的配置副本 / copied config */
  C620_M3508_FeedbackTypeDef feedback;  /* 最近一帧反馈快照 / latest feedback snapshot */
  int16_t target_current_raw;           /* 待发送的目标电流 / pending target current */
  volatile uint32_t last_feedback_tick; /* ISR 写、任务读的毫秒时间戳 / ISR-written ms tick */
  volatile C620_M3508_StateTypeDef state; /* ISR 与任务共享状态 / ISR/task shared state */
  bool initialized;                     /* 句柄是否已完成初始化 / handle initialised */
  volatile bool feedback_received;      /* ISR 写、任务读的反馈证据 / ISR-written feedback evidence */
  volatile bool output_enabled;         /* ISR 与任务共享输出使能 / shared output arming */
  bool requires_rearm;                  /* 离线后是否必须先重新使能 / needs re-arm after loss */
} C620_M3508_HandleTypeDef;

/* ---------------------------------------------------------------------------
 * 公开接口 / Public API
 * ------------------------------------------------------------------------- */

/**
 * @brief  注册并初始化一个 C620/M3508 电机实例。
 *         Register and initialise one C620/M3508 motor instance.
 * @param  hmotor 调用方提供的句柄存储，不能为 NULL，且生命周期应覆盖整个运行期。
 *                Caller-provided handle storage; not NULL and long-lived.
 * @param  config CAN 句柄、电调 ID 和超时参数。
 *                CAN handle, ESC ID and timeout parameters.
 * @retval true   初始化成功并已进入静态注册表。
 *                Initialised and inserted into the static registry.
 * @retval false  参数非法、ID 越界、同一总线上 ID 重复或注册表已满。
 *                Invalid argument, out-of-range/duplicate ID, or registry full.
 *
 * @note   本函数不启动 CAN 外设、不配置过滤器；请先调用 BoardCan_Init()。
 *         This function neither starts CAN nor configures filters; call
 *         BoardCan_Init() first.
 * @note   可在 osKernelStart() 之前调用，也可在任务中调用；不阻塞。
 *         Safe before osKernelStart() and from a task; it never blocks.
 */
bool C620_M3508_Init(C620_M3508_HandleTypeDef *hmotor,
                     const C620_M3508_ConfigTypeDef *config);

/**
 * @brief  注销一个已注册实例并清零其运行状态。
 *         Unregister an instance and clear its runtime state.
 * @param  hmotor 已初始化的设备句柄 / an initialised handle.
 * @retval true   注销成功 / unregistered successfully.
 * @retval false  参数为空或句柄未注册 / NULL or handle was not registered.
 *
 * @note   注销后该电机不再被 C620_M3508_SendAll() 计入聚合帧。
 *         After unregistering, the motor is excluded from the aggregate frames.
 */
bool C620_M3508_DeInit(C620_M3508_HandleTypeDef *hmotor);

/**
 * @brief  缓存目标电流原始值，不发帧。
 *         Cache the target current raw value without transmitting.
 * @param  hmotor 电机句柄 / motor handle.
 * @param  current_raw 有符号电流原始值，超出 ±16384 时饱和到边界。
 *                     Signed raw current, saturated to ±16384.
 * @retval true   值已写入目标缓存 / value stored.
 * @retval false  参数非法或设备未初始化 / invalid handle or not initialised.
 *
 * @note   适合在控制任务中每周期调用；真正发送由 C620_M3508_SendAll() 完成。
 *         Intended to be called every control period; the actual transmission is
 *         performed by C620_M3508_SendAll().
 */
bool C620_M3508_SetCurrent(C620_M3508_HandleTypeDef *hmotor,
                           int16_t current_raw);

/**
 * @brief  使能或关闭本电机的电流输出。
 *         Arm or disarm the current output of this motor.
 * @param  hmotor 电机句柄 / motor handle.
 * @param  enabled true 允许输出目标电流；false 立即清零目标电流。
 *                 true arms the output; false zeroes the target immediately.
 * @retval true   状态已更新 / state updated.
 * @retval false  参数非法或设备未初始化 / invalid handle or not initialised.
 *
 * @note   关闭时只修改目标缓存，聚合帧中该电机的两个字节会被强制写 0，
 *         因此即使 CAN 仍在线，电机也不会再收到非零指令。
 *         Disarming only changes RAM; the aggregate frame writes zeros in this
 *         motor's two bytes, so no non-zero command can reach it.
 */
bool C620_M3508_SetOutputEnabled(C620_M3508_HandleTypeDef *hmotor,
                                 bool enabled);

/**
 * @brief  更新在线/离线状态并按需重新锁定输出。
 *         Refresh the link state and re-lock the output when needed.
 * @param  hmotor 电机句柄 / motor handle.
 * @param  now_tick 当前毫秒时间基准，应与 C620_M3508_SendAll() 使用同一个时钟。
 *                  Current millisecond time base; must be the same clock as the
 *                  one used by C620_M3508_SendAll(). Use HAL_GetTick().
 * @retval true   状态检查完成 / state check completed.
 * @retval false  参数非法或设备未初始化 / invalid handle or not initialised.
 *
 * @note   检测到超时后会清零目标电流、关闭输出并置 requires_rearm，使通信恢复
 *         后不会突然恢复到掉线前的电流。
 *         On timeout the target is zeroed, the output is disarmed and
 *         requires_rearm is set, so a link recovery cannot resume the old current.
 * @note   必须在 C620_M3508_SendAll() 之前调用，否则本周期仍会发出旧目标值。
 *         Call it before C620_M3508_SendAll(), otherwise the stale target is sent
 *         in the same period.
 */
bool C620_M3508_Process(C620_M3508_HandleTypeDef *hmotor, uint32_t now_tick);

/**
 * @brief  发送一条 CAN 总线上所有已注册电机的聚合控制帧。
 *         Transmit the aggregate control frames of one CAN bus.
 * @param  hcan 目标 CAN 总线句柄 / target CAN bus handle.
 * @retval true   发送成功，或该总线上没有注册设备（无需发送）。
 *                Transmission succeeded, or no device is registered on that bus.
 * @retval false  hcan 为 NULL、发送邮箱已满或 HAL 发送失败。
 *                NULL handle, no free Tx mailbox, or HAL transmit failure.
 *
 * @note   只聚合同一个 hcan 的电机：ID 1 ~ 4 合成 0x200，ID 5 ~ 8 合成 0x1FF。
 *         未使能输出的电机在帧中占两个字节的 0。
 *         Only motors on the same hcan are aggregated: ID 1 ~ 4 into 0x200 and
 *         ID 5 ~ 8 into 0x1FF. Disarmed motors contribute two zero bytes.
 * @note   必须由固定周期的任务调用；C620 的电流指令是周期刷新量，不是寄存器。
 *         Must be called from a fixed-period task; a C620 current command is a
 *         periodically refreshed quantity, not a latched register.
 */
bool C620_M3508_SendAll(CAN_HandleTypeDef *hcan);

/**
 * @brief  解析一帧已经从 HAL 接收 FIFO 取出的数据。
 *         Parse one frame already read out of the HAL RX FIFO.
 * @param  hcan CAN 外设句柄 / CAN instance handle.
 * @param  rx_header HAL 接收帧头 / HAL receive header.
 * @param  data 8 字节 CAN 数据区 / the 8-byte CAN payload.
 * @retval true   该帧属于已注册设备并已刷新反馈。
 *                The frame belongs to a registered device and was applied.
 * @retval false  参数为空、帧格式不符或该 ID 未注册。
 *                NULL argument, wrong frame format, or unknown device ID.
 *
 * @note   可从 HAL_CAN_RxFifo0MsgPendingCallback() 调用；此路径运行在中断中，
 *         不得阻塞、不得打印、不得调用普通 FreeRTOS API。
 *         Callable from HAL_CAN_RxFifo0MsgPendingCallback(); runs in an ISR, so it
 *         must not block, print, or call non-FromISR FreeRTOS APIs.
 */
bool C620_M3508_HandleRxMessage(CAN_HandleTypeDef *hcan,
                                const CAN_RxHeaderTypeDef *rx_header,
                                const uint8_t data[C620_M3508_FRAME_DLC]);

/**
 * @brief  从硬件接收 FIFO 取一帧并交给本驱动解析。
 *         Fetch one frame from the hardware RX FIFO and parse it.
 * @param  hcan CAN 外设句柄 / CAN instance handle.
 * @param  rx_fifo 接收 FIFO 编号，例如 CAN_RX_FIFO0 / RX FIFO index.
 * @retval true   取帧成功且属于本驱动设备 / fetched and applied.
 * @retval false  HAL 取帧失败或帧不匹配 / HAL error or frame not recognised.
 */
bool C620_M3508_RxFifoCallback(CAN_HandleTypeDef *hcan, uint32_t rx_fifo);

/**
 * @brief  复制一份反馈快照 / Copy a feedback snapshot.
 * @param  hmotor 电机句柄 / motor handle.
 * @param  feedback 输出结构体，不能为 NULL / output structure, not NULL.
 * @retval true   复制成功 / copied.
 * @retval false  参数非法或设备未初始化 / invalid handle or not initialised.
 */
bool C620_M3508_GetFeedback(const C620_M3508_HandleTypeDef *hmotor,
                            C620_M3508_FeedbackTypeDef *feedback);

/**
 * @brief  查询电机通信是否在线（不区分输出是否使能）。
 *         Report whether the CAN link is alive (regardless of output arming).
 * @param  hmotor 电机句柄 / motor handle.
 * @retval true   已收到过反馈且最近一次 Process() 未判定超时。
 *                Feedback was received and the last Process() did not time out.
 * @retval false  句柄为空、未初始化或当前为离线状态。
 *                NULL, not initialised, or currently offline.
 */
bool C620_M3508_IsOnline(const C620_M3508_HandleTypeDef *hmotor);

/**
 * @brief  查询掉线后是否必须先重新使能输出。
 *         Report whether the output must be re-armed after a link loss.
 * @param  hmotor 电机句柄 / motor handle.
 * @retval true   上次超时后尚未重新使能，上层应先重新使能再下发电流。
 *                A timeout happened and the output has not been re-armed since.
 * @retval false  不需要重新使能，或句柄无效。
 *                No re-arm needed, or the handle is invalid.
 *
 * @note   C620_M3508_SetOutputEnabled(hmotor, true) 会清除该标志。
 *         C620_M3508_SetOutputEnabled(hmotor, true) clears this flag.
 */
bool C620_M3508_RequiresRearm(const C620_M3508_HandleTypeDef *hmotor);

/**
 * @brief  查询当前状态机状态 / Read the current state.
 * @param  hmotor 电机句柄 / motor handle.
 * @retval 当前状态；句柄为空时返回 C620_M3508_STATE_UNINITIALIZED。
 *         Current state; returns C620_M3508_STATE_UNINITIALIZED for a NULL handle.
 */
C620_M3508_StateTypeDef
C620_M3508_GetState(const C620_M3508_HandleTypeDef *hmotor);

#endif /* M3508_C620_H */

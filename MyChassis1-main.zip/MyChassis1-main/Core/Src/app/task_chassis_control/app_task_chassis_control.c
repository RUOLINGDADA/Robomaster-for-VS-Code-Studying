/**
  ******************************************************************************
  * @file    app_task_chassis_control.c
  * @brief   DR16 底盘四轮控制任务。
  *
  * 本任务只在 switch_s1=2 时运行：遥控目标转速与 CAN 转子速度作比较，速度 PID
  * 输出实际限幅约 ±6.0 A 内的电流，理论 ±3.5 A 仅作参考。反馈与输出共用安装方向表；
  * 不执行位置环，不改变测试任务。
  ******************************************************************************
  */

#include "app/chassis_control/chassis_control.h"
#include "app/chassis_motors/chassis_motors.h"
#include "app/task_chassis_control/app_task_chassis_control.h"
#include "app/task_chassis_mode_manager/app_task_chassis_mode_manager.h"
#include "bsp/board_can/board_can.h"
#include "bsp/dr16_dbus/dr16_dbus.h"

#include "FreeRTOS.h"
#include "task.h"

#include "stm32f4xx_hal.h"

#include <stdbool.h>
#include <stdint.h>

/** 底盘控制任务控制周期，单位：毫秒。 */
#define CHASSIS_TASK_PERIOD_MS 2U

/** PID 采样间隔超过此值视为挂起或异常停顿，单位 ms；清历史并发零电流。 */
#define CHASSIS_TASK_PID_GAP_MS 100U

/** 初始化失败后的调试等待周期，单位 ms；任务保留且不输出电流。 */
#define CHASSIS_TASK_INIT_RETRY_MS 1000U

static bool ChassisTask_IsModeSelected(DR16_Dbus_DataTypeDef *remote_data) {
  if (remote_data == NULL || !DR16_Dbus_GetData(remote_data)) {
    return false;
  }
  if (!remote_data->online) {
    return false;
  }
  return ChassisModeManager_GetMode() == CHASSIS_MODE_CONTROL;
}

/**
  * @brief  根据目标转速和在线反馈计算电流，再写入四个电机。
  * @param  dt_s 实际控制间隔，单位秒。
  * @retval 无。
  * @note   离线电机强制关闭并复位 PID，防止旧积分影响重连。
  */
static void ChassisTask_ApplyTargetCurrents(float dt_s) {
  for (uint32_t i = 0U; i < CHASSIS_MOTORS_COUNT; i++) {
    float feedback_rpm = 0.0f;
    const bool online = ChassisMotors_GetSpeedRpm(i, &feedback_rpm);
    int16_t target_current = 0;
    if (online) {
      target_current = ChassisControl_CalcCurrent(i, feedback_rpm, dt_s);
    } else {
      ChassisControl_ResetMotor(i);
    }
    (void)C620_M3508_SetOutputEnabled(&g_chassis_motors[i], online);
    (void)ChassisMotors_SetCurrent(i, target_current);
  }
}

/**
  * @brief  底盘遥控任务入口。
  * @param  argument FreeRTOS 任务参数，当前未使用。
  * @retval 无；任务入口不会返回。
  * @note   任务启动后永久等待模式管理任务唤醒，离开 switch_s1=2 后清零并再次等待。
  */
void task_chassis_control_entry(void *argument) {
  (void)argument;
  if (!ChassisControl_Init()) {
    for (;;) {
      vTaskDelay(pdMS_TO_TICKS(CHASSIS_TASK_INIT_RETRY_MS));
    }
  }
  for (;;) {
    vTaskSuspend(NULL);

    ChassisControl_Clear();
    ChassisControl_SetCurrentLimitsRaw(
        CHASSIS_CONTROL_THEORETICAL_CURRENT_RAW_MAX,
        CHASSIS_CONTROL_ACTUAL_CURRENT_RAW_MAX);
    TickType_t last_wake_tick = xTaskGetTickCount();
    uint32_t previous_ms = HAL_GetTick() - CHASSIS_TASK_PERIOD_MS;
    for (;;) {
      DR16_Dbus_DataTypeDef remote_data = {0};
      if (!ChassisTask_IsModeSelected(&remote_data)) {
        ChassisControl_Clear();
        ChassisControl_SetCurrentLimitsRaw(
            CHASSIS_CONTROL_THEORETICAL_CURRENT_RAW_MAX,
            CHASSIS_CONTROL_ACTUAL_CURRENT_RAW_MAX);
        ChassisMotors_StopAll();
        (void)ChassisMotors_Send();
        break;
      }

      if (BoardCan_RecoverIfBusOff()) {
        ChassisControl_Clear();
        ChassisControl_SetCurrentLimitsRaw(
            CHASSIS_CONTROL_THEORETICAL_CURRENT_RAW_MAX,
            CHASSIS_CONTROL_ACTUAL_CURRENT_RAW_MAX);
        ChassisMotors_StopAll();
        (void)ChassisMotors_Send();
        previous_ms = HAL_GetTick();
        vTaskDelayUntil(&last_wake_tick,
                        pdMS_TO_TICKS(CHASSIS_TASK_PERIOD_MS));
        continue;
      }

      const uint32_t now_ms = HAL_GetTick();
      /* 无符号差处理 tick 回绕；恢复运行不把长时间挂起当作正常积分周期。 */
      const uint32_t elapsed_ms = now_ms - previous_ms;
      previous_ms = now_ms;
      if (elapsed_ms == 0U || elapsed_ms > CHASSIS_TASK_PID_GAP_MS) {
        ChassisControl_Clear();
        ChassisMotors_StopAll();
        (void)ChassisMotors_Send();
        last_wake_tick = xTaskGetTickCount();
        vTaskDelayUntil(&last_wake_tick, pdMS_TO_TICKS(CHASSIS_TASK_PERIOD_MS));
        continue;
      }
      ChassisMotors_Process(now_ms);
      (void)ChassisControl_ApplyPendingSpeedPidGains();
      if (ChassisModeManager_IsKeyboardActive() &&
          ChassisModeManager_GetMode() == CHASSIS_MODE_CONTROL) {
        ChassisControl_UpdateKeyboard(&remote_data,
                                      (float)elapsed_ms * 0.001f);
      } else {
        ChassisControl_Update(&remote_data);
      }
      ChassisTask_ApplyTargetCurrents((float)elapsed_ms * 0.001f);
      (void)ChassisMotors_Send();

      /* 恢复被挂起的任务后重新设定节拍，不连续补发过期控制帧。 */
      if (elapsed_ms > CHASSIS_TASK_PERIOD_MS * 2U) {
        last_wake_tick = xTaskGetTickCount();
      }
      vTaskDelayUntil(&last_wake_tick, pdMS_TO_TICKS(CHASSIS_TASK_PERIOD_MS));
    }

    ChassisControl_Clear();
    ChassisMotors_StopAll();
    (void)ChassisMotors_Send();
  }
}

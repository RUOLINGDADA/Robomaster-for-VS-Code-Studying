/**
 * PID 主机数值验证：调用真实 PID、底盘混控和电机方向代码。
 * 驱动替身只替代 CAN/HAL；验证数值和闭环仿真，不代表电机已实机整定。
 */
#include "app/pid_controller/pid_controller.h"
#include "app/chassis_control/chassis_control.h"
#include "app/chassis_motors/chassis_motors.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

CAN_HandleTypeDef hcan1;
bool C620_M3508_Init(C620_M3508_HandleTypeDef *motor,
                     const C620_M3508_ConfigTypeDef *config) {
  motor->config = *config;
  motor->online = true;
  return true;
}
bool C620_M3508_Process(C620_M3508_HandleTypeDef *motor, uint32_t now_ms) {
  (void)motor; (void)now_ms; return true;
}
bool C620_M3508_SetOutputEnabled(C620_M3508_HandleTypeDef *motor, bool enabled) {
  if (!enabled) { motor->target_current_raw = 0; }
  return true;
}
bool C620_M3508_SetCurrent(C620_M3508_HandleTypeDef *motor, int16_t current_raw) {
  motor->target_current_raw = current_raw; return true;
}
bool C620_M3508_IsOnline(const C620_M3508_HandleTypeDef *motor) {
  return motor->online;
}
bool C620_M3508_GetFeedback(const C620_M3508_HandleTypeDef *motor,
                           C620_M3508_FeedbackTypeDef *feedback) {
  *feedback = motor->feedback; return true;
}
bool C620_M3508_SendAll(CAN_HandleTypeDef *hcan) { (void)hcan; return true; }
bool BoardCan_PollRxFifo0(void) { return true; }

static void Near(float actual, float expected) {
  if (fabsf(actual - expected) >= 0.001f) {
    fprintf(stderr, "actual=%g expected=%g\n", (double)actual, (double)expected);
  }
  assert(fabsf(actual - expected) < 0.001f);
}

static void NearSpeed(float actual, float expected) {
  assert(fabsf(actual - expected) < 0.1f);
}

static void TestPidMath(void) {
  Pid_ControllerTypeDef pid;
  Pid_ControllerConfigTypeDef config = {
      .ki = 2.0f, .output_limit = 10000.0f, .integral_limit = 1000.0f,
      .integral_error_scale = 0.01f};
  assert(Pid_Controller_Init(&pid, &config));
  Near(Pid_Controller_Calc(&pid, 100.0f, 0.0f, 0.1f), 10.0f);
  /* e=100→200，梯形面积15，Ki=2，当前倒数权重1/3，积分再增加10。 */
  Near(Pid_Controller_Calc(&pid, 200.0f, 0.0f, 0.1f), 20.0f);

  config.integral_limit = 5.0f;
  assert(Pid_Controller_Init(&pid, &config));
  Near(Pid_Controller_Calc(&pid, 100.0f, 0.0f, 1.0f), 5.0f);
  config.kp = 10.0f;
  config.output_limit = 20.0f;
  assert(Pid_Controller_Init(&pid, &config));
  for (int i = 0; i < 100; i++) {
    Near(Pid_Controller_Calc(&pid, 100.0f, 0.0f, 0.1f), 20.0f);
  }
  Near(pid.integral, 0.0f); /* 饱和期不积累同向积分。 */
  /* 梯形积分仍包含上一帧误差的半段面积，且受5原始值积分上限约束。 */
  Near(Pid_Controller_Calc(&pid, 0.0f, 0.0f, 0.1f), 5.0f);

  config = (Pid_ControllerConfigTypeDef){.kd = 1.0f, .output_limit = 10000.0f,
                                       .derivative_cutoff_hz = 10.0f};
  assert(Pid_Controller_Init(&pid, &config));
  Near(Pid_Controller_Calc(&pid, 0.0f, 10.0f, 0.01f), 0.0f);
  Near(Pid_Controller_Calc(&pid, 1000.0f, 10.0f, 0.01f), 0.0f);
  const float filtered = Pid_Controller_Calc(&pid, 1000.0f, 20.0f, 0.01f);
  assert(filtered < 0.0f && filtered > -1000.0f);
  const float decay = Pid_Controller_Calc(&pid, 1000.0f, 20.0f, 0.01f);
  assert(decay < 0.0f && fabsf(decay) < fabsf(filtered));
  Near(Pid_Controller_Calc(&pid, 0.0f, 0.0f, 0.0f), 0.0f);
  Near(Pid_Controller_Calc(&pid, NAN, 0.0f, 0.01f), 0.0f);
  Pid_Controller_Reset(&pid);
  Near(Pid_Controller_Calc(&pid, 0.0f, 1234.0f, 0.01f), 0.0f);
  config.integral_error_scale = -1.0f;
  assert(!Pid_Controller_Init(&pid, &config));
}

static void TestCascade(void) {
  Pid_CascadeControllerTypeDef cascade;
  const Pid_ControllerConfigTypeDef outer = {.kp = 10.0f, .output_limit = 50.0f};
  const Pid_ControllerConfigTypeDef inner = {.kp = 4.0f, .output_limit = 300.0f};
  assert(Pid_CascadeController_Init(&cascade, &outer, &inner));
  Near(Pid_CascadeController_Calc(&cascade, 100.0f, 0.0f, 20.0f, 0.002f), 120.0f);
  Near(Pid_CascadeController_Calc(&cascade, 0.0f, 100.0f, 100.0f, 0.002f), -300.0f);
  Near(Pid_CascadeController_Calc(&cascade, 0.0f, 0.0f, NAN, 0.002f), 0.0f);
  Pid_CascadeController_Reset(&cascade);
  assert(!cascade.position_pid.initialized && !cascade.speed_pid.initialized);
}

static void TestChassis(void) {
  assert(ChassisMotors_Init() && ChassisControl_Init());
  DR16_Dbus_DataTypeDef remote = {.switch_s1 = DR16_DBUS_SWITCH_DOWN, .online = true};
  const float maximum = CHASSIS_CONTROL_SPEED_RPM_MAX;
  remote.channel[3] = 660;
  ChassisControl_Update(&remote);
  for (uint32_t i = 0; i < 4; i++) {
    Near(g_chassis_target_speed_rpm[i], maximum);
    assert(ChassisControl_CalcCurrent(i, 0.0f, 0.002f) ==
           CHASSIS_CONTROL_ACTUAL_CURRENT_RAW_MAX);
  }
  ChassisControl_Clear();
  remote.channel[3] = 0; remote.channel[2] = 660;
  ChassisControl_Update(&remote);
  Near(g_chassis_target_speed_rpm[0], -maximum);
  Near(g_chassis_target_speed_rpm[1], maximum);
  Near(g_chassis_target_speed_rpm[2], -maximum);
  Near(g_chassis_target_speed_rpm[3], maximum);
  remote.channel[2] = 0; remote.channel[0] = 660;
  ChassisControl_Update(&remote);
  Near(g_chassis_target_speed_rpm[0], -maximum);
  Near(g_chassis_target_speed_rpm[1], maximum);
  Near(g_chassis_target_speed_rpm[2], maximum);
  Near(g_chassis_target_speed_rpm[3], -maximum);
  remote.channel[0] = 0; remote.channel[3] = 29;
  ChassisControl_Update(&remote);
  for (uint32_t i = 0; i < 4; i++) { Near(g_chassis_target_speed_rpm[i], 0.0f); }

  const int signs[4] = {-1, 1, 1, -1}; /* 必须保留用户实测方向。 */
  for (uint32_t i = 0; i < 4; i++) {
    assert(g_chassis_motors[i].config.motor_id == i + 1);
    assert(ChassisMotors_SetCurrent(i, 100));
    assert(g_chassis_motors[i].target_current_raw == signs[i] * 100);
    g_chassis_motors[i].feedback.speed_rpm = (int16_t)(signs[i] * 1000);
    float measured = 0.0f;
    assert(ChassisMotors_GetSpeedRpm(i, &measured));
    Near(measured, 1000.0f);
  }
  g_chassis_motors[0].online = false;
  float measured = 123.0f;
  assert(!ChassisMotors_GetSpeedRpm(0, &measured)); Near(measured, 0.0f);
  assert(!ChassisMotors_SetCurrent(4, 100));
  ChassisControl_ResetMotor(0);
  Near(g_chassis_target_current_raw[0], 0.0f);
  remote.online = false;
  ChassisControl_Update(&remote);
  for (uint32_t i = 0; i < 4; i++) {
    Near(g_chassis_target_speed_rpm[i], 0.0f);
    Near(g_chassis_target_current_raw[i], 0.0f);
  }

  /* 简单一阶负载模型：只验证闭环能减小误差、反向和限流，不用于预测实机参数。 */
  assert(ChassisControl_Init());
  g_chassis_target_speed_rpm[0] = 1000.0f;
  float speed = 0.0f;
  for (int i = 0; i < 4000; i++) {
    const int16_t current = ChassisControl_CalcCurrent(0, speed, 0.002f);
    assert(abs(current) <= CHASSIS_CONTROL_ACTUAL_CURRENT_RAW_MAX);
    speed += (2.0f * current - speed) * (0.002f / 0.03f);
  }
  assert(fabsf(speed - 1000.0f) < 30.0f);
  g_chassis_target_speed_rpm[0] = -1000.0f;
  /* 反向时还需消除原正向积分；倒数积分允许缓慢收敛，仿真观察16 s。 */
  for (int i = 0; i < 8000; i++) {
    const int16_t current = ChassisControl_CalcCurrent(0, speed, 0.002f);
    assert(abs(current) <= CHASSIS_CONTROL_ACTUAL_CURRENT_RAW_MAX);
    speed += (2.0f * current - speed) * (0.002f / 0.03f);
  }
  assert(fabsf(speed + 1000.0f) < 30.0f);
  ChassisControl_Clear();
  assert(ChassisControl_CalcCurrent(0, 0.0f, 0.002f) == 0);
}

static void TestSpinMix(void) {
  assert(ChassisControl_Init());
  DR16_Dbus_DataTypeDef remote = {
      .switch_s1 = DR16_DBUS_SWITCH_DOWN, .online = true};
  const float maximum = CHASSIS_CONTROL_SPEED_RPM_MAX;

  remote.channel[3] = 660;
  ChassisControl_UpdateSpin(&remote, 0.0f, 0.0f);
  for (uint32_t i = 0U; i < 4U; i++) {
    Near(g_chassis_spin_target_speed_rpm[i], maximum);
  }

  /* 右转90度后，大地前进应变成车体左移。 */
  ChassisControl_UpdateSpin(&remote, 1.57079632679f, 0.0f);
  Near(g_chassis_spin_target_speed_rpm[0], maximum);
  Near(g_chassis_spin_target_speed_rpm[1], -maximum);
  Near(g_chassis_spin_target_speed_rpm[2], maximum);
  Near(g_chassis_spin_target_speed_rpm[3], -maximum);

  remote.channel[3] = 0;
  ChassisControl_UpdateSpin(&remote, 0.0f, CHASSIS_SPIN_TARGET_OMEGA_RAD_S);
  assert(g_chassis_spin_target_speed_rpm[0] < 0.0f);
  assert(g_chassis_spin_target_speed_rpm[1] > 0.0f);
  assert(g_chassis_spin_target_speed_rpm[2] > 0.0f);
  assert(g_chassis_spin_target_speed_rpm[3] < 0.0f);

  assert(g_chassis_theoretical_current_limit_raw ==
         CHASSIS_CONTROL_THEORETICAL_CURRENT_RAW_MAX);
  assert(g_chassis_actual_current_limit_raw ==
         CHASSIS_CONTROL_ACTUAL_CURRENT_RAW_MAX);
  ChassisControl_SetCurrentLimitsRaw(
      CHASSIS_SPIN_THEORETICAL_CURRENT_RAW_MAX,
      CHASSIS_SPIN_ACTUAL_CURRENT_RAW_MAX);
  assert(g_chassis_theoretical_current_limit_raw ==
         CHASSIS_SPIN_THEORETICAL_CURRENT_RAW_MAX);
  assert(g_chassis_actual_current_limit_raw ==
         CHASSIS_SPIN_ACTUAL_CURRENT_RAW_MAX);
  g_chassis_target_speed_rpm[0] = maximum;
  assert(ChassisControl_CalcCurrent(0, 0.0f, 0.002f) ==
         CHASSIS_SPIN_ACTUAL_CURRENT_RAW_MAX);
  ChassisControl_Clear();
  assert(g_chassis_theoretical_current_limit_raw ==
         CHASSIS_CONTROL_THEORETICAL_CURRENT_RAW_MAX);
  assert(g_chassis_actual_current_limit_raw ==
         CHASSIS_CONTROL_ACTUAL_CURRENT_RAW_MAX);
  g_chassis_target_speed_rpm[0] = maximum;
  assert(ChassisControl_CalcCurrent(0, 0.0f, 0.002f) ==
         CHASSIS_CONTROL_ACTUAL_CURRENT_RAW_MAX);
}

static void KeyboardAdvance(DR16_Dbus_DataTypeDef *remote, int samples) {
  for (int i = 0; i < samples; i++) {
    ChassisControl_UpdateKeyboard(remote, 0.002f);
  }
}

static void TestKeyboardMix(void) {
  assert(ChassisControl_Init());
  assert(DR16_DBUS_KEY_SHIFT == (1U << 4U));
  assert(DR16_DBUS_KEY_CTRL == (1U << 5U));
  assert(DR16_DBUS_KEY_Q == (1U << 6U));
  assert(DR16_DBUS_KEY_E == (1U << 7U));
  DR16_Dbus_DataTypeDef remote = {.online = true};
  const float maximum = CHASSIS_CONTROL_SPEED_RPM_MAX;

  remote.keyboard = DR16_DBUS_KEY_W;
  ChassisControl_UpdateKeyboard(&remote, 0.002f);
  assert(g_chassis_keyboard_ramped_vy_rpm > 0.0f &&
         g_chassis_keyboard_ramped_vy_rpm < maximum);
  KeyboardAdvance(&remote, 99);
  NearSpeed(g_chassis_keyboard_ramped_vy_rpm, maximum / 3.0f);
  KeyboardAdvance(&remote, 200);
  /* 对数后段先快后慢，0.60 s 已超过旧曲线的2/3节点。 */
  assert(g_chassis_keyboard_ramped_vy_rpm > maximum * 0.75f &&
         g_chassis_keyboard_ramped_vy_rpm < maximum * 0.90f);
  KeyboardAdvance(&remote, 200);
  NearSpeed(g_chassis_keyboard_ramped_vy_rpm, maximum);
  for (uint32_t i = 0U; i < 4U; i++) { Near(g_chassis_target_speed_rpm[i], maximum); }

  remote.keyboard = DR16_DBUS_KEY_D;
  KeyboardAdvance(&remote, 500);
  Near(g_chassis_target_speed_rpm[0], -maximum);
  Near(g_chassis_target_speed_rpm[1], maximum);
  Near(g_chassis_target_speed_rpm[2], -maximum);
  Near(g_chassis_target_speed_rpm[3], maximum);

  remote.keyboard = DR16_DBUS_KEY_W | DR16_DBUS_KEY_D;
  ChassisControl_Clear();
  KeyboardAdvance(&remote, 500);
  Near(g_chassis_target_speed_rpm[0], 0.0f);
  Near(g_chassis_target_speed_rpm[1], maximum);
  Near(g_chassis_target_speed_rpm[2], 0.0f);
  Near(g_chassis_target_speed_rpm[3], maximum);

  remote.keyboard = DR16_DBUS_KEY_Q;
  ChassisControl_Clear();
  KeyboardAdvance(&remote, 500);
  Near(g_chassis_target_speed_rpm[0], maximum);
  Near(g_chassis_target_speed_rpm[1], -maximum);
  Near(g_chassis_target_speed_rpm[2], -maximum);
  Near(g_chassis_target_speed_rpm[3], maximum);

  remote.keyboard = DR16_DBUS_KEY_E;
  ChassisControl_Clear();
  KeyboardAdvance(&remote, 500);
  Near(g_chassis_target_speed_rpm[0], -maximum);
  Near(g_chassis_target_speed_rpm[1], maximum);
  Near(g_chassis_target_speed_rpm[2], maximum);
  Near(g_chassis_target_speed_rpm[3], -maximum);

  remote.keyboard = DR16_DBUS_KEY_W | DR16_DBUS_KEY_S |
                    DR16_DBUS_KEY_Q | DR16_DBUS_KEY_E;
  ChassisControl_Clear();
  KeyboardAdvance(&remote, 500);
  for (uint32_t i = 0U; i < 4U; i++) { Near(g_chassis_target_speed_rpm[i], 0.0f); }

  remote.keyboard = 0U;
  KeyboardAdvance(&remote, 1);
  for (uint32_t i = 0U; i < 4U; i++) { Near(g_chassis_target_speed_rpm[i], 0.0f); }

  /* 松键立即清零；反向先经过零速，再进入反方向。 */
  remote.keyboard = DR16_DBUS_KEY_W;
  ChassisControl_Clear();
  KeyboardAdvance(&remote, 500);
  remote.keyboard = DR16_DBUS_KEY_S;
  ChassisControl_UpdateKeyboard(&remote, 0.002f);
  assert(g_chassis_keyboard_ramped_vy_rpm > 0.0f);
  KeyboardAdvance(&remote, 500);
  Near(g_chassis_keyboard_ramped_vy_rpm, 0.0f);
  ChassisControl_UpdateKeyboard(&remote, 0.002f);
  assert(g_chassis_keyboard_ramped_vy_rpm < 0.0f);

  /* 松键后重新按下，从零速重新启动曲线。 */
  ChassisControl_Clear();
  remote.keyboard = DR16_DBUS_KEY_W;
  KeyboardAdvance(&remote, 100);
  remote.keyboard = 0U;
  ChassisControl_UpdateKeyboard(&remote, 0.002f);
  Near(g_chassis_keyboard_ramped_vy_rpm, 0.0f);
  remote.keyboard = DR16_DBUS_KEY_W;
  ChassisControl_UpdateKeyboard(&remote, 0.002f);
  assert(g_chassis_keyboard_ramped_vy_rpm > 0.0f &&
         g_chassis_keyboard_ramped_vy_rpm < maximum);
}

/** 验证实际接口生成的曲线：直线起步、斜率连续、对数后段放缓及零斜率收尾。 */
static void TestKeyboardLogRamp(void) {
  const uint16_t keys[] = {DR16_DBUS_KEY_W, DR16_DBUS_KEY_S,
                          DR16_DBUS_KEY_D, DR16_DBUS_KEY_A,
                          DR16_DBUS_KEY_E, DR16_DBUS_KEY_Q};
  const float maximum = CHASSIS_CONTROL_SPEED_RPM_MAX;
  for (uint32_t key = 0U; key < 6U; key++) {
    DR16_Dbus_DataTypeDef remote = {.online = true, .keyboard = keys[key]};
    float previous = 0.0f;
    float previous_step = maximum;
    float linear_step = 0.0f;
    const float sign = key % 2U == 0U ? 1.0f : -1.0f;
    ChassisControl_Clear();
    for (uint32_t sample = 1U; sample <= 550U; sample++) {
      ChassisControl_UpdateKeyboard(&remote, 0.002f);
      const float value = sign * (key < 2U ? g_chassis_keyboard_ramped_vy_rpm :
          key < 4U ? g_chassis_keyboard_ramped_vx_rpm :
                     g_chassis_keyboard_ramped_wz_rpm);
      const float step = value - previous;
      assert(value >= previous - 0.01f && value <= maximum);
      if (sample <= 100U) {
        NearSpeed(value, maximum * CHASSIS_CONTROL_KEYBOARD_LINEAR_RATIO *
                  (float)sample * 0.002f / CHASSIS_CONTROL_KEYBOARD_RAMP_T1_S);
        linear_step = step;
      } else if (sample == 101U) {
        assert(fabsf(step - linear_step) < 0.3f); /* T1两侧斜率差小于1.5%。 */
      }
      if (sample > 101U && sample <= 500U) {
        assert(step <= previous_step + 0.03f); /* 后段逐渐放缓，无中途再加陡。 */
      }
      if (sample == 500U) {
        NearSpeed(value, maximum);
        assert(step < 0.1f); /* 接入恒速时斜率接近零。 */
      }
      previous = value;
      previous_step = step;
    }
    remote.keyboard = 0U;
    ChassisControl_UpdateKeyboard(&remote, 0.002f);
    Near(g_chassis_keyboard_ramped_vx_rpm, 0.0f);
    Near(g_chassis_keyboard_ramped_vy_rpm, 0.0f);
    Near(g_chassis_keyboard_ramped_wz_rpm, 0.0f);
  }

  /* 相同经过时间采用不同实际周期，目标应一致；组合键的两个轴独立。 */
  DR16_Dbus_DataTypeDef remote = {
      .online = true, .keyboard = DR16_DBUS_KEY_W | DR16_DBUS_KEY_D};
  ChassisControl_Clear();
  KeyboardAdvance(&remote, 300);
  const float speed_2ms = g_chassis_keyboard_ramped_vy_rpm;
  ChassisControl_Clear();
  for (uint32_t sample = 0U; sample < 120U; sample++) {
    ChassisControl_UpdateKeyboard(&remote, 0.005f);
  }
  NearSpeed(g_chassis_keyboard_ramped_vy_rpm, speed_2ms);
  NearSpeed(g_chassis_keyboard_ramped_vx_rpm, speed_2ms);
  remote.online = false;
  ChassisControl_UpdateKeyboard(&remote, 0.002f);
  Near(g_chassis_keyboard_ramped_vy_rpm, 0.0f);
  remote.online = true;
  ChassisControl_UpdateKeyboard(&remote, 0.002f);
  assert(g_chassis_keyboard_ramped_vy_rpm < maximum / 100.0f);
}

int main(void) {
  TestPidMath(); TestCascade(); TestChassis(); TestSpinMix(); TestKeyboardMix();
  TestKeyboardLogRamp();
  puts("PASS: PID math, cascade, chassis mixing, spin transform, keyboard and limits");
  return 0;
}

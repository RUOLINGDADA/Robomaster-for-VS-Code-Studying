/* 主机测试只替代 CAN FIFO 取帧接口，不模拟总线。 */
#ifndef TEST_BOARD_CAN_H
#define TEST_BOARD_CAN_H
#include <stdbool.h>
bool BoardCan_PollRxFifo0(void);
#endif

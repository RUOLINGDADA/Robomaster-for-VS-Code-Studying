# pid_controller —— 单环与位置-速度双环

独立 C11 算法模块：`Core/Inc/app/pid_controller/pid_controller.h` 和对应源文件。
只依赖标准 C 库，不依赖 HAL、任务或电机协议；每个对象由一个任务独占，无动态内存和阻塞。

单环接口是 `Pid_Controller_Init/Reset/Calc()`，参数与状态分开保存。
`Init()` 校验有限值和非负限幅，失败对象清零；`Calc()` 的非法输入或 dt 返回0且不更新历史。
每次计算用秒为单位的实际 dt，Kp/Ki/Kd 的单位见头文件。首次采样不产生微分冲击。

计算顺序：

```text
e = target - measurement
积分增量 = Ki × (e + 上次e)/2 × dt × 1/(1+a|e|)
积分项限制在 ±integral_limit
D = -Kd × (measurement - 上次measurement)/dt
滤波系数 alpha = dt/(1/(2πfc) + dt)
滤波D = 上次滤波D + alpha × (D - 上次滤波D)
输出 = clamp(Kp × e + 积分项 + 滤波D, ±output_limit)
```

当前候选输出超过限幅且积分增量继续推向饱和时，本次不累加积分；允许反向增量退出饱和。
a=0恢复普通梯形积分；fc=0表示不滤波；Kd=0时默认只有 PI，但微分功能仍可直接开启。
梯形积分包含上一次误差，目标阶跃后仍有半步面积；停机、离线或重新接管必须调用 `Reset()`。

双环接口是 `Pid_CascadeController_Init/Reset/Calc()`：位置外环输出目标速度，再交给速度内环。
位置环 output_limit 是速度上限，速度环 output_limit 是电流或其他执行器指令上限。
底盘默认只使用单速度环；电调自身处理转矩电流，不增加 CAN 上的电流内环。

后续云台示例（参数需按实际电机设置）：

```c
Pid_CascadeControllerTypeDef controller;
Pid_ControllerConfigTypeDef position_config = {
  .kp = 2.0f, .output_limit = 1000.0f /* 输出转子 rpm */
};
Pid_ControllerConfigTypeDef speed_config = {
  .kp = 4.0f, .ki = 2.0f, .output_limit = 2867.0f,
  .integral_limit = 1000.0f, .integral_error_scale = 0.01f
};
if (Pid_CascadeController_Init(&controller, &position_config, &speed_config)) {
  float current_raw = Pid_CascadeController_Calc(
      &controller, target_deg, continuous_position_deg, logical_speed_rpm, dt_s);
  /* 调用对应云台输出层；这里只给出接口，不接入尚未配置的 CAN2。 */
}
```

位置输入必须在同一坐标系并处理单圈回绕，不能直接将0~8191编码器值当作连续角度。
本模块不提供云台驱动、角度累计或云台参数整定。

验证：`python tools/test_pid.py` 使用已安装 Visual Studio 的 C11 编译器，编译真实算法和公共电机代码。
测试替身仅替代 CAN/DBUS 硬件接口，验证梯形/倒数积分、微分先行和滤波、饱和/反向、双环限幅、
四轮混控、方向一致、退出模式复位及一阶负载模型。目标固件另用 `tools/verify.ps1` 编译链接。

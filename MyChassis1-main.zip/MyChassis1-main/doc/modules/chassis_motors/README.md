# chassis_motors —— 底盘公共电机模块

## 职责

集中注册 CAN1 上 ID 1~4 的 M3508，保存四个电机句柄，统一处理反馈超时、停止和聚合控制帧发送。
`HAL_CAN_RxFifo0MsgPendingCallback()` 也在这里，只取 CAN 帧并交给 C620 驱动解析。

## 接口

- `ChassisMotors_Init()`：模式管理任务启动时调用一次。
- `ChassisMotors_Process(now_tick)`：当前拥有输出权的工作任务每周期调用。
- `ChassisMotors_SetCurrent(index, current_raw)`：写入逻辑电流，按用户当前配置对 ID1/4 反相。
- `ChassisMotors_GetSpeedRpm(index, &speed_rpm)`：复制在线反馈，按同一方向表转换成逻辑转子 rpm。
- `ChassisMotors_StopAll()`：清零目标并关闭所有电机。
- `ChassisMotors_Send()`：发送一条 `0x200` 聚合控制帧。
- `g_chassis_motors[4]`：下标0=ID1右前、下标1=ID2左前、下标2=ID3左后、下标3=ID4右后。

## 运行约束

两个工作任务共享句柄，但模式管理任务保证同一时间只有一个任务调用 `Process()` 和 `Send()`。
保留用户实测方向表 `{-1,+1,+1,-1}`：ID1/4 反相，ID2/3 同相。电流和速度共用此表，
保证 PID 目标和反馈在同一坐标系。驱动反馈仍保留原始电调符号，便于核对 CAN 数据。
CAN 回调运行在中断上下文，不能打印、阻塞或调用普通 FreeRTOS API。

## 验证

使用 `powershell -NoProfile -ExecutionPolicy Bypass -File .\\tools\\verify.ps1` 编译验证。
